IMPORTANT!!!!
============================
The test scripts should never be tested on a production database.  The test scripts insert and delete data.  Adapdev.Technologies is not responsible for any loss or damage of existing data.  Use at your own risk.


Support
============================
All bugs, comments, feature requests, etc. should be submitted to:

codus-support@adapdev.com



To test, please do the following:


Testing w/ Access
============================
The Codus folder contains an Access 2003 database, called codustest.mdb.  You must have Access 2003 installed to test this.  When you open Codus, you'll see that a configuration exists for "Codus Access".

1. Press Test Connection - it should say that it connected successfully
2. Press Load Tables - this will load the database schema
3. Go to the Templates tab and click Generate
4. Once the generation is done, test the classes using either Zanebug or NUnit

Zanebug: http://www.adapdev.com/zanebug
NUnit: http://www.nunit.org


Testing w/ Sql Server - CodusTest database
============================
The Codus folder contains a script that will generate a test SqlServer database.  You must have SqlServer 2000 installed to use this.  To create the database, do the following:
1. Open Sql Server Enterprise Manager
2. Open Tools -> Sql Query Analyzer
3. In Sql Query Analyzer select File -> Open
4. Navigate to the C:\Program Files\Codus folder, and select codustest.sql
5. Click on Execute Query (F5) - this will create the database

Once you've done this, you can enter the settings for "Codus Sql" configuration in the Codus GUI.  From there:

1. Press Test Connection - it should say that it connected successfully
2. Press Load Tables - this will load the database schema
3. Go to the Templates tab and click Generate
4. Once the generation is done, test the classes using either Zanebug or NUnit

Zanebug: http://www.adapdev.com/zanebug
NUnit: http://www.nunit.org


Testing w/ Sql Server - Northwind database
============================
SqlServer comes with a default installation of Northwind.  You must have SqlServer 2000 installed to use this.  

Select the "Northwind" configuration in the Codus GUI.  From there:

1. Press Test Connection - it should say that it connected successfully
2. Press Load Tables - this will load the database schema
3. Go to the Templates tab and click Generate
4. Once the generation is done, test the classes using either Zanebug or NUnit

Zanebug: http://www.adapdev.com/zanebug
NUnit: http://www.nunit.org


Testing w/ MySql - Codus_Test Database
============================
Open the MySql Query Browser, open codustest_mysql.sql and run it.  This should create the codus_test catalog.

Select the MySql - MySql native connection and enter the applicable information.

1. Press Test Connection - it should say that it connected successfully
2. Press Load Tables - this will load the database schema
3. Go to the Templates tab and click Generate
4. Once the generation is done, test the classes using either Zanebug or NUnit

Zanebug: http://www.adapdev.com/zanebug
NUnit: http://www.nunit.org