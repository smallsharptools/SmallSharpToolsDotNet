drop database if exists codus_test;

create database codus_test;

use codus_test;

CREATE TABLE `alldatatypes` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `c_tinyint` tinyint(4) default '0',
  `c_bit` tinyint(1) default '0',
  `c_bool` tinyint(1) default '0',
  `c_smallint` smallint(6) default '0',
  `c_mediumint` mediumint(9) default '0',
  `c_int` int(11) default '0',
  `c_integer` int(11) default '0',
  `c_bigint` bigint(20) default '0',
  `c_real` double default '0',
  `c_double` double default '0',
  `c_float` float default '0',
  `c_decimal` decimal(10,0) default '0',
  `c_numeric` decimal(10,0) default '0',
  `c_char` varchar(100) default '',
  `c_varchar` varchar(100) default '',
  `c_date` date default '0000-00-00',
  `c_time` time default '00:00:00',
  `c_year` year(4) default NULL,
  `c_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `c_datetime` datetime default '0000-00-00 00:00:00',
  `c_tinyblob` tinyblob,
  `c_blob` blob,
  `c_mediumblob` mediumblob,
  `c_longblob` longblob,
  `c_tinytext` tinytext,
  `c_text` text,
  `c_mediumtext` mediumtext,
  `c_longtext` longtext,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; 


CREATE TABLE `blobs` (
  `ID` int(11) NOT NULL auto_increment,
  `c_tinyblog` tinyblob,
  `c_blob` blob,
  `c_mediumblob` mediumblob,
  `c_longblob` longblob,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; 

CREATE TABLE `dates_and_times` (
  `ID` int(11) NOT NULL auto_increment,
  `c_year` year(4) default NULL,
  `c_date` date default '0000-00-00',
  `c_time` time default '00:00:00',
  `c_datetime` datetime default '0000-00-00 00:00:00',
  `c_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; 


CREATE TABLE `texts` (
  `ID` int(11) NOT NULL auto_increment,
  `c_tinytext` tinytext,
  `c_text` text,
  `c_mediumtext` mediumtext,
  `c_longtext` longtext,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8; 

