
===========================================
Documentation (docs)
===========================================
The documentation for Codus is created using the DocBook xml format.  In order to work with file, download the following tool:

XmlMind Xml Editor
http://www.xmlmind.com/xmleditor/

To output the documentation to a format other than HTML (such as Word or PDF), download the following converter:

XmlMind FO Converter
http://www.xmlmind.com/foconverter/


===========================================
Libraries (lib)
===========================================
The /lib folder contains all necessary executables that aren't included as part of the Codus code base.  This includes NAnt, Genghis and the Visual Studio Extensions.  It also includes the core engine for code generation - Adapdev.CodeGen.dll.

The Adapdev assemblies are part of the Adapdev.NET project.  You'll need to download them to modify them.
http://www.adapdev.com/adapdevnet

===========================================
Setup (setup)
===========================================
To build the setup, you'll want to first download InnoSetup:

InnoSetup
http://www.jrsoftware.org/

Then, follow these steps:

1. Run prepsetup.bat
This copies all the output from the various folders, and places them in the /setup dir

2. Run buildsetup.iss
This will launch InnoSetup.  You'll want to compile the setup, which will place the results in the /bin directory.

===========================================
Source (src)
===========================================
All source code is contained in the /src directory.  The solution file is a VS.NET 2003 solution file.



