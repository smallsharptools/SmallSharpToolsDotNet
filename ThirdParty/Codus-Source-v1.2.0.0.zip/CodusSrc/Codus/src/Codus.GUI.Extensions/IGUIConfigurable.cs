namespace Codus.GUI.Extensions
{

	/// <summary>
	/// Summary description for ICustomPropertiesUC.
	/// </summary>
	public interface IGUIConfigurable
	{
		GUIConfigurator GetGUIConfigurator();
	}
}