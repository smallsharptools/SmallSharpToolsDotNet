See http://users.rcn.com/creitzel/tidy.html#dotnet for more info about 
this .NET/CLR wrapper for TidyATL/TidyLib.

