using System;

namespace Adapdev.Data.Sql
{
	using System.Collections;
	using System.Text;
	using Adapdev.Text;

	/// <summary>
	/// Summary description for Criteria.
	/// </summary>
	public abstract class Criteria : ICriteria
	{
		protected StringBuilder sb = new StringBuilder();
		protected DbType type = DbType.SQLSERVER;
		protected DbProviderType provider = DbProviderType.SQLSERVER;
		protected bool initialized = false;

		public Criteria(DbType type, DbProviderType provider)
		{
			this.type = type;
			this.provider = provider;
		}

		public Criteria(DbType type, DbProviderType provider, string sql): this(type, provider)
		{
			sql = sql.Replace("WHERE", "");
			this.AddSql(sql);
		}

		public void AddAnd()
		{
			if(this.initialized)this.AddCriteriaSeparator(CriteriaType.AND);
		}

		public virtual void AddAndCriteria(ICriteria c)
		{
			if(c.Initialized)
			{
				this.AddAnd();
				sb.Append("(");
				sb.Append(c.GetText().Replace("WHERE","").Trim());
				sb.Append(") ");
				this.initialized = true;
			}
		}

		protected void AddCriteriaSeparator(CriteriaType ct)
		{
			if (ct == CriteriaType.AND) sb.Append(" AND ");
			else sb.Append(" OR ");
		}

		public virtual void AddBetween(string columnName, object value1, object value2)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" BETWEEN ");
			sb.Append(QueryHelper.DressUp(value1,this.type));
			sb.Append(" AND ");
			sb.Append(QueryHelper.DressUp(value2,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddEqualTo(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" = ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddEqualTo(string tableName, string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(tableName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(".");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" = ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public void AddEqualTo(string columnName)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" = ");
			sb.Append(QueryHelper.GetParameterName(columnName, this.DbProviderType));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddExists(ISqlQuery subSqlQuery)
		{
			sb.Append(" EXISTS (" + subSqlQuery.Statement + ") ");
			this.initialized = true;
		}

		public virtual void AddGreaterThanOrEqualTo(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" >= ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddGreaterThan(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" > ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddIn(string columnName, ISqlQuery subSqlQuery)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" IN (");
			sb.Append(subSqlQuery.GetText());
			sb.Append(") ");
			this.initialized = true;
		}

		public virtual void AddIn(string columnName, ICollection values)
		{
			StringBuilder sbo = new StringBuilder();
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" IN (");
			IEnumerator enumerator = values.GetEnumerator();
			while (enumerator.MoveNext())
			{
				sbo.Append(QueryHelper.DressUp(enumerator.Current, this.type) + ", ");
			}
			sb.Append(StringUtil.RemoveFinalComma(sbo.ToString()));
			sb.Append(") ");
			this.initialized = true;
		}

		public virtual void AddIsNull(string columnName)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" IS NULL ");
			this.initialized = true;
		}

		public virtual void AddLessThanOrEqualTo(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" <= ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddLessThan(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" < ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddLike(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" LIKE ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddLike(string tableName, string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(tableName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(".");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" LIKE ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddNotBetween(string columnName, object value1, object value2)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" NOT BETWEEN ");
			sb.Append(QueryHelper.DressUp(value1, this.type));
			sb.Append(" AND ");
			sb.Append(QueryHelper.DressUp(value2, this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddNotEqualTo(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" <> ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddNotExists(ISqlQuery subSqlQuery)
		{
			sb.Append(" NOT EXISTS (" + subSqlQuery.GetText() + ") ");
			this.initialized = true;
		}

		public virtual void AddNotIn(string columnName, ICollection values)
		{
			StringBuilder sbo = new StringBuilder();
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" NOT IN (");
			IEnumerator enumerator = values.GetEnumerator();
			while (enumerator.MoveNext())
			{
				sbo.Append(QueryHelper.DressUp(enumerator.Current, this.type) + ", ");
			}
			sb.Append(StringUtil.RemoveFinalComma(sbo.ToString()));
			sb.Append(")");
			this.initialized = true;
		}

		public virtual void AddNotIn(string columnName, ISqlQuery subSqlQuery)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));

			sb.Append(" NOT IN (" + subSqlQuery.GetText() + ") ");
			this.initialized = true;
		}

		public virtual void AddNotLike(string columnName, object columnValue)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" NOT LIKE ");
			sb.Append(QueryHelper.DressUp(columnValue,this.type));
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual void AddNotNull(string columnName)
		{
			sb.Append(" ");
			sb.Append(QueryHelper.GetPreDelimeter(this.type));
			sb.Append(columnName);
			sb.Append(QueryHelper.GetPostDelimeter(this.type));
			sb.Append(" IS NOT NULL ");
			this.initialized = true;
		}

		public void AddOr()
		{
			if(this.initialized)this.AddCriteriaSeparator(CriteriaType.OR);
		}

		public void AddOrCriteria(ICriteria c)
		{
			if(c.Initialized)
			{
				this.AddOr();
				sb.Append("(" + c.GetText().Replace("WHERE","").Trim() + ") ");
				this.initialized = true;
			}
		}

		public virtual void AddSql(string sql)
		{
			sb.Append(" ");
			sb.Append(sql);
			sb.Append(" ");
			this.initialized = true;
		}

		public virtual string GetText()
		{
			if (this.initialized)
			{
				return " WHERE " + sb.ToString();
			}
			else
			{
				return "";
			}
		}

		public bool Initialized
		{
			get { return this.initialized; }
		}

		public DbProviderType DbProviderType
		{
			get { return this.provider; }
			set { this.provider = value; }
		}

		public string Statement
		{
			get{return this.GetText();}
		}

	}

	public enum CriteriaType
	{
		AND,
		OR
	}
}
