namespace Adapdev.Data.Sql
{
	/// <summary>
	/// Summary description for IDeleteQuery.
	/// </summary>
	public interface IDeleteQuery : INonSelectQuery
	{
	}
}