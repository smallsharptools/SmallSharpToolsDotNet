using System;

namespace Adapdev.Data
{
	/// <summary>
	/// Summary description for IQuery.
	/// </summary>
	public interface IQuery
	{
		/// <summary>
		/// Returns the text form of the query
		/// </summary>
		/// <returns></returns>
		string GetText();
	}
}
