namespace Adapdev.Data
{
	public enum DbProviderType
	{
		UNKNOWN,
		DB2,
		MYSQL,
		ORACLE,
		SQLSERVER,
		OLEDB,
		ODBC
	}
}