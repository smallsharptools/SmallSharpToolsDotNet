using System;
using System.Data;
using System.Text;

namespace Adapdev.Data
{
	/// <summary>
	/// Summary description for DataReaderDebugger.
	/// </summary>
	public class DataReaderDebugger
	{
		private DataReaderDebugger(){}

		public static string ToString(IDataReader reader)
		{
			StringBuilder sb = new StringBuilder();
			do
			{
				int i = reader.FieldCount;
				for(int j = 0; j < i; j++)
				{
					sb.Append(reader.GetName(j) + "|");
				}
				sb.Append(Environment.NewLine);


				while(reader.Read())
				{
					for(int j = 0; j < i; j++)
					{
						sb.Append(reader.GetValue(j).ToString() + "|");
					}
					sb.Append(Environment.NewLine);
				}
				sb.Append(Environment.NewLine);
			}
			while(reader.NextResult());

			return sb.ToString();
		}
	}
}
