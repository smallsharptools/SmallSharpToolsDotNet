namespace Adapdev.Data.Schema
{
	using System;
	using System.Collections;
	using System.Text;
	using System.Xml.Serialization;

	[Serializable]
	public class TableSchemaDictionary : DictionaryBase, IXmlSerializable
	{

		private const string nameSpace = "";
		private const string tableDictionaryElement = "TableDictionary";

		public TableSchema this[String key]
		{
			get { return ((TableSchema) Dictionary[key]); }
			set { Dictionary[key] = value; }
		}
		
		public ICollection Keys
		{
			get { return (Dictionary.Keys); }
		}

		public ICollection Values
		{
			get { return (Dictionary.Values); }
		}

		public void Add(String key, TableSchema value)
		{
			Dictionary.Add(key, value);
		}

		public bool Contains(String key)
		{
			return (Dictionary.Contains(key));
		}

		public void Remove(String key)
		{
			Dictionary.Remove(key);
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			foreach (TableSchema ti in this.Values)
			{
				sb.Append(ti.ToString());
			}
			return sb.ToString();
		}
		#region IXmlSerializable Members

		/// <summary>
		/// XmlWriter that is used to write the TableSchemaDictionary as it implements IDictory that is not serializable
		/// using the normal methods. This uses the interface IXmlSerializable which isn't offically supported but still  
		/// exists in the next framework
		/// </summary>
		/// <param name="writer">System.Xml.XmlWriter</param>
		public void WriteXml(System.Xml.XmlWriter writer)
		{
			XmlSerializer keySer = new XmlSerializer(typeof(String));
			XmlSerializer valueSer = new XmlSerializer(typeof(TableSchema));

			writer.WriteStartElement(tableDictionaryElement,nameSpace);
			foreach(object key in Dictionary.Keys){
				
				writer.WriteStartElement("key", nameSpace);
				keySer.Serialize(writer,key);
				writer.WriteEndElement();

				writer.WriteStartElement("value", nameSpace);
				object value = Dictionary[key];
				valueSer.Serialize(writer, value);
				writer.WriteEndElement();
			}
			writer.WriteEndElement();
		}

		public System.Xml.Schema.XmlSchema GetSchema()
		{
			return null;
		}
		
		/// <summary>
		/// Custom XmlReader to read the TableSchemaDictionary 
		/// </summary>
		/// <param name="reader">System.Xml.XmlReader</param>
		public void ReadXml(System.Xml.XmlReader reader)
		{
			XmlSerializer keySer = new XmlSerializer(typeof(String));
			XmlSerializer valueSer = new XmlSerializer(typeof(TableSchema));
			
			reader.Read();
			reader.ReadStartElement(tableDictionaryElement,nameSpace);
			
			while(reader.Name != tableDictionaryElement && reader.NodeType != System.Xml.XmlNodeType.EndElement)
			{
				reader.ReadStartElement("key", nameSpace);
				object key = keySer.Deserialize(reader);
				reader.ReadEndElement();

				reader.ReadStartElement("value", nameSpace);
				object value = valueSer.Deserialize(reader);
				reader.ReadEndElement();

				Dictionary.Add(key, value);
				reader.MoveToContent();
				//navigate past the end element tags to the next table 
				do{
					reader.Skip();
				}while(reader.NodeType == System.Xml.XmlNodeType.EndElement && reader.Name != tableDictionaryElement);
			}
			reader.ReadEndElement();
		}
		#endregion
	}
}