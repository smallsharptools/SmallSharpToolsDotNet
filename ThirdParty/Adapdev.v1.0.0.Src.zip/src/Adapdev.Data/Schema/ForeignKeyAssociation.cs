using System;
using System.ComponentModel;
using System.Xml.Serialization;

namespace Adapdev.Data.Schema
{
	using Adapdev.Text;

	/// <summary>
	/// Summary description for ForeignKeyAssociation.
	/// </summary>
	/// 
	[Serializable]
	public class ForeignKeyAssociation
	{
		private TableSchema _table = null;
		private ColumnSchema _columnSchema = null;
		private ColumnSchema _foreignColumn = null;
		private TableSchema _foreignTable = null;
		private TableSchema _secondForeignTable = null;
		private ColumnSchema _secondForeignColumn = null;
		private TableSchema _thirdForeignTable = null;
		private ColumnSchema _thirdForeignColumn = null;
		private AssociationType _association = AssociationType.OneToMany;
		
		public ForeignKeyAssociation(){}

		public ForeignKeyAssociation(TableSchema table, ColumnSchema columnSchema, TableSchema foreignTable, ColumnSchema foreignColumn)
		{
			this._table = table;
			this._columnSchema = columnSchema;
			this._foreignColumn = foreignColumn;
			this._foreignTable = foreignTable;
		}

		public ForeignKeyAssociation(TableSchema table, ColumnSchema columnSchema, TableSchema foreignTable, ColumnSchema foreignColumn, TableSchema secondForeignTable, ColumnSchema secondForeignColumn)
		{
			this._table = table;
			this._columnSchema = columnSchema;
			this._foreignColumn = foreignColumn;
			this._foreignTable = foreignTable;
			this._secondForeignColumn = secondForeignColumn;
			this._secondForeignTable = secondForeignTable;
		}

		public ForeignKeyAssociation(TableSchema table, ColumnSchema columnSchema, TableSchema foreignTable, ColumnSchema foreignColumn, TableSchema secondForeignTable, ColumnSchema secondForeignColumn, TableSchema thirdForeignTable, ColumnSchema thirdForeignColumn)
		{
			this._table = table;
			this._columnSchema = columnSchema;
			this._foreignColumn = foreignColumn;
			this._foreignTable = foreignTable;
			this._secondForeignColumn = secondForeignColumn;
			this._secondForeignTable = secondForeignTable;
			this._thirdForeignColumn = thirdForeignColumn;
			this._thirdForeignTable = thirdForeignTable;
		}

		[Browsable(false)]
		public ColumnSchema ForeignColumn
		{
			get { return _foreignColumn; }
			set { _foreignColumn = value; }
		}

		public string ForeignColumnName
		{
			get
			{
				if(this._foreignColumn != null) return this._foreignColumn.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public ColumnSchema SecondForeignColumn
		{
			get { return _secondForeignColumn; }
			set { _secondForeignColumn = value; }
		}

		public string SecondForeignColumnName
		{
			get
			{
				if(this._secondForeignColumn != null) return this._secondForeignColumn.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public ColumnSchema Column
		{
			get { return _columnSchema; }
			set { _columnSchema = value; }
		}

		public string ColumnName
		{
			get
			{
				if(this._columnSchema != null) return this._columnSchema.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public TableSchema Table
		{
			get { return this._table; }
			set { _table = value; }
		}

		public string TableName
		{
			get
			{
				if(this._table != null) return this._table.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public TableSchema ForeignTable
		{
			get { return _foreignTable; }
			set { _foreignTable = value; }
		}

		public string ForeignTableName
		{
			get
			{
				if(this._foreignTable != null) return this._foreignTable.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public TableSchema SecondForeignTable
		{
			get { return _secondForeignTable; }
			set { _secondForeignTable = value; }
		}

		public string SecondForeignTableName
		{
			get
			{
				if(this._secondForeignTable != null) return this._secondForeignTable.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public TableSchema ThirdForeignTable
		{
			get { return _thirdForeignTable; }
			set { _thirdForeignTable = value; }
		}

		public string ThirdForeignTableName
		{
			get
			{
				if(this._thirdForeignTable != null) return this._thirdForeignTable.Name;
				else return String.Empty;
			}
		}

		[Browsable(false)]
		public ColumnSchema ThirdForeignColumn
		{
			get { return _thirdForeignColumn; }
			set { _thirdForeignColumn = value; }
		}

		public string ThirdForeignColumnName
		{
			get
			{
				if(this._thirdForeignColumn != null) return this._thirdForeignColumn.Name;
				else return String.Empty;
			}
		}

		public string ForeignKeyName
		{
			get
			{
				if(this.SecondForeignTable != null && this.ThirdForeignTable != null)
					return this.DisplayAssociation() + this._table.Name + "." + this.ColumnName + " - " + this.ForeignTableName + "." + this.ForeignColumnName + " - " + this.SecondForeignTableName + "." + this.SecondForeignColumnName + " - " + this.ThirdForeignTableName + "." + this.ThirdForeignColumnName;
				else if(this.SecondForeignTable != null && this.ThirdForeignTable == null)
					return this.DisplayAssociation() + this._table.Name + "." + this.ColumnName + " - " + this.ForeignTableName + "." + this.ForeignColumnName + " - " + this.SecondForeignTableName + "." + this.SecondForeignColumnName;
				else
					return this.DisplayAssociation() + this._table.Name + "." + this.ColumnName + " - " + this.ForeignTableName + "." + this.ForeignColumnName;
			}
		}

		public AssociationType AssociationType
		{
			get { return _association; }
			set { _association = value; }
		}

		private string DisplayAssociation()
		{
			if (this.AssociationType == AssociationType.OneToOne) return "(1-1) ";
			if (this.AssociationType == AssociationType.OneToMany) return "(1-n) ";
			if (this.AssociationType == AssociationType.ManyToMany) return "(n-n) ";
			return String.Empty;
		}

		[Browsable(false)]
		public override string ToString()
		{
			return StringUtil.ToString(this);
		}

	}
}
