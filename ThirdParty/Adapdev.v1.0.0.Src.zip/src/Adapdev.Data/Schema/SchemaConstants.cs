using System;

namespace Adapdev.Data.Schema
{
	/// <summary>
	/// Summary description for Constants Associated with the Schema
	/// </summary>
	public class SchemaConstants
	{		
		public static readonly string SCHEMAPATH = System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData);
		public static readonly string REDUNDANT = "REMOVED_";
	}
}
