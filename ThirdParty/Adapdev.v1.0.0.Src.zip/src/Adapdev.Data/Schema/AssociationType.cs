using System;

namespace Adapdev.Data.Schema
{
	/// <summary>
	/// Summary description for AssociationType.
	/// </summary>
	public enum AssociationType
	{
		OneToOne,
		OneToMany,
		ManyToMany,
		ManyToOne
	}
}
