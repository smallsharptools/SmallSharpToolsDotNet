using System;
using Adapdev.Serialization;

namespace Adapdev.Data.Schema
{

	using System.IO;
	using System.Xml.Serialization;
	

	/// <summary>
	/// Summary description for SaveDatabaseSchema.
	/// </summary>
	public class SaveDatabaseSchema
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		private DatabaseSchema _dbSchema;
		private String schemaFile;
		private String _savedSchemaName;

		public SaveDatabaseSchema(DatabaseSchema dbSchema, String savedSchemaName)
		{
			this._dbSchema = dbSchema;
			this._savedSchemaName = savedSchemaName;
		}

		public void Save()
		{	
			schemaFile = System.IO.Path.Combine(SchemaConstants.SCHEMAPATH,_savedSchemaName);
			Serializer.SerializeToBinary(this._dbSchema, schemaFile);
		}
	}
}
