using System;

namespace Adapdev.Data.Schema
{
	using System.Reflection;
	using Adapdev.Attributes;

	/// <summary>
	/// Summary description for CompareSchemasCommand.
	/// </summary>
	public class CompareDatabaseSchemas
	{
		private DatabaseSchema _databaseSchema;
		private DatabaseSchema _savedDatabaseSchema;

		public CompareDatabaseSchemas(DatabaseSchema databaseSchema, DatabaseSchema savedDatabaseSchema)
		{
			this._databaseSchema = databaseSchema;
			this._savedDatabaseSchema = savedDatabaseSchema;
		}

		/// <summary>
		/// Compare the saved Schema and the database Schema by iterating through the DatabaseSchema's tables
		/// </summary>
		/// <returns>DatabaseSchema - the updated DatabaseSchema</returns>
		public DatabaseSchema Compare()
		{			
			findAndUpdateTables();
			return _savedDatabaseSchema;
		}
		
		private void findAndUpdateTables()
		{
			foreach(TableSchema table in _databaseSchema.SortedTables.Values)
			{	
				//If the table exists check it otherwise add the table
				if(null != this._savedDatabaseSchema.GetTable(table.Name))
				{
					foreach (PropertyInfo property in table.GetType().GetProperties())
					{
						foreach (object attribute in property.GetCustomAttributes(typeof(SchemaDataRewritableAttribute),true))
						{
							if(isRewritable(attribute, property))
							{
								rewritePropertyForTable(table, property);
							}	
						}
					}
					findAndUpdateColumns(table);				
				}
				else
				{
					this._savedDatabaseSchema.AddTable(table);
				}
			}
			this.markRedundantTables();
		}


		/// <summary>
		/// Iterate through the ColumnSchema's for a TableSchema and update properties that are rewritable from the Database Schema
		/// </summary>
		/// <param name="table">TableSchema table that we will check it's ColumnSchema's</param>
		private void findAndUpdateColumns(TableSchema table)
		{
			foreach(ColumnSchema column in table.SortedColumns.Values)
			{
				//If the column exists check it otherwise add the column
				if(null != this._savedDatabaseSchema.GetTable(table.Name).GetColumn(column.Name))
				{
					foreach (PropertyInfo property in column.GetType().GetProperties())
					{	
						foreach(object attribute in property.GetCustomAttributes(typeof(SchemaDataRewritableAttribute),true))
						{
							if(isRewritable(attribute,property))
							{
								rewritePropertyForColumn(table,column,property);
							}
						}
					}	
				}
				else
				{
					this._savedDatabaseSchema.GetTable(table.Name).AddColumn(column);
				}
			}
			markRedundantColumns(table.Name);
		}

		/// <summary>
		/// Mark a column that no longer exits in the DB schema but is in our saved schema
		/// </summary>
		/// <param name="tableNameToUpdate">String</param>
		private void markRedundantColumns(String tableNameToUpdate)
		{	
			foreach(ColumnSchema column in this._savedDatabaseSchema.GetTable(tableNameToUpdate).SortedColumns.Values)
			{
				if(null == this._databaseSchema.GetTable(tableNameToUpdate).GetColumn(column.Name))
				{
//					string newname = SchemaConstants.REDUNDANT + column.Name;
					string oldname = column.Name;
//					ColumnSchema c = column;
//					c.IsActive = false;
//					c.Name = newname;

					this._savedDatabaseSchema.GetTable(tableNameToUpdate).RemoveColumn(oldname);
//					this._savedDatabaseSchema.GetTable(tableNameToUpdate).AddColumn(c);
				}
			}
		}

		/// <summary>
		/// Mark a table that no longer exits in the DB schema but is in our saved schema
		/// </summary>
		private void markRedundantTables()
		{	
			foreach(TableSchema table in this._savedDatabaseSchema.SortedTables.Values)
			{	
				if(null == this._databaseSchema.GetTable(table.Name))
				{
					//					string newname = SchemaConstants.REDUNDANT + column.Name;
					string oldname = table.Name;
					//					ColumnSchema c = column;
					//					c.IsActive = false;
					//					c.Name = newname;

					this._savedDatabaseSchema.Tables.Remove(table.Name);
					//					this._savedDatabaseSchema.GetTable(tableNameToUpdate).AddColumn(c);



//					this._savedDatabaseSchema.GetTable(table.Name).IsActive = false;
//					this._savedDatabaseSchema.GetTable(table.Name).Name = SchemaConstants.REDUNDANT + table.Name;
				}
			}
		}

		/// <summary>
		/// Rewrite the TableSchema proprety to match that from the Database
		/// </summary>
		/// <param name="tableToUpdateFrom">TableSchema object that we will use to update from</param>
		/// <param name="property">PropertyInfo</param>
		private void rewritePropertyForTable(TableSchema tableToUpdateFrom, PropertyInfo property)
		{	
			TableSchema tableToUpdate = this._savedDatabaseSchema.GetTable(tableToUpdateFrom.Name);
			PropertyInfo tablePropertyToUpdate = tableToUpdate.GetType().GetProperty(property.Name);
			tablePropertyToUpdate.SetValue(tableToUpdateFrom, property.GetValue(tableToUpdate,null),null);
		}

		/// <summary>
		/// Rewrite the ColumnSchema proprety to match that from the Database
		/// </summary>
		/// <param name="tableToUpdateFrom">TableSchema object that we will use to update from</param>
		/// <param name="columnToUpdateFrom">ColumnSchema object that we will use to update from</param>
		/// <param name="property">PropertyInfo</param>
		private void rewritePropertyForColumn(TableSchema tableToUpdateFrom, ColumnSchema columnToUpdateFrom, PropertyInfo property)
		{
			ColumnSchema columnToUpdate = this._savedDatabaseSchema.GetTable(tableToUpdateFrom.Name).GetColumn(columnToUpdateFrom.Name);
			PropertyInfo columnPropertyToUpdate = columnToUpdate.GetType().GetProperty(property.Name);
			columnPropertyToUpdate.SetValue(columnToUpdateFrom, property.GetValue(columnToUpdate, null),null);
		}
		
		/// <summary>
		/// Is the SchemaDataRewritableAttribute set to update.
		/// </summary>
		/// <param name="attribute">The custom attribute for the property</param>
		/// <param name="property">The Schema PropertyInfo</param>
		/// <returns>bool</returns>
		private bool isRewritable(object attribute,PropertyInfo property)
		{
			return ((SchemaDataRewritableAttribute) attribute).Rewrite && property.CanWrite;
		}
		
	}
}