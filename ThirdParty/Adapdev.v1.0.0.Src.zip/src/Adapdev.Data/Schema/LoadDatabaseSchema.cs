using System;
using Adapdev.Serialization;

namespace Adapdev.Data.Schema
{
	using System.Collections;
	using System.IO;
	using System.Xml.Serialization;

	/// <summary>
	/// Summary description for LoadDatabaseSchema.
	/// </summary>
	public class LoadDatabaseSchema
	{
		private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		private DatabaseSchema _dbSchema;
		private String schemaFile;
		private String _savedSchemaName;

		public LoadDatabaseSchema(String savedSchemaName, DatabaseSchema dbSchema)
		{
			this._savedSchemaName = savedSchemaName;
			this._dbSchema = dbSchema;
		}

		public DatabaseSchema Load()
		{
			schemaFile = Path.Combine(SchemaConstants.SCHEMAPATH,this._savedSchemaName);

			if(File.Exists(schemaFile))
			{	
				try
				{
					this._dbSchema = Serializer.DeserializeFromBinary(typeof(DatabaseSchema), schemaFile) as DatabaseSchema;
				}
				catch (Exception)
				{
					// Can't deserialize so let's get rid of it
					File.Delete(schemaFile);
					this._dbSchema = null;
				}
			}
			return _dbSchema;
		}
	}
}