using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Text;
using Adapdev.Data.Sql;

namespace Adapdev.Data.Schema
{
	/// <summary>
	/// Summary description for OleDbSchemaBuilder.
	/// </summary>
	public class OleDbSchemaBuilder : AbstractSchemaBuilder
	{
		private Adapdev.IProgressCallback _callback = null;
		private Adapdev.Data.DbProviderType dbProviderType = DbProviderType.OLEDB;
		private int recordCount = 0;
		private readonly string oledbConnectionString;

		public OleDbSchemaBuilder(Adapdev.IProgressCallback callback, ref int recordCount, string oledbConnectionString)
		{
			this._callback = callback;
			this.recordCount = recordCount;
			this.oledbConnectionString = oledbConnectionString;
		}

		public override DatabaseSchema BuildDatabaseSchema(string connectionString, Adapdev.Data.DbType databaseType, Adapdev.Data.DbProviderType providerType, string schemaFilter)
		{
			bool open = false;
			OleDbConnection connection = (OleDbConnection)DbProviderFactory.CreateConnection(DbProviderType.OLEDB);
			connection.ConnectionString = connectionString;
			DatabaseSchema di = new DatabaseSchema();

			try
			{
				connection.Open();
				open = true;

				DataTable schemaTables = this.GetOleDbSchema(_callback, connection, OleDbSchemaGuid.Tables, "",schemaFilter,"","");
				di.DatabaseProviderType = providerType;
				di.DatabaseType = databaseType;
				this.dbProviderType = providerType;

				if (schemaTables != null) 
				{ 
					if (schemaTables.Rows.Count > 0) 
					{
						//TODO: Note sure if this is valid. It does not work for Oracle DB's
						di.Name = schemaTables.Rows[0]["TABLE_CATALOG"].ToString();
						if (di.Name == String.Empty) di.Name = "Unknown";
			
						// Build the base schema information
						if (!StartProgress(_callback, "Building Table Details",schemaTables.Rows.Count,ref recordCount)) return null;
						foreach (DataRow dr in schemaTables.Rows) 
						{
							// Only process Tables, Views and Synonyms
							TableType tableType = TableTypeConverter.Convert(dr["TABLE_TYPE"].ToString());
							if ((tableType == TableType.TABLE || tableType == TableType.VIEW || tableType == TableType.SYNONYM))
							{
								// Oracle will return tons of system tables
								// so for Oracle, we need to filter out tables
								// with no schema name
								bool go = true;
								switch(di.DatabaseType)
								{
									case DbType.ORACLE:
										if(dr["TABLE_SCHEMA"].ToString().Length > 0) go = true;
										else go = false;
										break;
									default:
										break;
								}

								if (!IncrProgress(_callback, dr["TABLE_NAME"].ToString(), ref recordCount)) return null;

								if(go)
								{
									TableSchema ti = CreateTableSchema(dr);
									//Debug.WriteLine(ti.Name + " -- " + ti.SchemaName);
									CreateColumnSchemas(ti, connection, databaseType);
									if(ti.Columns.Count > 0) di.AddTable(ti);
								}
							}
						}

						// Get the primary key information
						DataTable pkeys = this.GetOleDbSchema(_callback, connection, OleDbSchemaGuid.Primary_Keys, "",schemaFilter,"","");
						if (pkeys != null) 
						{
							if (!StartProgress(_callback, "Building Primary Key Details",pkeys.Rows.Count,ref recordCount)) return null;
							foreach (DataRow dr in pkeys.Rows) 
							{
								string pkTable = dr["TABLE_NAME"].ToString();
								if (!IncrProgress(_callback, dr["TABLE_NAME"].ToString(), ref recordCount)) return null;

								TableSchema tip = di[pkTable];
								if (tip != null) 
								{
									ColumnSchema ci = tip[dr["COLUMN_NAME"].ToString()];
									if (ci != null) 
									{
										ci.IsPrimaryKey = true;
										tip.AddColumn(ci);
									}
								}
							}
						}
				
						// Get the foreign key information
						DataTable fkeys = this.GetOleDbSchema(_callback, connection, OleDbSchemaGuid.Foreign_Keys, "",schemaFilter,"","");
						if (fkeys != null) 
						{
							if (!StartProgress(_callback, "Building Foreign Key Details",fkeys.Rows.Count,ref recordCount)) return null;
							foreach (DataRow dr in fkeys.Rows) 
							{
								string fkTable = dr["FK_TABLE_NAME"].ToString();
								if (!IncrProgress(_callback, dr["FK_TABLE_NAME"].ToString(), ref recordCount)) return null;

								TableSchema tif = di[fkTable];
								if (tif != null) 
								{
									ColumnSchema ci = tif[dr["FK_COLUMN_NAME"].ToString()];
									if (ci != null) 
									{
										ci.IsForeignKey = true;
										tif.AddColumn(ci);
									}
								}
							}
						}

						// Setup the Progress Display if one is defined. 
						if (fkeys != null) 
						{
							if (!StartProgress(_callback, "Building Foreign Key Relationships",fkeys.Rows.Count,ref recordCount)) return null;
							foreach (DataRow dr in fkeys.Rows) 
							{
								if (!IncrProgress(_callback, dr["PK_TABLE_NAME"].ToString(), ref recordCount)) return null;

								// Get the name of the primary key table
								string pkTable = dr["PK_TABLE_NAME"].ToString();
								// Get the name of the foreign key table
								string fkTable = dr["FK_TABLE_NAME"].ToString();
								// Get the name of the foreign key column
								string fkColumn = dr["FK_COLUMN_NAME"].ToString();

								// Get the table containing the primary key
								TableSchema tif = di[pkTable];
								// Get the table containing the foreign key
								TableSchema fk = di[fkTable];
								if (tif != null) 
								{
									try
									{ 
										// Get the primary key
										ColumnSchema ci = tif[dr["PK_COLUMN_NAME"].ToString()];
										// Get the foreign key
										ColumnSchema cf = fk[fkColumn];
										if (ci != null) 
										{
											// Add the association to the table and column containing the foreign key
											ci.ForeignKeyTables.Add(new ForeignKeyAssociation(tif, ci, fk ,cf));
										}
									}
									catch (Exception ex)
									{
										Debug.WriteLine(ex.Message);
									}
								}
							}
						}
						if (!EndProgress(_callback, "Finished Loading Tables",true)) return null;
					} 
					else 
					{
						if (!EndProgress(_callback, "No database schema information found.",false)) return null;
					} 
				} 
				else 
				{
					if (!EndProgress(_callback, "No database schema information found.",false)) return null;
				}
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.Message);
			}
			finally
			{
				if(open) connection.Close();
			}
			return di;
		}


		private TableSchema CreateTableSchema(DataRow dr)
		{
			TableSchema ti = new TableSchema();
			ti.Alias = dr["TABLE_NAME"].ToString();
			ti.Name = dr["TABLE_NAME"].ToString();
			ti.SchemaName = dr["TABLE_SCHEMA"].ToString();
			ti.TableType = TableTypeConverter.Convert(dr["TABLE_TYPE"].ToString());
			return ti;
		}

		/// <summary>
		/// Creates the ColumnSchemas for a specified table
		/// </summary>
		/// <param name="ts">The TableSchema to add the ColumnSchema to</param>
		/// <param name="connection">The OleDb connectionstring to use</param>
		private void CreateColumnSchemas(TableSchema ts, OleDbConnection connection, Adapdev.Data.DbType databaseType)
		{
			DataTable dt = this.GetReaderSchema(connection, ts.Name, databaseType);
			if (!(dt == null)) 
			{
				foreach (DataRow dr in dt.Rows) 
				{
					ColumnSchema ci = new ColumnSchema();
					ci.Alias = (string) dr["ColumnName"];
					ci.AllowNulls = (bool) dr["AllowDBNull"];
					ci.DataTypeId = (int) dr["ProviderType"];
					ci.DataType = ProviderInfoManager.GetInstance().GetNameById(dbProviderType, ci.DataTypeId);
					ci.DefaultTestValue = ProviderInfoManager.GetInstance().GetTestDefaultById(this.dbProviderType, ci.DataTypeId);
					ci.DefaultValue = ProviderInfoManager.GetInstance().GetDefaultById(this.dbProviderType, ci.DataTypeId);
					ci.IsAutoIncrement = (bool) dr["IsAutoIncrement"];
					ci.IsForeignKey = false;
					ci.IsPrimaryKey = false;
					ci.IsUnique = (bool) dr["IsUnique"];
					ci.Length = (int) dr["ColumnSize"];
					ci.Name = (string) dr["ColumnName"];
					ci.NetType = dr["DataType"].ToString();
					ci.Ordinal = (int) dr["ColumnOrdinal"];
					ci.IsReadOnly = (bool) dr["IsReadOnly"];
					ci.NumericPrecision = dr["NumericPrecision"] as string;
					ci.NumericScale = dr["NumericScale"] as string;
					ts.AddColumn(ci);
				} 
			}
		}

		/// <summary>
		/// Gets the OLE db schema.
		/// </summary>
		/// <param name="connection">An open OLEDB connection.</param>
		/// <param name="guid">GUID.</param>
		/// <param name="filterCatalog">Filter catalog.</param>
		/// <param name="filterSchema">Filter schema.</param>
		/// <param name="filterName">Name of the filter.</param>
		/// <param name="filterType">Filter type.</param>
		/// <returns></returns>
		private DataTable GetOleDbSchema(Adapdev.IProgressCallback _callback, OleDbConnection connection, Guid guid, string filterCatalog, string filterSchema, string filterName, string filterType) 
		{
			DataTable schemaTable = null;

			try 
			{
				schemaTable = connection.GetOleDbSchemaTable(guid, GetFilters(guid, filterCatalog, filterSchema, filterName, filterType));
			} 
			catch (Exception ex) 
			{
				if (_callback != null) _callback.AddMessage(ProgressMessageTypes.Critical, "Error obtaining Schema Information: " + ex.Message);
				Debug.WriteLine(ex.Message);
			}
			return schemaTable;
		}

		private static object[] GetFilters(Guid guid, string filterCatalog, string filterSchema, string filterName, string filterType) 
		{
			// Different OleDbSchemaGuid's require a different number of parameters. 
			// These parameter depend on what we are trying to retirve from the database
			// so this function returns the correct parameter sets. 
			// This should be a Switch statement, but the compiler did not like it. 

			filterCatalog	= filterCatalog	== string.Empty ? null : filterCatalog;
			filterSchema	= filterSchema	== string.Empty ? null : filterSchema;
			filterName		= filterName	== string.Empty ? null : filterName;
			filterType		= filterType	== string.Empty ? null : filterType;

			if (guid.Equals(OleDbSchemaGuid.Tables))		return new object[] {filterCatalog, filterSchema, filterName, filterType};
			if (guid.Equals(OleDbSchemaGuid.Views))			return new object[] {filterCatalog, filterSchema, filterName};
			if (guid.Equals(OleDbSchemaGuid.Primary_Keys))	return new object[] {filterCatalog, filterSchema, filterName};
			if (guid.Equals(OleDbSchemaGuid.Foreign_Keys))	return new object[] {filterCatalog, filterSchema, filterName, filterCatalog, filterSchema, filterName};
			if (guid.Equals(OleDbSchemaGuid.Columns))		return new object[] {filterCatalog, filterSchema, filterName, string.Empty};
			return null;
		}

		public StringBuilder PrintOleDbSchema(string oledbConnectionString, Guid guid, string filter)
		{
			OleDbConnection connection = new OleDbConnection(oledbConnectionString);
			StringBuilder sb = new StringBuilder();
			bool open = false;

			try
			{
				connection.Open();
				open = true;

				DataTable schemaTable;
				schemaTable = GetOleDbSchema(null, connection, guid, "","","",filter);

				foreach (DataRow row in schemaTable.Rows)
				{
					foreach (DataColumn column in schemaTable.Columns)
					{
						sb.Append("\t\t" + column + " : " + row[column] + "\r\n");
					}
					sb.Append("\r\n");
				}

				sb.Append("\r\n\r\n");
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.Message);
			}
			finally
			{
				if(open)connection.Close();
			}
			return sb;
		}

		private DataTable GetReaderSchema(OleDbConnection connection, string tableName, Adapdev.Data.DbType databaseType)
		{
			return GetReaderSchema(connection, new OleDbCommand(), oledbConnectionString, databaseType, tableName);
		}

		private DataTable GetReaderSchema(OleDbConnection cn, IDbCommand cmd, string connectionString, Adapdev.Data.DbType databaseType, string tableName)
		{
			DataTable schemaTable = null;
			try 
			{
				// Please Note: Use the GetPre and GetPostDelimiters here as in the case of
				// Oracle using [ ] around a Column Name is not valid. 
				cmd.Connection = cn;
				cmd.CommandText = "SELECT * FROM " + QueryHelper.GetPreDelimeter(databaseType) + tableName + QueryHelper.GetPostDelimeter(databaseType);
				IDataReader myReader = cmd.ExecuteReader(CommandBehavior.SchemaOnly);

				schemaTable = myReader.GetSchemaTable();

				myReader.Close();
			} 
			catch (Exception ex) 
			{
				schemaTable = null;
				if (_callback != null) _callback.AddMessage(ProgressMessageTypes.Warning, "Could not load Column information for " + tableName + ". " + ex.Message);
				Debug.WriteLine(ex.Message);
			}
			return schemaTable;
		}

		public StringBuilder PrintOleDbSchema(string oleDbConnectionString, Guid guid)
		{
			return PrintOleDbSchema(oleDbConnectionString, guid, "");
		}
	}
}
