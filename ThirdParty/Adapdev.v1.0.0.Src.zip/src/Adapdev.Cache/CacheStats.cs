using System;
using Adapdev.Diagnostics;

namespace Adapdev.Cache
{
	using System.Text;
	using Adapdev.Cache.Scavengers;

	/// <summary>
	/// Summary description for CacheStats.
	/// </summary>
	public class CacheStats : ICache
	{
		private ICache _cache = null;
		private double _retrieveTime;
		private double _retrieveTimeAvg;
		private int _retrieved;
		private double _insertTimeAvg;
		private double _insertTime;
		private double _inserted;
		private int _hitCount;
		private int _missCount;
		private readonly IPerfTimer timer = PerfTimerFactory.GetPerfTimer(PerfTimerType.HIRESSECONDS);

		public CacheStats(ICache cache)
		{
			this._cache = cache;
		}
		#region ICache Members

		public void Add(string key, object o)
		{
			timer.Start();
			this._cache.Add(key, o);
			timer.Stop();
			this._insertTime = timer.Duration;
			this._insertTimeAvg += timer.Duration;
			this._inserted++;
		}

		public void Add(int key, object o)
		{
			this.Add(key.ToString(), o);
		}

		public void Remove(Type t, int key)
		{
			this.Remove(t, key.ToString());
		}

		public void Remove(Type t, string key)
		{
			this._cache.Remove(t, key);
		}

		public object Get(Type t, int key)
		{
			return this.Get(t, key.ToString());
		}

		public object Get(Type t, string key)
		{
			timer.Start();
			object o = this._cache.Get(t, key);
			timer.Stop();
			this._retrieveTime = timer.Duration;
			this._retrieveTimeAvg += timer.Duration;
			this._retrieved++;

			if(o == null) this._missCount++;
			else this._hitCount++;

			return o;
		}

		public ICacheItem GetCacheItem(Type t, string key)
		{
			return this._cache.GetCacheItem(t, key);
		}

		public ICacheItem GetCacheItem(Type t, int key)
		{
			return this._cache.GetCacheItem(t, key);
		}

		public void Clear()
		{
			this._cache.Clear();
			this._hitCount = 0;
			this._inserted = 0;
			this._insertTime = 0;
			this._insertTimeAvg = 0;
			this._missCount = 0;
			this._retrieved = 0;
			this._retrieveTime = 0;
			this._retrieveTimeAvg = 0;
		}

		public int Count
		{
			get
			{
				return this._cache.Count;
			}
		}

		public bool Contains(Type t, string key)
		{
			return this._cache.Contains(t, key);
		}

		public bool Contains(Type t, int key)
		{
			return this._cache.Contains(t, key);
		}

		public void Scavenge(Adapdev.Cache.Scavengers.IScavenger scavenger)
		{
			this._cache.Scavenge(scavenger);
		}

		public ICacheItem[] Entries
		{
			get
			{
				return this._cache.Entries;
			}
		}

		public void Populate()
		{
			this._cache.Populate();
		}

		public void Copy(ICache cache)
		{
			this._cache.Copy(cache);
		}

		#endregion

		public double RetrieveTime
		{
			get{return this._retrieveTime;}
		}

		public double InsertTime
		{
			get{return this._insertTime;}
		}

		public double AverageRetrieveTime
		{
			get{return this._retrieveTimeAvg / this._retrieved;}
		}

		public double AverageInsertTime
		{
			get{return this._insertTimeAvg / this._inserted;}
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Insert Time: {0}\r\n", this.InsertTime);
			sb.AppendFormat("Avg. Insert Time: {0}\r\n", this.AverageInsertTime);
			sb.AppendFormat("Retrieve Time: {0}\r\n", this.RetrieveTime);
			sb.AppendFormat("Avg. Retrieve Time: {0}\r\n", this.AverageRetrieveTime);
			sb.AppendFormat("Hit Count: {0}\r\n", this.HitCount);
			sb.AppendFormat("Miss Count: {0}\r\n", this.MissCount);
			return sb.ToString();
		}

		public ICache Cache
		{
			get{return this._cache;}
		}

		public int HitCount
		{
			get{return this._hitCount;}
		}

		public int MissCount
		{
			get{return this._missCount;}
		}

		public void Scavenge(IScavenger scavenger, TimeSpan timespan)
		{
			this.Scavenge(scavenger, timespan);
		}

	}
}
