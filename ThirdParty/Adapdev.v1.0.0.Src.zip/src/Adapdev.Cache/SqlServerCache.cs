namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for SqlServerCache.
	/// </summary>
	public class SqlServerCache : ICache
	{
		public SqlServerCache()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region ICache Members

		public void Add(string id, object item)
		{
			// TODO:  Add SqlServerCache.Add implementation
		}

		public void Remove(string id)
		{
			// TODO:  Add SqlServerCache.Remove implementation
		}

		public object Get(string id)
		{
			// TODO:  Add SqlServerCache.Get implementation
			return null;
		}

		public CacheMetaData GetMetaData(string id)
		{
			return null;
		}

		public CacheMetaDataDictionary GetMetaData()
		{
			return null;
		}

		public void Clear()
		{
			// TODO:  Add SqlServerCache.Clear implementation
		}

		public int Count
		{
			get
			{
				// TODO:  Add SqlServerCache.Count getter implementation
				return 0;
			}
		}

		public void SetScavenger(IScavenger scavenger)
		{
			// TODO:  Add SqlServerCache.SetScavenger implementation
		}

		public bool Contains(string id)
		{
			return false;
		}

		#endregion
	}
}