using System;

namespace Adapdev.Cache.Scavengers
{
	/// <summary>
	/// Summary description for DateScavenger.
	/// </summary>
	public class AbsoluteExpirationScavenger : IScavenger
	{
		private DateTime _date;

		private AbsoluteExpirationScavenger(){}

		public AbsoluteExpirationScavenger(DateTime dateTime)
		{
			this._date = dateTime;
		}
		#region IScavenger Members

		public void Scavenge(ICache cache)
		{
			foreach(CacheItem item in cache.Entries)
			{
				if(item.Created < this._date) cache.Remove(item.ObjectType, item.Key);
			}
		}

		#endregion
	}
}
