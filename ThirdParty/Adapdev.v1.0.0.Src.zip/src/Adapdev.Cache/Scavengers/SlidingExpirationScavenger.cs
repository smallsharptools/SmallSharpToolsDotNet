using System;

namespace Adapdev.Cache.Scavengers
{
	/// <summary>
	/// Summary description for DateScavenger.
	/// </summary>
	public class SlidingExpirationScavenger : IScavenger
	{
		private TimeSpan _timespan;

		private SlidingExpirationScavenger(){}

		public SlidingExpirationScavenger(TimeSpan timespan)
		{
			this._timespan = timespan;
		}
		#region IScavenger Members

		public void Scavenge(ICache cache)
		{
			DateTime span = DateTime.Now.Subtract(this._timespan);

			foreach(CacheItem item in cache.Entries)
			{
				if(item.LastAccessed < span) cache.Remove(item.ObjectType, item.Key);
			}
		}

		#endregion
	}
}
