using System;

namespace Adapdev.Cache.Scavengers
{
	/// <summary>
	/// Summary description for GreaterThanOrdinalScavenger.
	/// </summary>
	public class GreaterThanOrdinalScavenger : IScavenger
	{
		private int _greaterThan = 0;

		private GreaterThanOrdinalScavenger(){}

		public GreaterThanOrdinalScavenger(int greaterThan)
		{
			_greaterThan = greaterThan;
		}
		#region IScavenger Members

		public void Scavenge(ICache cache)
		{
			foreach(CacheItem c in cache.Entries)
			{
				if(c.Ordinal > this._greaterThan)
				{
					cache.Remove(c.ObjectType, c.Key);
				}
			}
		}

		#endregion
	}
}
