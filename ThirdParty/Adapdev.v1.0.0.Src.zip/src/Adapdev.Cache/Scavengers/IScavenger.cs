using System;

namespace Adapdev.Cache.Scavengers
{
	/// <summary>
	/// Summary description for IScavenger.
	/// </summary>
	public interface IScavenger
	{
		void Scavenge(ICache cache);
	}
}
