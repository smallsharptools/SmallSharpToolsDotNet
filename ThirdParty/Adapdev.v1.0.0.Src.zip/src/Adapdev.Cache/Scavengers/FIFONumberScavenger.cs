using System;
using System.Collections;

namespace Adapdev.Cache.Scavengers
{
	public class FIFONumberScavenger : IScavenger
	{
		private int _num = 0;

		private FIFONumberScavenger(){}

		public FIFONumberScavenger(int numberOfItems)
		{
			this._num = numberOfItems;
		}

		#region IScavenger Members

		public void Scavenge(ICache cache)
		{
			ArrayList targets = new ArrayList();
			int start = 0;
			for(int i = 0; i < _num; i++)
			{
				ICacheItem item = cache.Entries[start] as ICacheItem;
				targets.Add(item);
				start++;
			}

			foreach(ICacheItem item in targets)
			{
				cache.Remove(item.ObjectType, item.Key);
			}
		}
		#endregion
	}
}
