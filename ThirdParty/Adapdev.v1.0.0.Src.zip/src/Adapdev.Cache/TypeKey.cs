using System;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for TypeKey.
	/// </summary>
	internal class TypeKey
	{
		public static string Build(Type t, string key)
		{
			return t.FullName + Separator + key;
		}

		public static string GetTypeName(string typekey)
		{
			return typekey.Substring(0, typekey.IndexOf(Separator));
		}

		public static Type GetType(string typekey)
		{
			return Type.GetType(GetTypeName(typekey));
		}

		public static string GetKey(string typekey)
		{
			return typekey.Substring(typekey.IndexOf(Separator), typekey.Length);
		}

		public static string Separator
		{
			get{return "---";}
		}
	}
}
