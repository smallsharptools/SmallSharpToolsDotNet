using System;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for CacheManager.
	/// </summary>
	public class CacheManager
	{
		private static ICache _cache = null;

		static CacheManager()
		{
		}

		/// <summary>
		/// Gets or sets the cache.
		/// </summary>
		/// 
		/// <value>The cache.</value>
		public static ICache Cache
		{
			get
			{
				if(_cache == null) _cache = new ImmutableInMemoryCache();
				return _cache;
			}
			set
			{
				if(_cache != null)
				{
					_cache.Clear();
				}

				_cache = value;
			}
		}

		/// <summary>
		/// Sets the cache.
		/// </summary>
		/// <param name="cacheType">Type of the cache.</param>
		/// <param name="copyExisting">if set to <c>true</c> [copy existing].</param>
		public static void SetCache(CacheType cacheType, bool copyExisting)
		{
			ICache cache = null;

			switch(cacheType)
			{
				case CacheType.File:
					cache = new FileCache();
					if(copyExisting) cache.Copy(Cache);
					Cache = cache;
					break;
				case CacheType.ImmutableInMemory:
					cache = new ImmutableInMemoryCache();
					if(copyExisting) cache.Copy(Cache);
					Cache = cache;
					break;
				case CacheType.MutableInMemory:
					cache = new MutableInMemoryCache();
					if(copyExisting) cache.Copy(Cache);
					Cache = cache;
					break;
				default:
					break;
			}
		}

		/// <summary>
		/// Sets the cache.  The existing cache will automatically be copied over
		/// to the new cache.
		/// </summary>
		/// <param name="cacheType">Type of the cache.</param>
		public static void SetCache(CacheType cacheType)
		{
			SetCache(cacheType, true);
		}
	}
}
