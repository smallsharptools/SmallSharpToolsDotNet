using System;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for CacheUtil.
	/// </summary>
	public class CacheUtil
	{
		private CacheUtil(){}

		/// <summary>
		/// Copies the specified source.
		/// </summary>
		/// <param name="source">The source.</param>
		/// <param name="target">The target.</param>
		public static void Copy(ICache source, ICache target)
		{
			foreach(CacheItem item in source.Entries)
			{
				target.Add(item.Key, item.Object);
			}
		}
	}
}
