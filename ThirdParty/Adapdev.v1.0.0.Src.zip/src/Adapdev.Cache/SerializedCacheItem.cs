using System;
using Adapdev.Serialization;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for SerializedCacheItem.
	/// </summary>
	/// 
	[Serializable]
	public class SerializedCacheItem : CacheItem
	{
		public SerializedCacheItem(string key, object o) : base(key, o)
		{
			this._key = key;
			this._object = Serializer.SerializeToBinary(o);
			this._created = DateTime.Now;
			this._lastAccessed = DateTime.Now;
			this._objectType = o.GetType();
		}

		public override object Object
		{
			get
			{
				return Serializer.DeserializeFromBinary(this._objectType, this._object as byte[]);
			}
		}

		public byte[] BinaryObject
		{
			get{return this._object as byte[];}
		}

	}
}
