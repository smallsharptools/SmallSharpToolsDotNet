using System;
using System.Collections;
using Adapdev.Cache.Scavengers;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for ICache.
	/// </summary>
	public interface ICache
	{
		/// <summary>
		/// Adds the specified object.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="o">The o.</param>
		void Add(string key, object o);
		/// <summary>
		/// Adds the specified object.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="o">The o.</param>
		void Add(int key, object o);
		/// <summary>
		/// Removes the specified object.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		void Remove(Type t, int key);
		/// <summary>
		/// Removes the specified object.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		void Remove(Type t, string key);
		/// <summary>
		/// Gets the specified object.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		object Get(Type t, int key);
		/// <summary>
		/// Gets the specified object.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		object Get(Type t, string key);
		/// <summary>
		/// Gets the cache item.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		ICacheItem GetCacheItem(Type t, string key);
		/// <summary>
		/// Gets the cache item.
		/// </summary>
		/// <param name="t">The object.</param>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		ICacheItem GetCacheItem(Type t, int key);
		/// <summary>
		/// Clears this instance.
		/// </summary>
		void Clear();
		/// <summary>
		/// Gets the count.
		/// </summary>
		/// <value>The count.</value>
		int Count{get;}
		/// <summary>
		/// Determines whether [contains] [the specified object].
		/// </summary>
		/// <param name="t">The t.</param>
		/// <param name="key">The key.</param>
		/// <returns>
		/// 	<c>true</c> if [contains] [the specified object]; otherwise, <c>false</c>.
		/// </returns>
		bool Contains(Type t, string key);
		/// <summary>
		/// Determines whether [contains] [the specified object].
		/// </summary>
		/// <param name="t">The t.</param>
		/// <param name="key">The key.</param>
		/// <returns>
		/// 	<c>true</c> if [contains] [the specified object]; otherwise, <c>false</c>.
		/// </returns>
		bool Contains(Type t, int key);
		/// <summary>
		/// Scavenges the current cache, using the specified scavenger.
		/// </summary>
		/// <param name="scavenger">The scavenger.</param>
		void Scavenge(IScavenger scavenger);
		/// <summary>
		/// Gets the entries.
		/// </summary>
		/// <value>The entries.</value>
		ICacheItem[] Entries{get;}
		/// <summary>
		/// Populates this instance.
		/// </summary>
		void Populate();
		/// <summary>
		/// Copies the specified cache.
		/// </summary>
		/// <param name="cache">The cache.</param>
		void Copy(ICache cache);
	}
}
