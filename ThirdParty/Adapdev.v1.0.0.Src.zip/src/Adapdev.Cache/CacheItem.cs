using System;
using Adapdev;

namespace Adapdev.Cache
{
	/// <summary>
	/// A wrapper for cached objects that contains meta data
	/// </summary>
	[Serializable]
	public class CacheItem : ICacheItem
	{
		protected object _object = null;
		protected string _key = String.Empty;
		protected int _ordinal = 0;
		protected DateTime _created;
		protected DateTime _lastAccessed;
		protected Type _objectType = null;

		/// <summary>
		/// Initializes a new instance of the <see cref="CacheItem"/> class.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="o">The o.</param>
		public CacheItem(string key, object o)
		{
			this._key = key;
			this._object = o;
			this._created = DateTime.Now;
			this._lastAccessed = DateTime.Now;
			this._objectType = o.GetType();
		}

		/// <summary>
		/// Gets the creation time.
		/// </summary>
		/// <value>The creation time.</value>
		public DateTime Created
		{
			get{return this._created;}
		}

		/// <summary>
		/// Gets the type of the object.
		/// </summary>
		/// <value>The type of the object.</value>
		public Type ObjectType
		{
			get{return this._objectType;}
		}

		/// <summary>
		/// Gets the cached object.
		/// </summary>
		/// <value>The cached object.</value>
		public virtual object Object
		{
			get{return this._object;}
		}

		/// <summary>
		/// Gets the internal key.
		/// </summary>
		/// <value>The internal key.</value>
		public string Key
		{
			get{return this._key;}
		}

		/// <summary>
		/// Gets the type key.
		/// </summary>
		/// <value>The type key.</value>
		public string TypeKey
		{
			get{return Adapdev.Cache.TypeKey.Build(this.ObjectType, this.Key);}
		}

		/// <summary>
		/// Gets or sets the ordinal location.
		/// </summary>
		/// <value>The ordinal location.</value>
		public int Ordinal
		{
			get{return this._ordinal;}
			set{this._ordinal = value;}
		}

		/// <summary>
		/// Gets or sets the last accessed time.
		/// </summary>
		/// <value>The last accessed time.</value>
		public DateTime LastAccessed
		{
			get { return _lastAccessed; }
			set { _lastAccessed = value; }
		}

		/// <summary>
		/// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </returns>
		public override string ToString()
		{
			return Adapdev.Text.StringUtil.ToString(this);
		}

	}
}
