using System;
using System.Collections;
using Adapdev.Serialization;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for ReadOnlyInMemoryCache.
	/// </summary>
	public class MutableInMemoryCache : AbstractCache
	{
		private CacheItemDictionary _hashtable = new CacheItemDictionary();
		private int _ordinal = 0;

		public MutableInMemoryCache()
		{
		}
		#region ICache Members

		public override void Add(string key, object o)
		{
			CacheItem c = new CacheItem(key, o);
			c.Ordinal = ++this._ordinal;
			this._hashtable[TypeKey.Build(o.GetType(), key)] = c;
		}

		public override void Remove(Type t, string key)
		{
			this._hashtable.Remove(TypeKey.Build(t, key));
		}

		public override object Get(Type t, string key)
		{
			ICacheItem item = this._hashtable[TypeKey.Build(t, key)] as ICacheItem;
			item.LastAccessed = DateTime.Now;
			return item.Object;
		}

		public override ICacheItem GetCacheItem(Type t, string key)
		{
			ICacheItem item = this._hashtable[TypeKey.Build(t, key)] as ICacheItem;
			item.LastAccessed = DateTime.Now;
			return item;
		}

		public override void Clear()
		{
			this._hashtable.Clear();
		}

		public override bool Contains(Type t, string key)
		{
			return this._hashtable.Contains(TypeKey.Build(t, key));
		}

		public override int Count
		{
			get
			{
				return this._hashtable.Count;
			}
		}

		public override ICacheItem[] Entries
		{
			get
			{
				CacheItem[] items = new CacheItem[this._hashtable.Count];
				this._hashtable.Values.CopyTo(items, 0);
				return items;
			}
		}

		public override void Populate()
		{

		}

		#endregion
	}
}
