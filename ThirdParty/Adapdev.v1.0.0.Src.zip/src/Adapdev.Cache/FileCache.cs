using System;
using System.Collections;
using System.IO;
using Adapdev.Serialization;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for FileCache.
	/// </summary>
	public class FileCache : AbstractCache
	{
		private string _folderPath = String.Empty;
		private CacheItemDictionary _items = new CacheItemDictionary();
		private static int _ordinal = 0;

		public FileCache()
		{
			this._folderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "filecache");
			if(!Directory.Exists(this._folderPath)) Directory.CreateDirectory(this._folderPath);

			FileCache._ordinal = this.Count;
		}

		public FileCache(string folderName)
		{
			this._folderPath = folderName;
			this._folderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "filecache");
			if(!Directory.Exists(this._folderPath)) Directory.CreateDirectory(this._folderPath);

			FileCache._ordinal = this.Count;
		}

		private string GetFileName(Type t, string key)
		{
			return TypeKey.Build(t, key) + ".cache";
		}

		private string GetFullFileName(Type t, string key)
		{
			return Path.Combine(this._folderPath, this.GetFileName(t, key));
		}

		private string GetFileNameWithoutExtension(string fileName)
		{
			return fileName.Substring(0, fileName.LastIndexOf("."));
		}

		#region ICache Members

		public override void Add(string key, object o)
		{
			SerializedCacheItem c = new SerializedCacheItem(key, o);
			c.Ordinal = ++FileCache._ordinal;
			this._items[TypeKey.Build(o.GetType(), key)] = c;
			Serializer.SerializeToBinary(o, Path.Combine(this._folderPath, this.GetFileName(o.GetType(), key)));
		}

		public override void Remove(Type t, string key)
		{

			File.Delete(Path.Combine(this._folderPath, this.GetFileName(t, key)));
			this._items.Remove(TypeKey.Build(t, key));
		}

		public override object Get(Type t, string key)
		{
			string typekey = TypeKey.Build(t, key);
			if(this._items.Contains(typekey))
			{
				ICacheItem item = this._items[typekey] as ICacheItem;
				item.LastAccessed = DateTime.Now;
				return item.Object;
			}
			else if(this.Contains(t, key))
			{
				return Serializer.DeserializeFromBinary(t, this.GetFileName(t, key));
			}
			else
			{
				return null;
			}
		}

		public override ICacheItem GetCacheItem(Type t, string key)
		{
			ICacheItem item = this._items[TypeKey.Build(t, key)] as ICacheItem;
			item.LastAccessed = DateTime.Now;
			return item;
		}

		public override void Clear()
		{
			if(Directory.Exists(this._folderPath))
			{
				Directory.Delete(this._folderPath, true);
				Directory.CreateDirectory(this._folderPath);
				this._items.Clear();
			}
		}

		public override int Count
		{
			get
			{
				return Directory.GetFiles(this._folderPath).Length;
			}
		}

		public override bool Contains(Type t, string key)
		{
			return File.Exists(this.GetFullFileName(t, key));
		}

		public override ICacheItem[] Entries
		{
			get
			{
				CacheItem[] items = new CacheItem[this._items.Count];
				this._items.Values.CopyTo(items, 0);
				return items;
			}
		}

		public override void Populate()
		{
			foreach(FileInfo f in new DirectoryInfo(this._folderPath).GetFiles())
			{
				string fileName = this.GetFileNameWithoutExtension(f.Name);
				SerializedCacheItem c = new SerializedCacheItem(TypeKey.GetKey(fileName), Serializer.DeserializeFromBinary(TypeKey.GetType(fileName), f.FullName));
				c.Ordinal = FileCache._ordinal++;
				this._items[f.Name] = c;
			}
		}

		#endregion
	}
}
