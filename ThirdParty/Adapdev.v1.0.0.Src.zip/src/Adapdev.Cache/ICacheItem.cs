using System;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for ICacheItem.
	/// </summary>
	public interface ICacheItem
	{
		/// <summary>
		/// Gets the created date and time.
		/// </summary>
		/// <value>The created date and time.</value>
		DateTime Created{get;}
		/// <summary>
		/// Gets or sets the last accessed date and time.
		/// </summary>
		/// <value>The last accessed date and time.</value>
		DateTime LastAccessed{get;set;}
		/// <summary>
		/// Gets the type of the object.
		/// </summary>
		/// <value>The type of the object.</value>
		Type ObjectType{get;}
		/// <summary>
		/// Gets the object.
		/// </summary>
		/// <value>The object.</value>
		object Object{get;}
		/// <summary>
		/// Gets the key.
		/// </summary>
		/// <value>The key.</value>
		string Key{get;}
		/// <summary>
		/// Gets or sets the ordinal value.
		/// </summary>
		/// <value>The ordinal value.</value>
		int Ordinal{get;set;}
	}
}
