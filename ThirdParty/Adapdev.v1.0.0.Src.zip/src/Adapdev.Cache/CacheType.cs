using System;

namespace Adapdev.Cache
{
	/// <summary>
	/// Summary description for CacheType.
	/// </summary>
	public enum CacheType
	{
		File,
		ImmutableInMemory,
		MutableInMemory
	}
}
