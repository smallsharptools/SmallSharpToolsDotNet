using System;
using Adapdev;

namespace Adapdev.Cache
{
	using System.Collections;
	using System.Timers;
	using Adapdev.Cache.Scavengers;

	/// <summary>
	/// Summary description for AbstractCache.
	/// </summary>
	public abstract class AbstractCache : LongLivingMarshalByRefObject, ICache
	{
		protected ArrayList _timers = new ArrayList();
		protected ArrayList _scavengers = new ArrayList();

		#region ICache Members

		public void Add(int key, object o)
		{
			this.Add(key.ToString(), o);
		}

		public void Remove(Type t, int key)
		{
			this.Remove(t, key.ToString());
		}

		public object Get(Type t, int key)
		{
			return this.Get(t, key.ToString());
		}

		public ICacheItem GetCacheItem(Type t, int key)
		{
			return this.GetCacheItem(t, key.ToString());
		}

		public bool Contains(Type t, int key)
		{
			return this.Contains(t, key.ToString());
		}

		public void Scavenge(Adapdev.Cache.Scavengers.IScavenger scavenger)
		{
			scavenger.Scavenge(this);
		}

		public void Copy(ICache cache)
		{
			CacheUtil.Copy(cache, this);
		}

		public abstract void Add(string key, object o);
		public abstract void Clear();
		public abstract bool Contains(Type t, string key);
		public abstract int Count{get;}
		public abstract ICacheItem[] Entries{get;}
		public abstract object Get(Type t, string key);
		public abstract ICacheItem GetCacheItem(Type t, string key);
		public abstract void Populate();
		public abstract void Remove(Type t, string key);

		#endregion
	}
}
