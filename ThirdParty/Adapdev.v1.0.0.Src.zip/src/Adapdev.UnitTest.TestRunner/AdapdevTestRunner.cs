using System;
using System.Text;
using TestDriven.Framework;
using TDF = TestDriven.Framework;
using System.Reflection;
using Adapdev.UnitTest.Core;
using AUC = Adapdev.UnitTest.Core;
using System.Diagnostics;

namespace Adapdev.UnitTest.TestRunner
{
    public class AdapdevTestRunner : ITestRunner
    {
        public TestRunState RunAssembly(ITestListener testListener, Assembly assembly)
        {
			ITestSuiteFilter filter = new NoFilter();
			return run(testListener, assembly, filter);
		}

        public TestRunState RunMember(ITestListener testListener, Assembly assembly, MemberInfo member)
        {
			if (member is Type)
			{
				ITestSuiteFilter filter = new TypeFilter(member as Type);
				return run(testListener, assembly, filter);
			}
			else if (member is MethodInfo)
			{
				ITestSuiteFilter filter = new MethodFilter(member as MethodInfo);
				return run(testListener, assembly, filter);
			}
			else
			{
				return TestRunState.NoTests;
			}
        }

        public TestRunState RunNamespace(ITestListener testListener, Assembly assembly, string ns)
        {
			ITestSuiteFilter filter = new NamespaceFilter(ns);
            return run(testListener, assembly, filter);
        }

		TestRunState run(ITestListener testListener, Assembly assembly, ITestSuiteFilter filter)
		{
			string assemblyFile = new Uri(assembly.CodeBase).LocalPath;
			ITestEngine engine = TestEngineFactory.CreateLocal(assemblyFile);
			TestSuite suite = engine.GetTestSuite();
			filter.Filter(suite);

			if (suite.GetTestCount() == 0)
			{
				return TestRunState.NoTests;
			}

			ProxyTestListener listener = new ProxyTestListener(testListener, suite.GetTestCount());
			engine.SetTestEventDispatcher(listener.CreateDispatcher());

			TestAssemblyResult[] results = engine.Run(suite);

			// HACK: Not always Success.
			return TestRunState.Success;
		}

        class ProxyTestListener
        {
            ITestListener testListener;
            int testCount;

            public ProxyTestListener(ITestListener testListener, int testCount)
            {
                this.testListener = testListener;
                this.testCount = testCount;
            }

            public TestEventDispatcher CreateDispatcher()
            {
                TestEventDispatcher dispatcher = new TestEventDispatcher();
				dispatcher.TestIterationCompleted += new TestIterationCompletedEventHandler(dispatcher_TestIterationCompleted);
				dispatcher.TestSuiteCompleted += new TestSuiteCompletedEventHandler(dispatcher_TestSuiteCompleted);
                return dispatcher;
            }

			private void dispatcher_TestIterationCompleted(object sender, TestIterationEventArgs e)
			{
				// HACK: Should this event fire if ShouldRun == false?
				if (e.TestIteration.State != AUC.TestState.Ignore)
				{
					string consoleError = e.TestIteration.ConsoleError;
					if(consoleError != null && consoleError.Length > 0)
					{
						// HACK: Console output is being redirected.
						Trace.Write(consoleError);
					}

					string consoleOutput = e.TestIteration.ConsoleOutput;
					if(consoleOutput != null && consoleOutput.Length > 0)
					{
						// HACK: Console output is being redirected.
						Trace.Write(consoleOutput);
					}

					TDF.TestResult summary = new TDF.TestResult();
					summary.TotalTests = this.testCount;
					switch(e.TestIteration.State)
					{
						case AUC.TestState.Pass:
							summary.State = TDF.TestState.Passed;
							break;
						case AUC.TestState.Fail:
							summary.State = TDF.TestState.Failed;
							break;
						case AUC.TestState.Ignore:
						case AUC.TestState.Untested:
						case AUC.TestState.ForcedIgnore:
						default:
							summary.State = TDF.TestState.Ignored;
							break;
					}
					summary.StackTrace = e.TestIteration.FullStackTrace;
					summary.Message = e.TestIteration.Result;
					summary.Name = e.TestIteration.Name;  // HACK: Should be full test name.
					summary.TimeSpan = TimeSpan.FromSeconds(e.TestIteration.Duration);
					this.testListener.TestFinished(summary);
				}

			}

			private void dispatcher_TestSuiteCompleted(object sender, TestAssemblyResult[] tar)
			{
				//Console.WriteLine(new Adapdev.UnitTest.Core.TextFormatter(tar).GetText());
			}
		}

		interface ITestSuiteFilter
		{
			void Filter(TestSuite suite);
		}

		class NoFilter : ITestSuiteFilter
		{
			public void Filter(TestSuite suite)
			{
			}
		}

		class NamespaceFilter : ITestSuiteFilter
		{
			string ns;

			public NamespaceFilter(string ns)
			{
				this.ns = ns;
			}

			public void Filter(TestSuite suite)
			{
				if (this.ns.Length > 0)
				{
					string prefix = this.ns + ".";
					foreach (TestAssembly testAssembly in suite.GetTestAssemblies())
					{
						foreach (TestFixture testFixture in testAssembly.GetTestFixtures())
						{
							if (!toFullName(testFixture).StartsWith(prefix))
							{
								testFixture.ShouldRun = false;
							}
						}
					}
				}
			}
		}

		class TypeFilter : ITestSuiteFilter
		{
			Type type;

			public TypeFilter(Type type)
			{
				this.type = type;
			}

			public void Filter(TestSuite suite)
			{
				foreach (TestAssembly testAssembly in suite.GetTestAssemblies())
				{
					foreach (TestFixture testFixture in testAssembly.GetTestFixtures())
					{
						if (toFullName(testFixture) != this.type.FullName)
						{
							testFixture.ShouldRun = false;
						}
					}
				}
			}
		}

		class MethodFilter : ITestSuiteFilter
		{
			MethodInfo method;

			public MethodFilter(MethodInfo method)
			{
				this.method = method;
			}

			public void Filter(TestSuite suite)
			{
				Type type = this.method.ReflectedType;
				foreach (TestAssembly testAssembly in suite.GetTestAssemblies())
				{
					foreach (TestFixture testFixture in testAssembly.GetTestFixtures())
					{
						if (toFullName(testFixture) != type.FullName)
						{
							testFixture.ShouldRun = false;
						}
						else
						{
							foreach (Test test in testFixture.GetTests())
							{
								if (test.Method != method.Name)
								{
									test.ShouldRun = false;
								}
							}
						}
					}
				}
			}
		}

        static string toFullName(TestFixture testFixture)
        {
            string fullName = "";
            if (testFixture.Namespace != null && testFixture.Namespace.Length > 0)
            {
                fullName += testFixture.Namespace + ".";
            }
            fullName += testFixture.Class;
            return fullName;
        }
    }
}
