Adapdev.NVelocity is a modified version of the NVelocity project (http://nvelocity.sourceforge.net/).

The following changes have taken place:
- Switched to Adapdev.NET library version
- Signed with Adapdev.NET key
- Removed Html portions of library
- Removed logging portions of library
- Fixed issue with relative file path references in #parse call