namespace NVelocity.Context
{
	/// <summary>
	/// interface for internal context wrapping functionality
	/// </summary>
	/// <author> <a href="mailto:geirm@optonline.net">Geir Magnusson Jr.</a></author>
	/// <version> $Id: InternalWrapperContext.cs,v 1.5 2005/11/16 07:01:49 intesar66 Exp $ </version>
	public interface InternalWrapperContext
	{
		/// <summary>
		/// returns the wrapped user context 
		/// </summary>
		IContext InternalUserContext { get; }

		/// <summary>
		/// returns the base full context impl 
		/// </summary>
		InternalContextAdapter BaseContext { get; }

	}
}