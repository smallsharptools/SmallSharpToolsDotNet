namespace NVelocity.Context
{
	/// <summary>  interface to bring all necessary internal and user contexts together.
	/// this is what the AST expects to deal with.  If anything new comes
	/// along, add it here.
	/// *
	/// I will rename soon :)
	/// *
	/// </summary>
	/// <author> <a href="mailto:geirm@optonline.net">Geir Magnusson Jr.</a>
	/// </author>
	/// <version> $Id: InternalContextAdapter.cs,v 1.5 2005/11/16 07:01:49 intesar66 Exp $
	/// 
	/// </version>
	public interface InternalContextAdapter : InternalHousekeepingContext, IContext, InternalWrapperContext, InternalEventContext
	{
	}
}