namespace NVelocity.Runtime.Resource
{
	using System;
	using System.Collections;

	/// <summary> Default implementation of the resource cache for the default
	/// ResourceManager.
	/// *
	/// </summary>
	/// <author> <a href="mailto:geirm@apache.org">Geir Magnusson Jr.</a>
	/// </author>
	/// <author> <a href="mailto:dlr@finemaltcoding.com">Daniel Rall</a>
	/// </author>
	/// <version> $Id: ResourceCacheImpl.cs,v 1.5 2005/11/16 07:01:51 intesar66 Exp $
	/// 
	/// </version>
	public class ResourceCacheImpl : ResourceCache
	{
		/// <summary> 
		/// Cache storage, assumed to be thread-safe.
		/// </summary>
		//UPGRADE_NOTE: The initialization of  'cache' was moved to method 'InitBlock'. 'ms-help://MS.VSCC/commoner/redir/redirect.htm?keyword="jlca1005"'
		protected internal Hashtable cache = new Hashtable();

		/// <summary>
		/// Runtime services, generally initialized by the
		/// <code>initialize()</code> method.
		/// </summary>
		protected internal RuntimeServices rsvc = null;

		public ResourceCacheImpl()
		{
		}

		public virtual void initialize(RuntimeServices rs)
		{
			rsvc = rs;

			rsvc.info("ResourceCache : initialized. (" + this.GetType() + ")");
		}

		public virtual Resource get(Object key)
		{
			return (Resource) cache[key];
		}

		public virtual Resource put(Object key, Resource value_Renamed)
		{
			Object o = cache[key];
			cache[key] = value_Renamed;
			return (Resource) o;
		}

		public virtual Resource remove(Object key)
		{
			Object o = cache[key];
			cache.Remove(key);
			return (Resource) o;
		}

		public virtual IEnumerator enumerateKeys()
		{
			return cache.Keys.GetEnumerator();
		}
	}
}