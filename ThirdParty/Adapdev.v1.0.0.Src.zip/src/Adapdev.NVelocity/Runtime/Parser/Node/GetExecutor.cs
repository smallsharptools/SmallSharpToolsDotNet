namespace NVelocity.Runtime.Parser.Node
{
	using System;
	using System.Reflection;
	using NVelocity.Context;
	using NVelocity.Exception;

	/// <summary>
	/// Executor that simply tries to execute a get(key)
	/// operation. This will try to find a get(key) method
	/// for any type of object, not just objects that
	/// implement the Map interface as was previously
	/// the case.
	/// </summary>
	/// <author> <a href="mailto:jvanzyl@apache.org">Jason van Zyl</a></author>
	public class GetExecutor : AbstractExecutor
	{
		/// <summary>
		/// Container to hold the 'key' part of get(key).
		/// </summary>
		private Object[] args = new Object[1];

		/// <summary>
		/// Default constructor.
		/// </summary>
		public GetExecutor(RuntimeServices r, Type c, String key)
		{
			rsvc = r;
			args[0] = key;

			// NOTE: changed from get to get to get_Item - assumption is that get would be converted to an indexer in .Net
			// to keep some resembalance to the Java version, look for "Get" and "get" methods as well (both cases for .Net style and java)
			method = rsvc.Introspector.getMethod(c, "get_Item", args);
			if (method == null)
			{
				method = rsvc.Introspector.getMethod(c, "Get", args);
				if (method == null)
				{
					method = rsvc.Introspector.getMethod(c, "get", args);
				}
			}
		}

		/// <summary>
		/// Execute method against context.
		/// </summary>
		public override Object execute(Object o, InternalContextAdapter context)
		{
			if (method == null)
				return null;

			try
			{
				return method.Invoke(o, (Object[]) args);
			}
			catch (TargetInvocationException ite)
			{
				/*
		*  the method we invoked threw an exception.
		*  package and pass it up
		*/
				throw new MethodInvocationException("Invocation of method 'get(\"" + args[0] + "\")'" + " in  " + o.GetType() + " threw exception " + ite.GetBaseException().GetType(), ite.GetBaseException(), "get");
			}
			catch (ArgumentException)
			{
				return null;
			}
		}
	}
}