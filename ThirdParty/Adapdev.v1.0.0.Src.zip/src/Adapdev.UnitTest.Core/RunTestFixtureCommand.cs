using System;
using System.Collections;
using System.Reflection;
using System.Threading;
using Adapdev.Commands;
using Adapdev.Threading;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestFixtureCommand.
	/// </summary>
	public class RunTestFixtureCommand : IThreadWorkItemCommand
	{
		private TestEventDispatcher _dispatcher = null;
		private TestFixture _testFixture = null;
		private Assembly _assembly = null;
		private string _className = String.Empty;
		private TestFixtureResult _testFixtureResult = null;
		private TestFixtureIteration _testFixtureIteration = null;
		private Type _type = null;
		private object _o = null;

		public RunTestFixtureCommand(TestEventDispatcher dispatcher, TestFixture tf, Assembly assembly, string className, TestFixtureResult testFixtureResult)
		{
			this._dispatcher = dispatcher;
			//if(tf.IsMultiThreaded) this._dispatcher = null;
			this._testFixture = tf;
			this._assembly = assembly;
			this._className = className;
			this._testFixtureResult = testFixtureResult;
		}

		public void Execute()
		{
			if (!this._testFixture.Ignore && this._testFixture.ShouldRun)
			{
				if(_dispatcher != null && !_testFixture.IsMultiThreaded)_dispatcher.OnTestFixtureStarted(new TestFixtureEventArgs(this._testFixture));
				for (int j = 1; j <= this._testFixture.RepeatCount; j++)
				{
					this._type = null;
					this._testFixtureIteration = null;

					if (this._testFixture.RepeatDelay > 0) Thread.Sleep(this._testFixture.RepeatDelay);
					this._testFixtureIteration = new TestFixtureIteration();
					if(_dispatcher != null)this._dispatcher.OnTestFixtureIterationStarted(new TestFixtureEventArgs(this._testFixture));

					this._o = this._assembly.CreateInstance(this._className);
					this._type = this._assembly.GetType(this._className, true);

					this.RunTestFixtureSetUps(this._testFixture, this._o, this._type);

					RunTests();

					this.RunTestFixtureTearDowns(this._testFixture, this._o, this._type);
					this._testFixtureIteration.Iteration = j;
					this._testFixtureResult.AddIteration(this._testFixtureIteration);
					if(_dispatcher != null)_dispatcher.OnTestFixtureIterationCompleted(new TestFixtureIterationEventArgs(this._testFixtureIteration));
				}
				if(_dispatcher != null)_dispatcher.OnTestFixtureCompleted(new TestFixtureResultEventArgs(this._testFixtureResult));
			}
		}

		protected void RunTestFixtureSetUps(TestFixture tf, object instance, Type type)
		{
			foreach (BaseTestHelper t in tf.GetFixtureSetUps())
			{
				try
				{
					if(_dispatcher != null)_dispatcher.OnBaseTestHelperStarted(new BaseTestHelperEventArgs(t));
					MethodInfo m = type.GetMethod(t.Method);
					m.Invoke(instance, null);
				}
				catch (Exception e)
				{
					Console.Write(e);
				}
			}
		}

		protected void RunTestFixtureTearDowns(TestFixture tf, object instance, Type type)
		{
			foreach (BaseTestHelper t in tf.GetFixtureTearDowns())
			{
				try
				{
					if(_dispatcher != null)_dispatcher.OnBaseTestHelperStarted(new BaseTestHelperEventArgs(t));
					MethodInfo m = type.GetMethod(t.Method);
					m.Invoke(instance, null);
				}
				catch (Exception e)
				{
					Console.Write(e);
				}
			}
		}

		private void RunTests()
		{
			if(this._testFixture.IsMultiThreaded)
			{
				ArrayList threads = new ArrayList();

				foreach (Test test in this._testFixture.GetTests())
				{
					RunTestCommand command = new RunTestCommand(this._dispatcher, test, this._testFixture, this._type, this._o, this._testFixtureIteration);
					Thread t = new Thread(new ThreadStart(command.Execute));
					t.IsBackground = true;
					t.Priority = ThreadPriority.Highest;
					threads.Add(t);
					t.Start();
				}
				foreach(Thread t in threads) t.Join(30000);

			}
			else
			{
				foreach (Test test in this._testFixture.GetTests())
				{
					new RunTestCommand(this._dispatcher, test, this._testFixture, this._type, this._o, this._testFixtureIteration).Execute();
				}
			}
		}

		public object Execute(object o)
		{
			this.Execute();
			return 1;
		}
	}
}
