using System;
using System.Collections;
using System.IO;
using Adapdev;

namespace Adapdev.UnitTest.Core
{
	using System.Reflection;

	public class LocalSeparateTestEngine : ITestEngine
	{
		private TestSuite suite = null;
		private AppDomainManager manager;
		private string assembly;
		private TestEventDispatcher dispatcher = null;
		private bool disposed = false;
		private bool unloaded = false;
		private readonly string testlib = Assembly.GetExecutingAssembly().GetName().FullName;
		private string _log = String.Empty;

		public LocalSeparateTestEngine(string assembly) : this(AppDomain.CurrentDomain.BaseDirectory, assembly){}

		public LocalSeparateTestEngine(string basedir, string assembly)
		{
			FileInfo file = new FileInfo(assembly);
			try
			{
				if(file.Directory.GetFiles(file.Name + ".config").Length > 0)
				{
					manager = new AppDomainManager(basedir, Path.Combine(file.Directory.FullName, file.Name + ".config"), new string[]{assembly});
				}
				else
				{
					manager = new AppDomainManager(basedir, String.Empty, new string[]{assembly});
				}
			}
			catch(Exception ex)
			{
				this._log += "Couldn't load AppDomainManager" + Environment.NewLine;
				this._log += ex.Message + Environment.NewLine;
				this._log += ex.StackTrace + Environment.NewLine;
			}
			manager.AddAssembly(assembly);
			this.assembly = assembly;
		}

		public LocalSeparateTestEngine(string basedir, string configurationFile, string assembly)
		{
			try
			{
				manager = new AppDomainManager(basedir, configurationFile, new string[]{assembly});
			}
			catch(Exception ex)
			{
				this._log += "Couldn't load AppDomainManager" + Environment.NewLine;
				this._log += ex.Message + Environment.NewLine;
				this._log += ex.StackTrace + Environment.NewLine;
			}
			manager.AddAssembly(assembly);
			this.assembly = assembly;
		}

		public TestAssemblyResult[] Run()
		{
			TestRunner tr = manager.GetObjectByName(testlib, "Adapdev.UnitTest.Core.TestRunner") as TestRunner;
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(suite);
		}

		public TestAssemblyResult[] Run(TestSuite ts)
		{
			TestRunner tr = manager.GetObjectByName(testlib, "Adapdev.UnitTest.Core.TestRunner") as TestRunner;
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(ts);
		}

		public TestAssemblyResult Run(TestAssembly ta)
		{
			TestRunner tr = manager.GetObjectByName(testlib, "Adapdev.UnitTest.Core.TestRunner") as TestRunner;
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(ta);
		}

		public TestSuite GetTestSuite()
		{
			try
			{
				TestSuiteBuilder builder = manager.GetObjectByName(testlib, "Adapdev.UnitTest.Core.TestSuiteBuilder") as TestSuiteBuilder;
				TestSuite suite = builder.BuildAssemblies(new string[]{this.assembly});
				this._log += builder.Log;
				return suite;
			}
			catch(Exception ex)
			{
				this._log += ex.Message;
				this._log += ex.StackTrace;
			}
			return null;
		}

		public TestAssembly GetTestAssembly()
		{
			try
			{
				TestSuiteBuilder builder = manager.GetObjectByName(testlib, "Adapdev.UnitTest.Core.TestSuiteBuilder") as TestSuiteBuilder;
				TestAssembly assembly = builder.BuildAssembly(this.assembly);
				this._log += builder.Log;
				return assembly;
			}
			catch(Exception ex)
			{
				this._log += ex.Message;
				this._log += ex.StackTrace;
			}
			return null;
		}

		public IList GetLoadedAssemblies()
		{
			ArrayList al = new ArrayList();
			AssemblyInfo[] loaded = manager.GetLoadedAssemblies();
			foreach(AssemblyInfo assembly in loaded)
			{
				al.Add(assembly);								
			}
			return al;
		}

		public TestSuite Suite
		{
			get { return suite; }
		}

		public void SetTestEventDispatcher(TestEventDispatcher dispatcher)
		{
			this.dispatcher = dispatcher;
		}

		public void ShutDown()
		{
			this.manager.Unload();
			this.unloaded = true;
		}

		public string ConfigurationFile
		{
			get { return this.manager.Domain.SetupInformation.ConfigurationFile; }
		}

		public string Log
		{
			get { return this._log; }
		}

		public void Dispose()
		{
			if(!this.unloaded)
			{
				this.ShutDown();
				Dispose(true);
			}
			GC.SuppressFinalize(this);
		}

		private void Dispose(bool disposing)
		{
			// Check to see if Dispose has already been called.
			if(!this.disposed)
			{
				// If disposing equals true, dispose all managed 
				// and unmanaged resources.
				if(disposing)
				{
					// Dispose managed resources.
					this.ShutDown();
				}
			}
			disposed = true;         
		}
	}
}
