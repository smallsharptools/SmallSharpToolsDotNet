using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestSummary.
	/// </summary>
	public class TestSummary
	{
		private TestAssemblyResult[] tar = null;

		public TestSummary(TestAssemblyResult[] tar)
		{
			this.tar = tar;
		}

		public int TotalFailed
		{
			get
			{
				int total = 0;

				foreach (TestAssemblyResult testAssemblyResult in tar)
				{
					total += testAssemblyResult.Failed;
				}
				return total;
			}
		}

		public int TotalPassed
		{
			get
			{
				int total = 0;

				foreach (TestAssemblyResult testAssemblyResult in tar)
				{
					total += testAssemblyResult.Passed;
				}
				return total;
			}
		}

		public int TotalIgnored
		{
			get
			{
				int total = 0;

				foreach (TestAssemblyResult testAssemblyResult in tar)
				{
					total += testAssemblyResult.Ignored;
				}
				return total;
			}		
		}

		public double PercentPassed
		{
			get
			{
				int passed = this.TotalPassed;
				int failed = this.TotalFailed;
				if ((passed + failed) > 0)
					return (Convert.ToDouble(passed)/Convert.ToDouble(passed + failed));
				else
					return 0;			
			}
		}

		public double PercentFailed
		{
			get{return 1 - this.PercentPassed;}
		}

		public double TotalDuration
		{
			get
			{
				double duration = 0;
				foreach(TestAssemblyResult t in this.tar)
				{
					duration += t.GetTotalDuration();
				}
				return duration;
			}	

		}
	}
}
