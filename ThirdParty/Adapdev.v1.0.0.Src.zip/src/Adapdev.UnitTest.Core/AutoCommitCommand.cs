using System;
using Adapdev.Commands;
using Adapdev.Transactions;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for AutoCommitTestCommand.
	/// </summary>
	public class AutoCommitCommand : IThreadWorkItemCommand
	{
		private ICommand _command;

		public AutoCommitCommand(ICommand command)
		{
			this._command = command;
		}
		#region ICommand Members

		public void Execute()
		{
			using(TransactionScope transction = new TransactionScope())
			{
				this._command.Execute();
			}
		}

		#endregion

		public object Execute(object o){this.Execute();return 1;}

	}
}
