using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Reflection;

	/// <summary>
	/// Summary description for TypeHelper.
	/// </summary>
	public class TypeHelper
	{
		private static Hashtable attributeList = new Hashtable();

		public static bool HasCustomAttribute(ICustomAttributeProvider t, Type customAttributeType)
		{
			if (t == null)
				throw new ArgumentNullException("t");
			if (customAttributeType == null)
				throw new ArgumentNullException("customAttributeType");

			return t.GetCustomAttributes(customAttributeType, true).Length != 0;
		}

		public static Object GetFirstCustomAttribute(ICustomAttributeProvider mi, Type customAttributeType)
		{
			if (mi == null)
				throw new ArgumentNullException("mi");
			if (customAttributeType == null)
				throw new ArgumentNullException("customAttributeType");

			Object[] attrs = mi.GetCustomAttributes(customAttributeType, true);
			if (attrs.Length == 0)
				throw new ArgumentException("type does not have custom attribute");
			return attrs[0];
		}

		public static HybridDictionary PopulateAttributes(ICustomAttributeProvider mi)
		{
			if(mi == null)
			{
				throw new ArgumentNullException("mi");
			}

			object[] attributes = mi.GetCustomAttributes(true);
			System.Collections.Specialized.HybridDictionary attributeList = new HybridDictionary(attributes.Length);

			foreach(Attribute a in attributes)
			{
				attributeList[a.GetType().FullName] = null;
			}

			return attributeList;
		}
	}
}