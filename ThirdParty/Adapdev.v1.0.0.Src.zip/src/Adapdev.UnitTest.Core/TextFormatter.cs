using System;
using System.Text;

namespace Adapdev.UnitTest.Core
{
	using System.Diagnostics;

	/// <summary>
	/// Summary description for TextFormatter.
	/// </summary>
	public class TextFormatter : IResultFormatter
	{
		private StringBuilder sb = new StringBuilder();

		public TextFormatter(TestAssemblyResult[] results, bool showDetails, bool showOutput, bool showFailures)
		{
			FormatResults(results, showDetails, showOutput, showFailures);
		}

		public TextFormatter(TestAssemblyResult[] results)
		{
			FormatResults(results, true, false, false);
		}

		internal void FormatResults(TestAssemblyResult[] results, bool showDetails, bool showOutput, bool showFailures)
		{
			Debug.Assert(results != null);
			sb.Append("\r\nDATE: " + DateTime.Now.ToString() + "\r\n");
			foreach (TestAssemblyResult assemblyResult in results)
			{
				if(assemblyResult != null)
				{
					sb.Append("========================================\r\n");
					sb.Append(assemblyResult.Name + "\r\n");
					sb.Append("========================================\r\n");
					sb.Append(assemblyResult.Location + "\r\n");
					sb.AppendFormat("Passed: {0}\r\n" +
						"Failed: {1}\r\n" + 
						"Ignored: {2}\r\n" +
						"Percent Passed: {3}\r\n" +
						"Avg Duration: {4}\r\n" +
						"Total Duration: {5}\r\n" +
						"# of Iterations: {6}\r\n",
						assemblyResult.Passed,
						assemblyResult.Failed,
						assemblyResult.Ignored,
						assemblyResult.PercentPassed.ToString("P"),
						assemblyResult.GetAverageDuration(),
						assemblyResult.GetTotalDuration(),
						assemblyResult.GetTotalIterations());
					sb.Append("\r\n");
					if(showDetails) this.GetDetailedSummary(assemblyResult, showOutput, showFailures);
					sb.Append("\r\n");
				}

			}
			sb.Append(this.GetSummary(results));
		}

		internal string GetSummary(TestAssemblyResult[] tar)
		{
			Debug.Assert(tar != null);
			TestSummary ts = new TestSummary(tar);
			sb.Append("========================================\r\n");
			sb.Append("SUMMARY\r\n");
			sb.Append("========================================\r\n");
			return String.Format("Passed: {0}\t\tFailed: {1}\t\tIgnored: {2}\r\nPercent Passed: {3}\t\r\nTime:{4}s\r\n", 
				ts.TotalPassed, 
				ts.TotalFailed, 
				ts.TotalIgnored, 
				ts.PercentPassed.ToString("P"),
				ts.TotalDuration);
		}

		internal string GetDetailedSummary(AbstractTestResult tar, bool showOutput, bool showFailure)
		{
			return this.GetDetailedSummary(tar, showOutput,showFailure, 0);
		}

		internal string GetDetailedSummary(AbstractTestResult tar, bool showOutput, bool showFailure, int nesting)
		{
			Debug.Assert(tar != null);
			if(!(tar.State == TestState.Ignore))
			{
				if(tar.Iterations.Count > 1) nesting += 1;
				foreach(AbstractTestIteration ati in tar.Iterations)
				{
					if(tar.Iterations.Count > 1)
					{
						sb.Append(this.GetNesting(nesting) + "Iteration: " + ati.Iteration + "\r\n");
					}
					sb.AppendFormat(this.GetNesting(nesting + 1) + this.GetMarker(tar) + "{0} - {1}\r\n", tar.Name, tar.State);
					//sb.AppendFormat(this.GetNesting(nesting + 1) + this.GetMarker(tar) + "Time: {0}s\r\n", tar.GetTotalDuration());
					if((tar is TestResult) && ((tar as TestResult).Description.Length > 0))
					{
						sb.AppendFormat(this.GetNesting(nesting + 2) + "Description: {0}\r\n", (tar as TestResult).Description);
					}

					if(ati is TestIteration)
					{
						sb.Append(this.GetNesting(nesting + 2) + "Thread Id: " + (ati as TestIteration).Thread + Environment.NewLine);
						sb.Append(this.GetNesting(nesting + 2) + "Time: " + (ati as TestIteration).Duration + Environment.NewLine);
					}

					if(showFailure && (ati is TestIteration))
					{
						TestIteration ti = ati as TestIteration;
						if(ti.Result.Length > 0) sb.Append(this.GetOutput("Result: " + this.GetDivider() + ti.Result + "\r\n", nesting + 2));
						if(ti.FullStackTrace.Length > 0) sb.Append(this.GetOutput("StackTrace: " + this.GetDivider() + ti.FullStackTrace + "\r\n", nesting + 2));
					}


					if(showOutput && ati.ConsoleOutput.Length > 0)
					{
						sb.Append(this.GetOutput("Output: " + this.GetDivider() + ati.AllOutput, nesting + 2));
					}


					if(ati is CompositeAbstractTestIteration)
					{
						foreach(AbstractTestResult result in (ati as CompositeAbstractTestIteration).GetTestResults())
						{ 
							this.GetDetailedSummary(result, showOutput, showFailure, nesting + 1);
						}
					}
				}
			}
			return "";
		}

		private string GetNesting(int nesting)
		{
			string t = "";
			for(int i = 0; i < nesting; i++)
			{
				t+="\t";
			}
			return t;
		}

		private string GetOutput(string output, int nesting)
		{
			string s = String.Empty;
			output = "\r\n" + output;
			s = output.Replace("\r\n", "\r\n" + this.GetNesting(nesting));
			return s + "\r\n";
		}

		private string GetMarker(AbstractTestResult atr)
		{
			if(atr is TestAssemblyResult) return "+++";
			if(atr is TestFixtureResult) return "++";
			if(atr is TestResult) return "+";
			return "";
		}

		private string GetDivider()
		{
			return "\r\n-----------------------------\r\n";
		}

		#region IResultFormatter Members

		public string GetText()
		{
			return sb.ToString();
		}

		#endregion
	}
}
