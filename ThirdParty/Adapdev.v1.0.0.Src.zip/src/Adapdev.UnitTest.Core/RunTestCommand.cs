using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Adapdev.Commands;
using Adapdev.Diagnostics;
using Adapdev.Threading;
using log4net;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for NonThreadedRunTestCommand.
	/// </summary>
	public class RunTestCommand : ICommand
	{
		// create the logger
		private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		// setup the logging levels
		private bool _debugMode = log.IsDebugEnabled;
		private bool _infoMode = log.IsInfoEnabled;


		private TestEventDispatcher _dispatcher = null;
		private Test _test = null;
		private TestFixture _testFixture = null;
		private Type _type = null;
		private object o = null;
		private TestFixtureIteration _testFixtureIteration = null;

		public RunTestCommand(TestEventDispatcher dispatcher, Test test, TestFixture tf, Type type, object o, TestFixtureIteration tfi)
		{
			this._dispatcher = dispatcher;
			//if(test.IsMultiThreaded || tf.IsMultiThreaded) this._dispatcher = null;
			this._test = test;
			this._testFixture = tf;
			this.o = o;
			this._testFixtureIteration = tfi;
			this._type = type;
		}

		public void Execute()
		{
			try
			{
				MethodInfo m = _type.GetMethod(_test.Method);
				TestResult tr = new TestResult(_test);
				tr.TestId = _test.Id;
				tr.Description = _test.Description;

				if(this._debugMode) log.Debug("Running T " + _test.Name);

				if (!_test.Ignore && _test.ShouldRun)
				{

					if(_dispatcher != null)_dispatcher.OnTestStarted(new TestEventArgs(_test));
					this.RunTestIteration(tr, m);

				}
				else
				{
					TestIteration ti = new TestIteration();
					ti.Name = _test.Name;
					ti.State = TestState.Ignore;
					ti.Result = _test.IgnoreReason;
					tr.AddIteration(ti);
				}

				if (_testFixture.ShouldShow) _testFixtureIteration.AddTestResult(tr);
				if(_dispatcher != null)_dispatcher.OnTestCompleted(new TestResultEventArgs(tr));
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message + " " + e.StackTrace);
			}
			finally
			{
			}
		}

		private void RunTestIteration(TestResult testResult, MethodInfo method)
		{
			if(this._testFixture.IsMultiThreaded)
			{
				ArrayList threads = new ArrayList();

				for (int i = 1; i <= _test.RepeatCount; i++)
				{
					RunTestIterationCommand command = new RunTestIterationCommand(this._dispatcher, this._test, this._testFixture, this._type, this.o, this._testFixtureIteration, method, i, testResult);
					Thread t = new Thread(new ThreadStart(command.Execute));
					threads.Add(t);
					t.Start();
				}
				foreach(Thread t in threads) t.Join(30000);
			}			
			else
			{
				if(this._test.ShouldRun)
				{
					for (int i = 1; i <= _test.RepeatCount; i++)
					{
						new RunTestIterationCommand(this._dispatcher, this._test, this._testFixture, this._type, this.o, this._testFixtureIteration, method, i, testResult).Execute();
					}
				}
			}
		}


		public void Execute(object o){this.Execute();}
	}
}
