using System;
using System.Collections;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for CompositeAbstractTestIteration.
	/// </summary>
	/// 
	[Serializable]
	public class CompositeAbstractTestIteration : AbstractTestIteration
	{
		protected Hashtable _results = new Hashtable();

		public void AddTestResult(AbstractTestResult tr)
		{
			this._results[tr.Name] = tr;
			if (tr.State == TestState.Fail) this._state = TestState.Fail;
			if (this._state != TestState.Fail)
			{
				if (tr.State == TestState.Pass) this._state = TestState.Pass;
			}
		}

		public ICollection GetTestResults()
		{
			return this._results.Values;
		}

		public override double Duration
		{
			get
			{
				double d = 0;

				foreach (AbstractTestResult tr in this.GetTestResults())
				{
					d += tr.GetTotalDuration();
				}

				return d;
			}
		}

		public AbstractTestResult GetTestResult(string name)
		{
			return this._results[name] as AbstractTestResult;
		}
	}
}
