using System;
using Adapdev.Commands;
using Adapdev.Transactions;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for AutoRollbackCommand.
	/// </summary>
	public class AutoRollbackCommand : IThreadWorkItemCommand
	{
		private ICommand _command;

		public AutoRollbackCommand(ICommand command)
		{
			this._command = command;
		}
		#region ICommand Members

		public void Execute()
		{
			using(TransactionScope transaction = new TransactionScope())
			{
				this._command.Execute();
				transaction.Abort();
			}
		}

		#endregion

		public object Execute(object o){this.Execute();return 1;}

	}
}
