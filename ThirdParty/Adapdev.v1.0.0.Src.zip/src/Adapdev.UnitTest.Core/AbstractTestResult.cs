#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;

	/// <summary>
	/// Summary description for AbstractTestResult.
	/// </summary>
	/// 
	[Serializable]
	public class AbstractTestResult
	{
		protected ArrayList _iterations = new ArrayList();
		protected string _name = "";
		protected TestState _state = TestState.Untested;
		protected int _id = 0;

		/// <summary>
		/// Gets or sets the iterations.
		/// </summary>
		/// <value></value>
		public ArrayList Iterations
		{
			get { return this._iterations; }
			set { this._iterations = value; }
		}

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value></value>
		public string Name
		{
			get { return this._name; }
			set { this._name = value; }
		}

		/// <summary>
		/// Gets or sets the state.
		/// </summary>
		/// <value></value>
		public TestState State
		{
			get { return this._state; }
			set { this._state = value; }
		}

		/// <summary>
		/// Adds the iteration.
		/// </summary>
		/// <param name="ti">Ti.</param>
		public void AddIteration(AbstractTestIteration ti)
		{
			this._iterations.Add(ti);
			if (ti.State == TestState.Fail)
			{
				this._state = TestState.Fail;
			}
			else if (this.State != TestState.Fail && ti.State != TestState.Ignore && ti.State != TestState.ForcedIgnore)
			{
				this._state = TestState.Pass;
			}
			else if (this.State != TestState.Fail && this.State != TestState.Pass && (ti.State == TestState.Ignore || ti.State == TestState.ForcedIgnore))
			{
				this._state = TestState.Ignore;
			}
		}

		/// <summary>
		/// Gets the iteration.
		/// </summary>
		/// <param name="i">I.</param>
		/// <returns></returns>
		public AbstractTestIteration GetIteration(int i)
		{
			return (AbstractTestIteration) this._iterations[i];
		}

		/// <summary>
		/// Gets the child abstract test result.
		/// </summary>
		/// <param name="iteration">Iteration.</param>
		/// <param name="name">Name.</param>
		/// <returns></returns>
		public AbstractTestResult GetChildAbstractTestResult(int iteration, string name)
		{
			AbstractTestIteration a = this.GetIteration(iteration);
			if(a is CompositeAbstractTestIteration)
			{
				return (a as CompositeAbstractTestIteration).GetTestResult(name);
			}
			else
			{
				throw new ApplicationException("This AbstractTestResult contains no child results.");
			}
		}

		/// <summary>
		/// Gets the all child abstract test results.
		/// </summary>
		/// <returns></returns>
		public ArrayList GetAllChildAbstractTestResults()
		{
			ArrayList results = new ArrayList();
			foreach(AbstractTestIteration a in this.Iterations)
			{
				if(a is CompositeAbstractTestIteration)
				{
					results.AddRange((a as CompositeAbstractTestIteration).GetTestResults());
				}
			}
			return results;
		}

		/// <summary>
		/// Gets the all child abstract test results.
		/// </summary>
		/// <param name="name">Name.</param>
		/// <returns></returns>
		public ArrayList GetAllChildAbstractTestResults(string name)
		{
			ArrayList results = new ArrayList();
			foreach(AbstractTestIteration a in this.Iterations)
			{
				if(a is CompositeAbstractTestIteration)
				{
					results.Add((a as CompositeAbstractTestIteration).GetTestResult(name));
				}
			}
			return results;
		}

		/// <summary>
		/// Gets the total number of iterations.
		/// </summary>
		/// <returns></returns>
		public int GetTotalIterations()
		{
			return this._iterations.Count;
		}

		/// <summary>
		/// Gets the average duration.
		/// </summary>
		/// <returns></returns>
		public double GetAverageDuration()
		{
			return this.GetTotalDuration()/this._iterations.Count;
		}

		/// <summary>
		/// Gets the total duration.
		/// </summary>
		/// <returns></returns>
		public double GetTotalDuration()
		{
			double d = 0;

			foreach (AbstractTestIteration ti in this._iterations)
			{
				d += ti.Duration;
			}
			return d;
		}

		/// <summary>
		/// Gets or sets the test id.
		/// </summary>
		/// <value></value>
		public int TestId
		{
			get { return this._id; }
			set { this._id = value; }
		}

		/// <summary>
		/// Gets the number of passed tests.
		/// </summary>
		/// <value></value>
		public int Passed
		{
			get
			{
				int total = 0;
				foreach(AbstractTestIteration ati in this._iterations)
				{
					if(ati is CompositeAbstractTestIteration)
					{
						foreach(AbstractTestResult atr in (ati as CompositeAbstractTestIteration).GetTestResults())
						{
							total += atr.Passed;
						}
					}
					else
					{
						if(ati.State == TestState.Pass)total++;
					}
				}
				return total;
			}
		}

		/// <summary>
		/// Gets the number of failed tests.
		/// </summary>
		/// <value></value>
		public int Failed
		{
			get
			{
				int total = 0;
				foreach(AbstractTestIteration ati in this._iterations)
				{
					if(ati is CompositeAbstractTestIteration)
					{
						foreach(AbstractTestResult atr in (ati as CompositeAbstractTestIteration).GetTestResults())
						{
							total += atr.Failed;
						}
					}
					else
					{
						if(ati.State == TestState.Fail)total++;
					}
				}
				return total;
			}
		}

		/// <summary>
		/// Gets the number of ignored tests.
		/// </summary>
		/// <value></value>
		public int Ignored
		{
			get
			{
				int total = 0;
				foreach(AbstractTestIteration ati in this._iterations)
				{
					if(ati is CompositeAbstractTestIteration)
					{
						foreach(AbstractTestResult atr in (ati as CompositeAbstractTestIteration).GetTestResults())
						{
							total += atr.Ignored;
						}
					}
					else
					{
						if(ati.State == TestState.Ignore)total++;
					}
				}
				return total;
			}
		}

		/// <summary>
		/// Gets the percent passed.
		/// </summary>
		/// <value></value>
		public double PercentPassed
		{
			get
			{
				int passed = this.Passed;
				int failed = this.Failed;
				if ((passed + failed) > 0)
					return (Convert.ToDouble(passed)/Convert.ToDouble(passed + failed));
				else
					return 0;
			}
		}

		/// <summary>
		/// Gets the percent failed.
		/// </summary>
		/// <value></value>
		public double PercentFailed
		{
			get{return 1 - this.PercentPassed;}
		}
	}
}