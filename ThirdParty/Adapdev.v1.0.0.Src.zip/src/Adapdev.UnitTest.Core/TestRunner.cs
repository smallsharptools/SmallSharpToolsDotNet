using System.Text;
using Adapdev.Reflection;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;
	using System.Diagnostics;
	using System.IO;
	using System.Reflection;
	using System.Threading;
	using Adapdev;
	using Adapdev.Diagnostics;
	using log4net;
	using NUnit.Framework;

	public delegate double ThreadedTestHandler(MethodInfo method, object o);

	/// <summary>
	/// Summary description for RemoteTestRunner.
	/// </summary>
	/// 
	public class TestRunner : LongLivingMarshalByRefObject
	{
		#region Instance variables

		private TestEventDispatcher _dispatcher = null;
		private RunMode _mode = RunMode.NotRunning;

		// create the logger
		private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		// setup the logging levels
		private bool _debugMode = log.IsDebugEnabled;
		private bool _infoMode = log.IsInfoEnabled;

		private IPerfTimer timer = PerfTimerFactory.GetPerfTimer(PerfTimerType.HIRESSECONDS);

		#endregion

		#region Properties


		public RunMode RunMode
		{
			get { return this._mode; }
		}

		#endregion

		#region Public Methods

		public TestSuite BuildSuite(params string[] assemblies)
		{
			TestSuiteBuilder builder = new TestSuiteBuilder();
			return builder.BuildAssemblies(assemblies);
		}

		public TestAssembly BuildAssembly(string assembly)
		{
			TestSuiteBuilder builder = new TestSuiteBuilder();
			return builder.BuildAssembly(assembly);
		}

		public void SetTestEventDispatcher(TestEventDispatcher dispatcher)
		{
			this._dispatcher = dispatcher;
		}

		public TestAssemblyResult[] Run(TestSuite ts)
		{
			Thread.CurrentThread.ApartmentState = ApartmentState.MTA;
			this._mode = RunMode.Running;
			ArrayList al = new ArrayList();
	
			foreach (TestAssembly ta in ts.GetTestAssemblies())
			{
				if (ta.ShouldRun && !ta.Ignore)
				{
					TestAssemblyResult tarr = this.Run(ta);
					al.Add(tarr);
				}
			}

			al.TrimToSize();
			TestAssemblyResult[] tar = al.ToArray(typeof(TestAssemblyResult)) as TestAssemblyResult[];

			this._mode = RunMode.NotRunning;
			if(_dispatcher != null)this._dispatcher.OnTestSuiteCompleted(tar);
			return tar;
		}

		public TestAssemblyResult Run(TestAssembly ta)
		{
			string orig = Environment.CurrentDirectory;
			Environment.CurrentDirectory = ta.Location;

			TestAssemblyResult tar = new TestAssemblyResult(ta);
			tar.TestId = ta.Id;
			tar.AssemblyFullName = ta.AssemblyFullName;
			tar.AssemblyName = ta.AssemblyName;
			tar.Location = ta.Location;

			if(_dispatcher != null) _dispatcher.OnTestAssemblyStarted(new TestAssemblyEventArgs(ta));
			for (int i = 1; i <= ta.RepeatCount; i++)
			{
				if (ta.RepeatDelay > 0) Thread.Sleep(ta.RepeatDelay);
				TestAssemblyIteration tai = new TestAssemblyIteration();
				
				if(_dispatcher != null)this._dispatcher.OnTestAssemblyIterationStarted(new TestAssemblyEventArgs(ta));

				foreach (TestFixture tf in ta.GetTestFixtures())
				{
					if (tf != null && tf.ShouldRun && !tf.Ignore)
					{
							TestFixtureResult tfr = this.Run(tf);
							tai.AddTestResult(tfr);
					}
				}
				
				if(_dispatcher != null)_dispatcher.OnTestAssemblyIterationCompleted(new TestAssemblyIterationEventArgs(tai));
				

				tai.Iteration = i;
				tar.AddIteration(tai);
			}

			try{if(_dispatcher != null)_dispatcher.OnTestAssemblyCompleted(new TestAssemblyResultEventArgs(tar));}
			catch(Exception){}

			Environment.CurrentDirectory = orig;
			return tar;
		}

		public TestFixtureResult Run(TestFixture tf)
		{
			TestFixtureResult testFixtureResult = new TestFixtureResult(tf);

			try
			{
				testFixtureResult.TestId = tf.Id;
				string assembly = (tf.Parent.OriginalPath);
				string classname = tf.Namespace + "." + tf.Class;
				object o = new object();
				Assembly a = AssemblyCache.Get(tf.Parent.OriginalPath);

				RunTestFixture(tf, a, classname, testFixtureResult);
			}
			catch (Exception e)
			{
				testFixtureResult.State = TestState.Fail;
			}
			return testFixtureResult;
		}

		private void RunTestFixture(TestFixture tf, Assembly a, string classname, TestFixtureResult testFixtureResult)
		{
			new RunTestFixtureCommand(this._dispatcher, tf, a, classname, testFixtureResult).Execute();
		}

		public TestResult Run(Test t)
		{
			return null;
		}



		public void SetConsole(TextWriter tw)
		{
			Console.SetOut(tw);
		}

		public void SetConsoleError(TextWriter tw)
		{
			Console.SetError(tw);
		}

		public void SetDebug(TextWriter tw)
		{
			Debug.Listeners.Add(new TextWriterTraceListener(tw));
		}

		public void SetTrace(TextWriter tw)
		{
			Trace.Listeners.Add(new TextWriterTraceListener(tw));
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns>AssemblyList</returns>
		public IList GetAssemblies()
		{
			ArrayList al = new ArrayList();
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly a in assemblies)
			{
				AssemblyInfo ai = new AssemblyInfo();
				ai.Name = a.GetName().Name;
				ai.Version = a.GetName().Version.ToString();
				ai.FullName = a.FullName;
				ai.Location = a.Location;
				ai.CodeBase = a.CodeBase;
				al.Add(ai);
			}
			return al;
		}

		#endregion
	}

	public enum RunMode
	{
		Running,
		NotRunning
	}
}