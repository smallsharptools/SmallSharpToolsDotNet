using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestEngineType.
	/// </summary>
	public enum TestEngineType
	{
		Local,
		LocalSeparate
	}
}
