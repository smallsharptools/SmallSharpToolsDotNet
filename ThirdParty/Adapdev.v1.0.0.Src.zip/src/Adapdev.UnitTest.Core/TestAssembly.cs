using System.ComponentModel;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;

	/// <summary>
	/// Summary description for TestAssembly.
	/// </summary>
	/// 
	[Serializable]
	public class TestAssembly : AbstractTest
	{
		protected Hashtable _fixtures = new Hashtable();
		protected string _assemblyName = String.Empty;
		protected string _assemblyFullName = String.Empty;
		protected TestSuite _parent = null;
		protected string _path = String.Empty;
		protected string _location = String.Empty;
		protected string _original = String.Empty;
		protected string _configFile = String.Empty;

		public TestAssembly()
		{
		}

		public TestAssembly(string name)
		{
			this.AssemblyName = name;
			this.Name = name;
		}

		public string ConfigFile
		{
			get { return _configFile; }
			set { _configFile = value; }
		}

		public string Path
		{
			get { return this._path; }
			set { this._path = value; }
		}

		public string AssemblyName
		{
			get { return this._assemblyName; }
			set { this._assemblyName = value; }
		}

		public string AssemblyFullName
		{
			get { return this._assemblyFullName; }
			set { this._assemblyFullName = value; }
		}

		public string OriginalPath
		{
			get{return this._original;}
			set{this._original = value;}
		}

		[Browsable(false)]
		public TestSuite Parent
		{
			get { return this._parent; }
			set { this._parent = value; }
		}

		public string Location
		{
			get { return this._location; }
			set { this._location = value; }
		}

		public void AddTestFixture(TestFixture tf)
		{
			if (tf != null) this._fixtures[tf.Id] = tf;
		}

		public void RemoveTestFixture(TestFixture tf)
		{
			if (tf != null) this._fixtures.Remove(tf.Id);
		}

		public void RemoveTestFixture(string id)
		{
			this._fixtures.Remove(id);
		}

		public override int GetTestCount()
		{
			if (!this.Ignore)
			{
				int count = 0;
				foreach (TestFixture t in this.GetTestFixtures())
				{
					if(t.ShouldRun && !t.Ignore)
					{
						count += t.GetTestCount();
					}
				}
				return count*this.RepeatCount;
			}
			else
			{
				return 0;
			}
		}

		public ICollection GetTestFixtures()
		{
			return this._fixtures.Values;
		}

	}
}