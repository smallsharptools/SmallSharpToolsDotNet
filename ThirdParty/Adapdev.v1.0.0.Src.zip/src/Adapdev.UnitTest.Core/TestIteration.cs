#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;

	/// <summary>
	/// Summary description for TestIteration.
	/// </summary>
	/// 
	[Serializable]
	public class TestIteration : AbstractTestIteration
	{
		protected string _result = "";
		protected string _exceptionType = "";
		protected string _stackTrace = "";
		protected string _thread = "";
		protected long _k = 0;

		public TestIteration()
		{
		}

		public string Result
		{
			get { return this._result; }
			set { this._result = value; }
		}

		public string ExceptionType
		{
			get { return this._exceptionType; }
			set { this._exceptionType = value; }
		}

		public string FullStackTrace
		{
			get { return this._stackTrace; }
			set { this._stackTrace = value; }
		}

		public string Thread
		{
			get { return this._thread; }
			set { this._thread = value; }
		}

		public long MemoryUsed
		{
			get
			{
				if (this._k > 0) return this._k;
				else return 0;
			}
			set { this._k = value; }
		}

		public double GetOpsPerSecond()
		{
			if (this.Duration > 0)
			{
				return 1/this.Duration;
			}
			else
			{
				return 0;
			}
		}
	}
}