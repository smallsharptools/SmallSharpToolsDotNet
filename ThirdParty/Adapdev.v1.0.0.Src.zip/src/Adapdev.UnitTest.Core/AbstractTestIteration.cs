#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Text;

	/// <summary>
	/// Summary description for AbstractTestIteration.
	/// </summary>
	/// 
	[Serializable]
	public class AbstractTestIteration
	{
		protected string _category = "";
		protected double _duration;
		protected TestState _state = TestState.Untested;
		protected string _consoleOutput = "";
		protected string _consoleError = "";
		protected string _debugOutput = "";
		protected string _traceOutput = "";
		protected int _iteration = 0;
		protected string _name = String.Empty;

		public string ConsoleError
		{
			get { return _consoleError; }
			set { _consoleError = value; }
		}

		public string DebugOutput
		{
			get { return _debugOutput; }
			set { _debugOutput = value; }
		}

		public string TraceOutput
		{
			get { return _traceOutput; }
			set { _traceOutput = value; }
		}

		public string ConsoleOutput
		{
			get { return _consoleOutput; }
			set { _consoleOutput = value; }
		}

		public string AllOutput
		{
			get
			{
				StringBuilder sb = new StringBuilder();
				if(this._consoleError.Length > 0)
				{
					sb.Append(this._consoleError);
					sb.Append("\r\n");
				}
				if(this._consoleOutput.Length > 0)
				{
					sb.Append(this._consoleOutput);
					sb.Append("\r\n");
				}
				if(this._debugOutput.Length > 0)
				{
					sb.Append(this._debugOutput);
					sb.Append("\r\n");
				}
				if(this._traceOutput.Length > 0)
				{
					sb.Append(this._traceOutput);
					sb.Append("\r\n");
				}
				return sb.ToString();
			}
		}

		public string Category
		{
			get { return this._category; }
			set { this._category = value; }
		}

		public virtual double Duration
		{
			get { return this._duration; }
			set { this._duration = value; }
		}

		public TestState State
		{
			get { return this._state; }
			set { this._state = value; }
		}

		public int Iteration
		{
			get {return this._iteration;}
			set {this._iteration = value;}
		}

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

	}
}