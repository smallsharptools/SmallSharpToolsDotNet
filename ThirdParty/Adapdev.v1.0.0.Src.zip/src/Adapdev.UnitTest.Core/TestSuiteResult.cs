using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestSuiteResult.
	/// </summary>
	public class TestSuiteResult : AbstractTestResult
	{
		
	}
}
