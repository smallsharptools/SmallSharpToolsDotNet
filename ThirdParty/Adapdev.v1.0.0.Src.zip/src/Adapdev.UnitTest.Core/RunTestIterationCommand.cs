using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Adapdev.Commands;
using Adapdev.Diagnostics;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for RunTestIterationCommand.
	/// </summary>
	public class RunTestIterationCommand : IThreadWorkItemCommand
	{
		private TestEventDispatcher _dispatcher = null;
		private Test _test = null;
		private TestFixture _testFixture = null;
		private object o = null;
		private int i = 0;
		private Type _type = null;
		private TestFixtureIteration _testFixtureIteration = null;
		private MethodInfo _method = null;
		private IPerfTimer timer = PerfTimerFactory.GetPerfTimer(PerfTimerType.HIRESSECONDS);
		private TestResult tr = null;

		public RunTestIterationCommand(TestEventDispatcher dispatcher, Test test, TestFixture tf, Type type, object o, TestFixtureIteration tfi, MethodInfo method, int iteration, TestResult tr)
		{
			this._dispatcher = dispatcher;
			this._test = test;
			this._testFixture = tf;
			this.o = o;
			this.i = iteration;
			this._type = type;
			this._testFixtureIteration = tfi;
			this._method = method;
			this.tr = tr;
		}

		public void Execute()
		{
			TextWriter consoleOut = Console.Out;
			TextWriter errorOut = Console.Error;
			StringWriter consoleWriter = new StringWriter();
			StringWriter errorWriter = new StringWriter();
			StringWriter debugWriter = new StringWriter();
			StringWriter traceWriter = new StringWriter();

			Console.SetOut(consoleWriter);
			Console.SetError(errorWriter);
			TextWriterTraceListener debug = new TextWriterTraceListener(debugWriter);
			TextWriterTraceListener error = new TextWriterTraceListener(traceWriter);
			Debug.Listeners.Add(debug);
			Trace.Listeners.Add(error);


			if (_test.RepeatDelay > 0)
			{
				Thread.Sleep(_test.RepeatDelay);
				Console.WriteLine("Sleeping..." + _test.RepeatDelay);
			}
			TestIteration ti = new TestIteration();
			ti.Name = _test.Name;
			ti.Iteration = i;
			ti.Thread = AppDomain.GetCurrentThreadId().ToString();
			long kStart = 0;
			long kEnd = 0;
			if(_dispatcher != null)_dispatcher.OnTestIterationStarted(new TestEventArgs(_test));

			try
			{
				this.RunTestSetUps(_dispatcher, _testFixture, _test.Name, o, _type);
				kStart = Process.GetCurrentProcess().WorkingSet;
				timer.Start();
								
				// Check for transactions and run
				ICommand command = new RunMethodCommand(this._method, o);	
				if(this._test.TransactionType == TransactionType.AutoCommit) command = new AutoCommitCommand(command);
				if(this._test.TransactionType == TransactionType.AutoRollback) command = new AutoRollbackCommand(command);
				command.Execute();

									
				timer.Stop();
				ti.Duration = timer.Duration;
				kEnd = Process.GetCurrentProcess().WorkingSet;
				ti.MemoryUsed = (kEnd - kStart)/1024;

				if (_test.MaxKMemory > 0 && _test.MaxKMemory < ti.MemoryUsed)
				{
					ti.State = TestState.Fail;
					ti.Result = "Memory usage exceeded MaxK limit of " + _test.MaxKMemory;
				}
				else if (_test.MinOperationsPerSecond > 0 && ti.GetOpsPerSecond() < _test.MinOperationsPerSecond)
				{
					ti.State = TestState.Fail;
					ti.Result = "Ops per second was less than minimum limit of " + _test.MinOperationsPerSecond;
				}
				else if (_test.ExpectedExceptionType != null && _test.ExpectedExceptionType.Length > 0)
				{
					ti.State = TestState.Fail;
					ti.Result = "ExceptedException type " + _test.ExpectedExceptionType + " was not thrown.";
				}
				else
				{
					ti.State = TestState.Pass;
				}

				this.RunTestTearDowns(_dispatcher, _testFixture, _test.Name, o, _type);
			}
			catch (Exception e)
			{
				timer.Stop();
				ti.Duration = timer.Duration;
				kEnd = Process.GetCurrentProcess().WorkingSet;
				if (_test.ExpectedExceptionType != null && _test.ExpectedExceptionType.Length > 0)
				{
					Type t = null;
					foreach(Assembly ass in AppDomain.CurrentDomain.GetAssemblies())
					{
						try
						{
							t = ass.GetType(_test.ExpectedExceptionType, true, true);
							break;
						}
						catch(Exception){}
					}

					if(t == null) throw new TypeLoadException("Unable to locate " + _test.ExpectedExceptionType + ".  Please make sure it is correct.");
					if (e.InnerException.GetType().IsSubclassOf(t) || e.InnerException.GetType() == t)
					{
						if(_test.ExpectedExceptionMessage != null && _test.ExpectedExceptionMessage.Length > 0)
						{
							if(_test.ExpectedExceptionMessage.ToLower() == e.InnerException.Message.ToLower())
							{
								ti.Result = "Expected Exception: " + _test.ExpectedExceptionType + " was thrown.  Message: " + e.InnerException.Message;
								ti.State = TestState.Pass;
							}
							else
							{
								ti.Result = "Expected Exception: " + _test.ExpectedExceptionType + " was thrown, but wrong message.  Message: " + e.InnerException.Message + " - Expected: " + _test.ExpectedExceptionMessage;
								ti.State = TestState.Fail;
							}
						}
						else
						{
							ti.Result = "Expected Exception: " + _test.ExpectedExceptionType + " was thrown.  Message: " + e.InnerException.Message;
							ti.State = TestState.Pass;
						}
					}
					else
					{
						ti.Result = "Expected Exception: " + _test.ExpectedExceptionType + " was NOT thrown.  Message: " + e.InnerException.Message;
						ti.State = TestState.Fail;
					}
					ti.ExceptionType = e.InnerException.GetType().FullName;
					ti.FullStackTrace = this.FilterAdapdev(e.InnerException.StackTrace);
					ti.MemoryUsed = (kEnd - kStart)/1024;

				}
					// TODO : Fix incrementing of tests in GUI when IgnoreException is thrown
				else if(e.InnerException.GetType() == typeof(IgnoreException) || e.InnerException.GetType() == typeof(IgnoreException))
				{
					ti.Result = e.InnerException.Message;
					ti.State = TestState.ForcedIgnore;
					ti.ExceptionType = e.InnerException.GetType().FullName;
					ti.FullStackTrace = this.FilterAdapdev(e.InnerException.StackTrace);
				}
				else
				{
					ti.Result = e.InnerException.Message;
					ti.ExceptionType = e.InnerException.GetType().FullName;
					ti.FullStackTrace = this.FilterAdapdev(e.InnerException.StackTrace);
					ti.State = TestState.Fail;
				}
				this.RunTestTearDowns(_dispatcher, _testFixture, _test.Name, o, _type);
			}

			ti.ConsoleOutput = consoleWriter.ToString();
			ti.ConsoleError = errorWriter.ToString();
			ti.DebugOutput = debugWriter.ToString();
			ti.TraceOutput = traceWriter.ToString();

			lock(this)
			{
				tr.AddIteration(ti);
				if(_dispatcher != null)_dispatcher.OnTestIterationCompleted(new TestIterationEventArgs(ti));
			}

			Console.SetOut(consoleOut);
			Console.SetError(errorOut);
			Debug.Listeners.Remove(debug);
			Trace.Listeners.Remove(error);

			debug.Dispose();
			error.Dispose();
			
		}

		protected void RunTestSetUps(TestEventDispatcher _dispatcher, TestFixture tf, string name, object instance, Type type)
		{
			foreach (TestHelper t in tf.GetTestSetUps())
			{
				try
				{
					if (t.Test.Length < 1 || t.Test.ToLower().Equals(name.ToLower()))
					{
						if(_dispatcher != null)_dispatcher.OnBaseTestHelperStarted(new BaseTestHelperEventArgs(t));
						MethodInfo m = type.GetMethod(t.Method);
						m.Invoke(instance, null);
					}
				}
				catch (Exception e)
				{
					Console.Write(e);
				}
			}
		}

		protected void RunTestTearDowns(TestEventDispatcher _dispatcher, TestFixture tf, string name, object instance, Type type)
		{
			foreach (TestHelper t in tf.GetTestTearDowns())
			{
				try
				{
					if (t.Test.Length < 1 || t.Test.ToLower().Equals(name.ToLower()))
					{
						if(_dispatcher != null)_dispatcher.OnBaseTestHelperStarted(new BaseTestHelperEventArgs(t));
						MethodInfo m = type.GetMethod(t.Method);
						m.Invoke(instance, null);
					}
				}
				catch (Exception e)
				{
					Console.Write(e);
				}
			}
		}

		private string FilterAdapdev(string exception)
		{
			int last = exception.LastIndexOf("Adapdev.UnitTest.Assert");
			
			// make sure it's present
			if(last > -1)
			{
				int line = exception.IndexOf("   at", last);

				// make sure it's present
				if(line > -1 && line > last && line < exception.Length)
					return exception.Substring(line, exception.Length - line);
				else
					return exception;
			}
			else
			{
				return exception;
			}
		}


		public object Execute(object o){this.Execute();return 1;}
	}
}
