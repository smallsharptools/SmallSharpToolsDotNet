using System.ComponentModel;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;

	/// <summary>
	/// Summary description for TestInfo.
	/// </summary>
	/// 
	[Serializable]
	public class Test : TestUnit
	{
		protected string _description = "";
		protected bool _fixtureSetup = false;
		protected bool _fixtureTearDown = false;
		protected bool _testSetUp = false;
		protected bool _testTearDown = false;
		protected string _method = "";
		protected string _category = "";
		protected string _exceptionType = null;
		protected string _exceptionMessage = null;
		protected TestFixture _parent = null;
		protected TestType _testType = TestType.Unit;

		public Test()
		{
		}
	
		public string Description
		{
			get{ return this._description;}
			set{ this._description = value;}
		}

		public TestType TestType
		{
			get{return this._testType;}
			set{this._testType = value;}
		}

		public string ExpectedExceptionType
		{
			get{return this._exceptionType;}
			set { this._exceptionType = value; }
		}

		public string ExpectedExceptionMessage
		{
			get{return this._exceptionMessage;}
			set{this._exceptionMessage = value;}
		}

		[Browsable(false)]
		public bool IsFixtureSetUp
		{
			get { return this._fixtureSetup; }
			set { this._fixtureSetup = value; }
		}

		[Browsable(false)]
		public bool IsFixtureTearDown
		{
			get { return this._fixtureTearDown; }
			set { this._fixtureTearDown = value; }

		}

		[Browsable(false)]
		public bool IsTestSetUp
		{
			get { return this._testSetUp; }
			set { this._testSetUp = value; }

		}

		[Browsable(false)]
		public bool IsTestTearDown
		{
			get { return this._testTearDown; }
			set { this._testTearDown = value; }
		}

		[Browsable(false)]
		public TestFixture Parent
		{
			get { return this._parent; }
			set { this._parent = value; }
		}

		public void SetTestFixture(TestFixture tfi)
		{
			this._parent = _parent;
		}

		[Browsable(false)]
		public string Method
		{
			get { return this._method; }
			set { this._method = value; }
		}

		public string Category
		{
			get { return this._category; }
			set { this._category = value; }
		}

		public override int GetTestCount()
		{
			if (!this.Ignore)
			{
				return this.RepeatCount;
			}
			else
			{
				return 0;
			}
		}


	}
}