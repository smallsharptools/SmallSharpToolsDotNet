using System.Collections.Specialized;
using System.Diagnostics;
using System.Text;
using Adapdev.Reflection;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;
	using System.IO;
	using System.Reflection;
	using log4net;
	using NUnit.Framework;

	/// <summary>
	/// Summary description for TestSuiteBuilder.
	/// </summary>
	public class TestSuiteBuilder : MarshalByRefObject
	{
		// list of assembly dependencies for the current assembly
		private Hashtable dependencyList = new Hashtable();
		private Hashtable loadedList = new Hashtable();
		// create the logger
		private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
		private StringBuilder sb = new StringBuilder();

		public static string DependencyLog = String.Empty;

		public TestSuite BuildAssemblies(params string[] assemblies)
		{
			TestSuite ts = new TestSuite();

			foreach(string assemblyName in assemblies)
			{
				try
				{
					ts.AddTestAssembly(this.BuildAssembly(assemblyName));
				}
				catch(FileNotFoundException ex)
				{
					sb.Append("Assembly couldn't be found: " + assemblyName + Environment.NewLine);
				}
			}

			return ts;
		}

		public TestAssembly BuildAssembly(string assemblyName)
		{
			// set delegate to probe for an assembly when it's not found in the base path
			AppDomain.CurrentDomain.AssemblyResolve +=new ResolveEventHandler(CurrentDomain_AssemblyResolve);
			AppDomain.CurrentDomain.AssemblyLoad += new AssemblyLoadEventHandler(CurrentDomain_AssemblyLoad);

			// switch the current directory to the assemblies location
			// needed to find related files for the specified assembly
			FileInfo fi = new FileInfo(assemblyName);
			string orig = Environment.CurrentDirectory;
			Environment.CurrentDirectory = fi.DirectoryName;
			sb.Append("Building assembly: " + assemblyName + Environment.NewLine);
			sb.Append("Environment Directory: " + Environment.CurrentDirectory + Environment.NewLine);
			sb.Append("Assembly Directory: " + fi.DirectoryName + Environment.NewLine);

			// add the assembly to the AssemblyCache
			Assembly assembly = AssemblyCache.Add(assemblyName.ToLower(), assemblyName);
			// find any assembly dependencies
			this.FindDependencies(assembly, dependencyList);

			sb.Append("Dependencies loaded.");

			// Build the TestAssembly information
			TestAssembly ta = new TestAssembly();
			try
			{
				ta.AssemblyName = fi.Name;
				ta.AssemblyFullName = assembly.FullName;
				ta.FullName = assembly.GetName().Name;
				ta.Name = assembly.GetName().Name;
				ta.Path = assembly.Location;
				ta.Location = fi.DirectoryName;
				ta.OriginalPath = assemblyName;

				// Build the TestFixtures
				foreach (Type t in assembly.GetExportedTypes())
				{
					sb.Append("***Loading " + t.Name + Environment.NewLine);
					try
					{
						ta.AddTestFixture(this.BuildTestFixture(t, ta, assembly));
					}
					catch(Exception ex)
					{
						sb.Append("Can't create TestFixture: " + t.Name + Environment.NewLine);
						sb.Append("Message: " + ex.Message + Environment.NewLine);
					}
				}

				// restore the original environment
				Environment.CurrentDirectory = orig;

				//sb.Append(Environment.NewLine + Environment.NewLine);
				sb.Append(ta.ToString());
			}
			catch (Exception e)
			{
				log.Error("Unable to create TestAssembly", e);
				sb.Append("Can't create test assembly: " + fi.Name + Environment.NewLine);
				sb.Append("Message: " + e.Message + Environment.NewLine);
			}
			return ta;
		}

		public TestFixture BuildTestFixture(Type t, TestAssembly ta, Assembly a)
		{
			HybridDictionary fd = TypeHelper.PopulateAttributes(t);
			if(fd.Count == 0) sb.Append("NO ATTRIBUTES");

			foreach(string attr in fd.Keys)
			{
				sb.Append("ATTRIBUTE: " + attr + Environment.NewLine);
			}

			Adapdev.UnitTest.Core.TestFixture tf = null;
			if(fd.Contains("Adapdev.UnitTest.TestFixtureAttribute") || fd.Contains("NUnit.Framework.TestFixtureAttribute"))
			{
				try
				{
					sb.Append("Building TestFixture " + t.FullName + Environment.NewLine);

					// Build the TestFixture
					tf = new Adapdev.UnitTest.Core.TestFixture();
					tf.Parent = ta;
					tf.Class = t.Name;
					tf.Name = t.Name;
					tf.Namespace = t.Namespace;
					tf.FullName = t.FullName;

					if (fd.Contains("Adapdev.UnitTest.TestFixtureAttribute"))
					{
						Adapdev.UnitTest.TestFixtureAttribute tfa = (Adapdev.UnitTest.TestFixtureAttribute) TypeHelper.GetFirstCustomAttribute(t, typeof (Adapdev.UnitTest.TestFixtureAttribute));
						tf.IsMultiThreaded = tfa.IsMultiThreaded;
					}


					this.ProcessCommonAttributes(fd, t, tf);

					foreach (MethodInfo mi in t.GetMethods())
					{
						HybridDictionary md = TypeHelper.PopulateAttributes(mi);
						if (md.Contains("Adapdev.UnitTest.TestAttribute")
							|| md.Contains("NUnit.Framework.TestAttribute"))
						{
							sb.Append("Building Test " + mi.Name + Environment.NewLine);
							tf.AddTest(this.BuildTest(mi, tf));
						}
						else if (md.Contains("Adapdev.UnitTest.TestFixtureSetUpAttribute")
							|| md.Contains("NUnit.Framework.TestFixtureSetUpAttribute"))
						{
							sb.Append("Building TestFixtureSetUp " + mi.Name + Environment.NewLine);
							tf.AddFixtureSetUp(this.BuildBaseTestHelper(mi, tf));
						}
						else if (md.Contains("Adapdev.UnitTest.TestFixtureTearDownAttribute")
							|| md.Contains("NUnit.Framework.TestFixtureTearDownAttribute"))
						{
							sb.Append("Building TestFixtureTearDown " + mi.Name + Environment.NewLine);
							tf.AddFixtureTearDown(this.BuildBaseTestHelper(mi, tf));
						}
						else if (md.Contains("Adapdev.UnitTest.TestSetUpAttribute")
							|| md.Contains("Adapdev.UnitTest.SetUpAttribute")
							|| md.Contains("NUnit.Framework.SetUpAttribute")
							)
						{
							sb.Append("Building TestSetUp " + mi.Name + Environment.NewLine);
							tf.AddTestSetUp(this.BuildTestHelper(md, mi, tf));
						}
						else if (md.Contains("Adapdev.UnitTest.TestTearDownAttribute")
							|| md.Contains("Adapdev.UnitTest.TearDownAttribute")
							|| md.Contains("NUnit.Framework.TearDownAttribute")
							)
						{
							sb.Append("Building TestTearDown " + mi.Name + Environment.NewLine);
							tf.AddTestTearDown(this.BuildTestHelper(md, mi, tf));
						}
					}
					////sb.Append(tf.ToString());
				}
				catch(Exception ex)
				{
					log.Error("Problem loading TestFixture", ex);
					sb.Append("Problem loading TestFixture: " + tf.Name + Environment.NewLine);
					sb.Append("Message: " + ex.Message + Environment.NewLine);

				}
			}

			return tf;
		}

		public Test BuildTest(MethodInfo m, TestFixture tf)
		{
			Test t = new Test();
			t.Parent = tf;
			t.Method = m.Name;
			t.Name = m.Name;
			t.FullName = tf.FullName + "." + m.Name;

			HybridDictionary md = TypeHelper.PopulateAttributes(m);
			this.ProcessTestAttribute(md, m, t);
			this.ProcessCommonAttributes(md, m, t);
			this.ProcessExpectedExceptionAttribute(md, m, t);
			this.ProcessCategoryAttribute(md, m, t);
			this.ProcessMaxKAttribute(md, m, t);
			this.ProcessMinOperationsPerSecondAttribute(md, m, t);
			this.ProcessTransactionAttribute(md, m, t);

			sb.Append("Test built: " + t.Name + Environment.NewLine);
			return t;
		}

		public BaseTestHelper BuildBaseTestHelper(MethodInfo m, TestFixture tf)
		{
			BaseTestHelper t = new BaseTestHelper();
			t.Method = m.Name;
			t.Name = m.Name;
			return t;
		}

		public TestHelper BuildTestHelper(HybridDictionary md, MethodInfo m, TestFixture tf)
		{
			TestHelper th = new TestHelper();
			th.Method = m.Name;
			th.Name = m.Name;
			this.ProcessTestSetUpAttribute(md, m, th);
			this.ProcessTestTearDownAttribute(md, m, th);
			return th;
		}

		public void ProcessCommonAttributes(HybridDictionary md, ICustomAttributeProvider m, AbstractTest t)
		{
			this.ProcessIgnoreAttribute(md, m, t);
			this.ProcessRepeatAttribute(md, m, t);
		}

		public void ProcessIgnoreAttribute(HybridDictionary md, ICustomAttributeProvider m, AbstractTest t)
		{
			if (md.Contains("Adapdev.UnitTest.IgnoreAttribute"))
			{
				Adapdev.UnitTest.IgnoreAttribute ia = (Adapdev.UnitTest.IgnoreAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (Adapdev.UnitTest.IgnoreAttribute));
				t.Ignore = true;
				t.IgnoreReason = ia.Reason;
			}
			else if (md.Contains("NUnit.Framework.IgnoreAttribute"))
			{
				NUnit.Framework.IgnoreAttribute ia = (NUnit.Framework.IgnoreAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (NUnit.Framework.IgnoreAttribute));
				t.Ignore = true;
				t.IgnoreReason = ia.Reason;
			}
			else if (md.Contains("NUnit.Framework.ExplicitAttribute"))
			{
				t.Ignore = true;
			}
			return;
		}

		public void ProcessRepeatAttribute(HybridDictionary md, ICustomAttributeProvider m, AbstractTest t)
		{
			if (md.Contains("Adapdev.UnitTest.RepeatAttribute"))
			{
				Adapdev.UnitTest.RepeatAttribute a = (Adapdev.UnitTest.RepeatAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (Adapdev.UnitTest.RepeatAttribute));
				t.Repeat = true;
				t.RepeatCount = a.RepeatCount;
				t.RepeatDelay = a.RepeatDelay;
			}
			return;
		}

		public void ProcessMaxKAttribute(HybridDictionary md, ICustomAttributeProvider m, AbstractTest t)
		{
			if (md.Contains("Adapdev.UnitTest.MaxKMemoryAttribute"))
			{
				MaxKMemoryAttribute a = (MaxKMemoryAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (MaxKMemoryAttribute));
				(t as Test).MaxKMemory = a.MaxK;
			}
			return;
		}

		public void ProcessMinOperationsPerSecondAttribute(HybridDictionary md, ICustomAttributeProvider m, AbstractTest t)
		{
			if (md.Contains("Adapdev.UnitTest.MinOperationsPerSecondAttribute"))
			{
				MinOperationsPerSecondAttribute a = (MinOperationsPerSecondAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (MinOperationsPerSecondAttribute));
				(t as Test).MinOperationsPerSecond = a.MinOps;
			}
			return;
		}

		public void ProcessExpectedExceptionAttribute(HybridDictionary md, ICustomAttributeProvider m, Test t)
		{
			if (md.Contains("Adapdev.UnitTest.ExpectedExceptionAttribute"))
			{
				Adapdev.UnitTest.ExpectedExceptionAttribute a =
					(Adapdev.UnitTest.ExpectedExceptionAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (Adapdev.UnitTest.ExpectedExceptionAttribute));

				t.ExpectedExceptionType = a.ExceptionType;
				t.ExpectedExceptionMessage = a.Message;
			}
			else if (md.Contains("NUnit.Framework.ExpectedExceptionAttribute"))
			{
				NUnit.Framework.ExpectedExceptionAttribute a =
					(NUnit.Framework.ExpectedExceptionAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (NUnit.Framework.ExpectedExceptionAttribute));

				t.ExpectedExceptionType = a.ExceptionType.FullName;
				t.ExpectedExceptionMessage = a.ExpectedMessage;
			}
			return;
		}

		public void ProcessTestAttribute(HybridDictionary md, ICustomAttributeProvider m, Test t)
		{
			if (md.Contains("Adapdev.UnitTest.TestAttribute"))
			{
				Adapdev.UnitTest.TestAttribute a =
					(Adapdev.UnitTest.TestAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (Adapdev.UnitTest.TestAttribute));

				t.Category = a.Category;
				t.Description = a.Description;
				t.TestType = a.TestType;
			}
			else if (md.Contains("NUnit.Framework.TestAttribute"))
			{
				NUnit.Framework.TestAttribute a =
					(NUnit.Framework.TestAttribute) TypeHelper.GetFirstCustomAttribute(m, typeof (NUnit.Framework.TestAttribute));
				if(a.Description != null) t.Description = a.Description;
			}

			return;
		}

		public void ProcessCategoryAttribute(HybridDictionary md, ICustomAttributeProvider m, Test t)
		{
			// Check for NUnit Category attribute
			if (md.Contains("NUnit.Framework.CategoryAttribute"))
			{
				NUnit.Framework.CategoryAttribute a = (NUnit.Framework.CategoryAttribute)TypeHelper.GetFirstCustomAttribute(m, typeof(NUnit.Framework.CategoryAttribute));
				t.Category = a.Name;
			}
		}

		public void ProcessTransactionAttribute(HybridDictionary md, ICustomAttributeProvider m, Test t)
		{
			if (md.Contains("Adapdev.UnitTest.TransactionAttribute"))
			{
				t.TransactionType = TransactionType.AutoCommit;
			}
			else if (md.Contains("Adapdev.UnitTest.RollbackTransactionAttribute"))
			{
				t.TransactionType = TransactionType.AutoRollback;
			}
		}

		public void ProcessTestSetUpAttribute(HybridDictionary md, ICustomAttributeProvider mi, TestHelper t)
		{
			if (md.Contains("Adapdev.UnitTest.TestSetUpAttribute")
				|| md.Contains("Adapdev.UnitTest.SetUpAttribute")
				)
			{
				Adapdev.UnitTest.TestSetUpAttribute a =
					(Adapdev.UnitTest.TestSetUpAttribute)
					TypeHelper.GetFirstCustomAttribute(mi, typeof (Adapdev.UnitTest.TestSetUpAttribute));
				t.Test = a.Test;
			}
			return;
		}

		public void ProcessTestTearDownAttribute(HybridDictionary md, ICustomAttributeProvider mi, TestHelper t)
		{
			if (md.Contains("Adapdev.UnitTest.TestTearDownAttribute")
				|| md.Contains("Adapdev.UnitTest.TearDownAttribute")
				)
			{
				Adapdev.UnitTest.TestTearDownAttribute a =
					(Adapdev.UnitTest.TestTearDownAttribute)
					TypeHelper.GetFirstCustomAttribute(mi, typeof (Adapdev.UnitTest.TestTearDownAttribute));
				t.Test = a.Test;
			}
			return;
		}

		public Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
		{
			string lostNamespace = args.Name.Split((",").ToCharArray())[0];
			string lostAssemblyFilename = Path.Combine(Environment.CurrentDirectory, lostNamespace + ".dll");
			Assembly a = null;

			sb.Append("Not found.  Trying to resolve " + lostAssemblyFilename + Environment.NewLine);
			try
			{
				a = Assembly.LoadFile(lostAssemblyFilename);
				if(a != null) 
					sb.Append("Found.  Loaded " + a.GetName().Name + " - " + a.GetName().Version + " - " + a.Location + Environment.NewLine);
			}
			catch(Exception ex)
			{
				sb.Append("Couldn't find: " + lostAssemblyFilename + Environment.NewLine);
				sb.Append(ex.Message + Environment.NewLine);
			}
			
			return a;
		}

		protected void FindDependencies(Assembly assembly, Hashtable dependencyList)
		{
			AssemblyName assemblyName = assembly.GetName();
			//sb.Append("Probing for: " + assemblyName + Environment.NewLine);
			if (! dependencyList.Contains(assemblyName.FullName))
			{
				dependencyList[assemblyName.FullName] = assemblyName.Name;
				foreach (AssemblyName name in assembly.GetReferencedAssemblies())
				{
					try
					{
						if(!this.loadedList.Contains(name))
						{
							Assembly referenced = Assembly.Load(name);
							if(referenced != null)
							{
								this.loadedList[name] = name;
								FindDependencies(referenced, dependencyList);
							}
						}
					}
					catch (Exception ex)
					{
						sb.Append("Error: " + ex.Message + Environment.NewLine);
					}
				}
			}
		}

		public void CurrentDomain_AssemblyLoad(object sender, AssemblyLoadEventArgs args)
		{
			sb.Append("Loading: " + args.LoadedAssembly.FullName + Environment.NewLine);
		}

		public string Log
		{
			get{return this.sb.ToString();}
		}
	}
}