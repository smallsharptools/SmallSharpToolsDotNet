using System;
using System.Collections;
using System.IO;
using Adapdev;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for LocalTestFacade.
	/// </summary>
	public class LocalTestEngine : ITestEngine
	{
		private TestSuite suite;
		private AppDomainManager manager;
		private string assembly;
		private TestEventDispatcher dispatcher = null;
		private string _log = String.Empty;

		public LocalTestEngine(string assembly)
		{
			manager = new AppDomainManager();
			manager.AddAssembly(assembly);
			this.assembly = assembly;
		}

		public TestAssemblyResult[] Run()
		{
			TestRunner tr = new TestRunner();
			this.suite = tr.BuildSuite(assembly);
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(suite);
		}

		public TestAssemblyResult[] Run(TestSuite ts)
		{
			TestRunner tr = new TestRunner();
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(ts);
		}

		public TestAssemblyResult Run(TestAssembly ta)
		{
			TestRunner tr = new TestRunner();
			if(this.dispatcher != null) tr.SetTestEventDispatcher(this.dispatcher);
			return tr.Run(ta);
		}

		public TestSuite GetTestSuite()
		{
			TestSuiteBuilder builder = new TestSuiteBuilder();
			TestSuite ts = builder.BuildAssemblies(this.assembly);
			this._log = builder.Log;
			return ts;
		}

		public TestAssembly GetTestAssembly()
		{
			TestSuiteBuilder builder = new TestSuiteBuilder();
			TestAssembly ta = builder.BuildAssembly(this.assembly);
			this._log = builder.Log;
			return ta;
		}

		public IList GetLoadedAssemblies()
		{
			ArrayList al = new ArrayList();
			AssemblyInfo[] loaded = manager.GetLoadedAssemblies();
			foreach(AssemblyInfo assembly in loaded)
			{
				al.Add(assembly);
			}
			return al;
		}

		public void SetTestEventDispatcher(TestEventDispatcher dispatcher)
		{
			this.dispatcher = dispatcher;
		}

		public TestSuite Suite
		{
			get { return suite; }
		}

		public void ShutDown()
		{
		}

		public void Dispose()
		{
		}

		public string ConfigurationFile
		{
			get { return this.manager.Domain.SetupInformation.ConfigurationFile; }
		}

		public string Log
		{
			get { return this._log; }
		}

	}
}
