using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for IResultFormatter.
	/// </summary>
	public interface IResultFormatter
	{
		string GetText();
	}
}
