using System;
using System.Collections;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestEngineFactory.
	/// </summary>
	public class TestEngineFactory
	{
		public static LocalTestEngine CreateLocal(string assembly)
		{
			return new LocalTestEngine(assembly);
		}

		public static LocalSeparateTestEngine CreateLocalSeparate(string assembly)
		{
			return new LocalSeparateTestEngine(assembly);
		}

		public static LocalSeparateTestEngine CreateLocalSeparate(string basedir, string assembly)
		{
			return new LocalSeparateTestEngine(basedir, assembly);
		}

		public static LocalSeparateTestEngine CreateLocalSeparate(string basedir, string configfile, string assembly)
		{
			return new LocalSeparateTestEngine(basedir, configfile, assembly);
		}
	}
}
