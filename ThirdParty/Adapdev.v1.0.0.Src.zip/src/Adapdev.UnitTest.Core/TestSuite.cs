#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;
	using Adapdev.IO;

	/// <summary>
	/// Summary description for TestSuite.
	/// </summary>
	/// 
	[Serializable]
	public class TestSuite
	{
		protected Hashtable _assemblies = new Hashtable();
		protected int failedTestCount = 0;
		protected int passedTestCount = 0;
		protected int ignoredTestCount = 0;
		protected double _duration = 0;

		public TestSuite(){}

		public void AddTestAssembly(TestAssembly ta)
		{
			this._assemblies[ta.Name] = ta;
		}

		public ICollection GetTestAssemblies()
		{
			return this._assemblies.Values;
		}

		public TestAssembly GetTestAssembly(string name)
		{
			return this._assemblies[name] as TestAssembly;
		}
		
		public int GetTestCount()
		{
			int count = 0;
			foreach (TestAssembly ta in this.GetTestAssemblies())
			{
				if(ta.ShouldRun && !ta.Ignore)
				{
					count += ta.GetTestCount();
				}
			}
			return count;
		}

		public int FailedTestCount
		{
			get { return this.failedTestCount; }
			set { this.failedTestCount = value; }
		}

		public int IgnoredTestCount
		{
			get { return this.ignoredTestCount; }
			set { this.ignoredTestCount = value; }
		}

		public int PassedTestCount
		{
			get { return this.passedTestCount; }
			set { this.passedTestCount = value; }
		}

		public double PercentPassed
		{
			get
			{
				if ((this.passedTestCount + this.failedTestCount) > 0)
					return (Convert.ToDouble(this.passedTestCount)/Convert.ToDouble(this.passedTestCount + this.failedTestCount));
				else
					return 0;
			}
		}

	}
}