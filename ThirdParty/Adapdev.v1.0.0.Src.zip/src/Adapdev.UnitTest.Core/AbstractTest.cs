using System.ComponentModel;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using Adapdev.Text;

	/// <summary>
	/// Summary description for AbstractTest.
	/// </summary>
	/// 
	[Serializable]
	public abstract class AbstractTest
	{
		protected bool _ignore = false;
		protected string _ignoreReason = "";
		protected int _sequence = 0;
		protected int _id = 0;
		protected bool _repeat = false;
		protected int _repeatCount = 1;
		protected int _repeatDelay = 0;
		protected string _name = "";
		protected bool _shouldRun = true;
		protected bool _shouldShow = true;
		protected TestState _testState = TestState.Untested;
		protected AbstractTestResult _result = null;
		protected string _fullName = String.Empty;
		private static int _globalid = 0;
		private bool _isMultiThreaded = false;


		public AbstractTest()
		{
			this._id = System.Threading.Interlocked.Increment(ref _globalid);
		}

		[Browsable(false)]
		public int SequenceNumber
		{
			get { return this._sequence; }
			set { this._sequence = value; }
		}

		public bool Repeat
		{
			get { return this._repeat; }
			set { this._repeat = value; }
		}

		public int RepeatCount
		{
			get { return this._repeatCount; }
			set { this._repeatCount = value; }
		}

		public int RepeatDelay
		{
			get { return this._repeatDelay; }
			set { this._repeatDelay = value; }
		}

		public bool Ignore
		{
			get { return this._ignore; }
			set { this._ignore = value; }
		}

		public string IgnoreReason
		{
			get { return this._ignoreReason; }
			set { this._ignoreReason = value; }
		}

		[Browsable(false)]
		public string Name
		{
			get { return this._name; }
			set { this._name = value; }
		}

		[Browsable(false)]
		public bool ShouldRun
		{
			get { return this._shouldRun; }
			set { this._shouldRun = value; }
		}

		[Browsable(false)]
		public bool ShouldShow
		{
			get { return this._shouldShow; }
			set { this._shouldShow = value; }
		}

		[Browsable(false)]
		public TestState State
		{
			get { return this._testState; }
			set { this._testState = value; }
		}

		[Browsable(false)]
		public AbstractTestResult Result
		{
			get { return this._result; }
			set { this._result = value; }
		}

		[Browsable(false)]
		public int Id
		{
			get { return this._id; }
			set { this._id = value; }
		}

		public override string ToString()
		{
			return StringUtil.ToString(this);
		}

		public void AcceptVisitor(AbstractTestVisitor atv)
		{
			atv.Visit(this);
		}

		[Browsable(false)]
		public string FullName
		{
			get{return this._fullName;}
			set{this._fullName = value;}
		}

		public bool IsMultiThreaded
		{
			get { return _isMultiThreaded; }
			set { _isMultiThreaded = value; }
		}

		public abstract int GetTestCount();
	}
}