#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

using Adapdev;

namespace Adapdev.UnitTest.Core
{
	public delegate void TestIterationStartedEventHandler(object sender, TestEventArgs e);

	public delegate void TestIterationCompletedEventHandler(object sender, TestIterationEventArgs e);

	public delegate void TestCompletedEventHandler(object sender, TestResultEventArgs e);

	public delegate void TestStartedEventHandler(object sender, TestEventArgs e);

	public delegate void TestFixtureCompletedEventHandler(object sender, TestFixtureResultEventArgs e);

	public delegate void TestFixtureStartedEventHandler(object sender, TestFixtureEventArgs e);

	public delegate void TestFixtureIterationStartedEventHandler(object sender, TestFixtureEventArgs e);

	public delegate void TestFixtureIterationCompletedEventHandler(object sender, TestFixtureIterationEventArgs e);

	public delegate void TestAssemblyIterationCompletedEventHandler(object sender, TestAssemblyIterationEventArgs e);

	public delegate void TestAssemblyIterationStartedEventHandler(object sender, TestAssemblyEventArgs e);

	public delegate void TestAssemblyCompletedEventHandler(object sender, TestAssemblyResultEventArgs e);

	public delegate void TestAssemblyStartedEventHandler(object sender, TestAssemblyEventArgs e);

	public delegate void ErrorEventHandler(object sender, ErrorEventArgs e);

	public delegate void BaseTestHelperStartedEventHandler(object sender, BaseTestHelperEventArgs e);

	public delegate void TestSuiteCompletedEventHandler(object sender, TestAssemblyResult[] tar);

	/// <summary>
	/// Summary description for TestEventDispatcher.
	/// </summary>
	public class TestEventDispatcher : LongLivingMarshalByRefObject
	{
		public TestEventDispatcher()
		{
		}

		public event TestIterationCompletedEventHandler TestIterationCompleted;
		public event TestIterationStartedEventHandler TestIterationStarted;
		public event TestCompletedEventHandler TestCompleted;
		public event TestStartedEventHandler TestStarted;

		public event TestFixtureIterationStartedEventHandler TestFixtureIterationStarted;
		public event TestFixtureIterationCompletedEventHandler TestFixtureIterationCompleted;
		public event TestFixtureCompletedEventHandler TestFixtureCompleted;
		public event TestFixtureStartedEventHandler TestFixtureStarted;

		public event TestAssemblyIterationStartedEventHandler TestAssemblyIterationStarted;
		public event TestAssemblyIterationCompletedEventHandler TestAssemblyIterationCompleted;
		public event TestAssemblyCompletedEventHandler TestAssemblyCompleted;
		public event TestAssemblyStartedEventHandler TestAssemblyStarted;

		public event TestSuiteCompletedEventHandler TestSuiteCompleted;

		public event ErrorEventHandler ErrorOccured;

		public event BaseTestHelperStartedEventHandler BaseTestHelperStarted;

		public virtual void OnTestIterationStarted(TestEventArgs e)
		{
			if (TestIterationStarted != null)
			{
				//Invokes the delegates.
				TestIterationStarted(this, e);
			}
		}

		public virtual void OnTestIterationCompleted(TestIterationEventArgs e)
		{
			if (TestIterationCompleted != null)
			{
				//Invokes the delegates.
				TestIterationCompleted(this, e);
			}
		}

		public virtual void OnTestFixtureIterationStarted(TestFixtureEventArgs e)
		{
			if (TestFixtureIterationStarted != null)
			{
				//Invokes the delegates.
				TestFixtureIterationStarted(this, e);
			}
		}

		public virtual void OnTestFixtureIterationCompleted(TestFixtureIterationEventArgs e)
		{
			if (TestFixtureIterationCompleted != null)
			{
				//Invokes the delegates.
				TestFixtureIterationCompleted(this, e);
			}
		}

		public virtual void OnTestAssemblyIterationStarted(TestAssemblyEventArgs e)
		{
			if (TestAssemblyIterationStarted != null)
			{
				//Invokes the delegates.
				TestAssemblyIterationStarted(this, e);
			}
		}

		public virtual void OnTestAssemblyIterationCompleted(TestAssemblyIterationEventArgs e)
		{
			if (TestAssemblyIterationCompleted != null)
			{
				//Invokes the delegates.
				TestAssemblyIterationCompleted(this, e);
			}
		}

		public virtual void OnTestCompleted(TestResultEventArgs e)
		{
			if (TestCompleted != null)
			{
				//Invokes the delegates.
				TestCompleted(this, e);
			}
		}

		public virtual void OnTestFixtureCompleted(TestFixtureResultEventArgs e)
		{
			if (TestFixtureCompleted != null)
			{
				//Invokes the delegates.
				TestFixtureCompleted(this, e);
			}
		}

		public virtual void OnTestAssemblyCompleted(TestAssemblyResultEventArgs e)
		{
			if (TestAssemblyCompleted != null)
			{
				//Invokes the delegates.
				TestAssemblyCompleted(this, e);
			}
		}

		public virtual void OnTestStarted(TestEventArgs e)
		{
			if (TestStarted != null)
			{
				//Invokes the delegates.
				TestStarted(this, e);
			}
		}

		public virtual void OnTestFixtureStarted(TestFixtureEventArgs e)
		{
			if (TestFixtureStarted != null)
			{
				//Invokes the delegates.
				TestFixtureStarted(this, e);
			}
		}

		public virtual void OnTestAssemblyStarted(TestAssemblyEventArgs e)
		{
			if (TestAssemblyStarted != null)
			{
				//Invokes the delegates.
				TestAssemblyStarted(this, e);
			}
		}

		public virtual void OnTestSuiteCompleted(TestAssemblyResult[] tar)
		{
			if (TestSuiteCompleted != null)
			{
				//Invokes the delegates.
				TestSuiteCompleted(this, tar);
			}
		}

		public virtual void OnBaseTestHelperStarted(BaseTestHelperEventArgs e)
		{
			if (BaseTestHelperStarted != null)
			{
				//Invokes the delegates.
				BaseTestHelperStarted(this, e);
			}
		}

		public virtual void OnErrorOccured(ErrorEventArgs e)
		{
			if (ErrorOccured != null)
			{
				//Invokes the delegates.
				ErrorOccured(this, e);
			}
		}

	}
}