using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestFramework.
	/// </summary>
	/// 
	[Serializable]
	public enum TestFramework
	{
		NUnit,
		Adapdev,
		MbUnit
	}
}
