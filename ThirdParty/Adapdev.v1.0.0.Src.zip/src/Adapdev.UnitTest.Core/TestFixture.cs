using System.ComponentModel;

#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Collections;
	using System.Collections.Specialized;

	/// <summary>
	/// Summary description for TestFixtureInfo.
	/// </summary>
	/// 
	[Serializable]
	public class TestFixture : TestUnit
	{
		protected HybridDictionary _tests = new HybridDictionary();
		protected string _namespace = "";
		protected string _class = "";
		protected TestAssembly _parent = null;
		protected ArrayList _fSetUp = new ArrayList();
		protected ArrayList _fTearDown = new ArrayList();
		protected ArrayList _tSetUp = new ArrayList();
		protected ArrayList _tTearDown = new ArrayList();

		public TestFixture()
		{
		}

		[Browsable(false)]
		public string Namespace
		{
			get { return this._namespace; }
			set { this._namespace = value; }
		}

		[Browsable(false)]
		public string Class
		{
			get { return this._class; }
			set { this._class = value; }
		}

		[Browsable(false)]
		public TestAssembly Parent
		{
			get { return this._parent; }
			set { this._parent = value; }
		}

		public void AddTest(Test t)
		{
			if (t != null) this._tests[t.Id] = t;
		}

		public void RemoveTest(Test t)
		{
			if (t != null) this._tests.Remove(t.Id);
		}

		public void RemoveTest(string id)
		{
			this._tests.Remove(id);
		}

		public void AddFixtureSetUp(BaseTestHelper th)
		{
			this._fSetUp.Add(th);
		}

		public void AddFixtureTearDown(BaseTestHelper th)
		{
			this._fTearDown.Add(th);
		}

		public void AddTestSetUp(BaseTestHelper th)
		{
			this._tSetUp.Add(th);
		}

		public void AddTestTearDown(BaseTestHelper th)
		{
			this._tTearDown.Add(th);
		}

		public ICollection GetFixtureSetUps()
		{
			return this._fSetUp;
		}

		public ICollection GetFixtureTearDowns()
		{
			return this._fTearDown;
		}

		public ICollection GetTestSetUps()
		{
			return this._tSetUp;
		}

		public ICollection GetTestTearDowns()
		{
			return this._tTearDown;
		}

		[Browsable(false)]
		public ArrayList FixtureSetUps
		{
			get { return this._fSetUp; }
			set { this._fSetUp = value; }
		}

		[Browsable(false)]
		public ArrayList FixtureTearDowns
		{
			get { return this._fTearDown; }
			set { this._fTearDown = value; }
		}

		[Browsable(false)]
		public ArrayList TestSetUps
		{
			get { return this._tSetUp; }
			set { this._tSetUp = value; }
		}

		[Browsable(false)]
		public ArrayList TestTearDowns
		{
			get { return this._tTearDown; }
			set { this._tTearDown = value; }
		}

		public override int GetTestCount()
		{
			if (!this.Ignore)
			{
				int count = 0;
				foreach (Test t in this.GetTests())
				{
					if(t.ShouldRun && !t.Ignore)
					{
						count += t.GetTestCount();
					}
				}
				return count*this.RepeatCount;
			}
			else
			{
				return 0;
			}
		}


		public ICollection GetTests()
		{
			return new SortedList(this._tests).Values;
		}

	}
}