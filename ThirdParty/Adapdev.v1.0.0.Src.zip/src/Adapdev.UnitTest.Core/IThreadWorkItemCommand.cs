using System;
using Adapdev.Commands;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for IThreadWorkItemCommand.
	/// </summary>
	public interface IThreadWorkItemCommand : ICommand
	{
		object Execute(object o);
	}
}
