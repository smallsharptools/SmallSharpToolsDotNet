using System;
using System.Collections;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for ITestEngine.
	/// </summary>
	public interface ITestEngine : IDisposable
	{
		TestAssemblyResult[] Run();
		TestAssemblyResult[] Run(TestSuite ts);
		TestAssemblyResult Run(TestAssembly ta);
		TestSuite GetTestSuite();
		TestAssembly GetTestAssembly();
		IList GetLoadedAssemblies();
		void SetTestEventDispatcher(TestEventDispatcher dispatcher);
		void ShutDown();
		string ConfigurationFile{get;}
		string Log{get;}
	}
}
