using System;
using System.Reflection;
using Adapdev.Commands;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for RunMethodCommand.
	/// </summary>
	public class RunMethodCommand : ICommand
	{
		private MethodInfo _method = null;
		private object _o = null;

		public RunMethodCommand(MethodInfo method, object o)
		{
			this._method = method;
			this._o = o;
		}

		public void Execute()
		{
			this._method.Invoke(this._o, null);
		}
	}
}
