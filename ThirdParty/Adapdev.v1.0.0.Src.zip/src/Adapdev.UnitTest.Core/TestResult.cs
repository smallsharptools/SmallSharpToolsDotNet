#region Copyright / License Information

/*
Author: Sean McCormack

================================================
Copyright
================================================
Copyright (c) 2004 Adapdev Technologies, LLC

================================================
License
================================================
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

================================================
Change History
================================================
	III	MM/DD/YYYY	Change

*/

#endregion

namespace Adapdev.UnitTest.Core
{
	using System;

	/// <summary>
	/// Summary description for TestResult.
	/// </summary>
	/// 
	[Serializable]
	public class TestResult : AbstractTestResult
	{
		protected string _category = "";
		protected string _description = "";
		protected TestType _testType = TestType.Unit;

		public TestResult(Test t)
		{
			this.Name = t.Name;
			this.Category = t.Category;
			this.TestType = t.TestType;
		}

		public TestType TestType
		{
			get{return this._testType;}
			set{this._testType = value;}
		}

		/// <summary>
		/// Gets or sets the category.
		/// </summary>
		/// <value></value>
		public string Category
		{
			get { return this._category; }
			set { this._category = value; }
		}

		/// <summary>
		/// Gets or sets the description.
		/// </summary>
		/// <value></value>
		public string Description
		{
			get{ return this._description;}
			set{ this._description = value;}
		}

		public double GetAvgOpsPerSecond()
		{
			double i = 0;

			foreach (TestIteration ti in this._iterations)
			{
				i += ti.GetOpsPerSecond();
			}

			double avg = i/this._iterations.Count;
			return avg;
		}

		public long GetAvgMemoryUsed()
		{
			long i = 0;

			foreach (TestIteration ti in this._iterations)
			{
				i += ti.MemoryUsed;
			}

			long avg = i/this._iterations.Count;
			return avg;
		}

	}
}