using System;

namespace Adapdev.UnitTest.Core
{
	/// <summary>
	/// Summary description for TestSuiteIteration.
	/// </summary>
	public class TestSuiteIteration : CompositeAbstractTestIteration
	{

	}
}
