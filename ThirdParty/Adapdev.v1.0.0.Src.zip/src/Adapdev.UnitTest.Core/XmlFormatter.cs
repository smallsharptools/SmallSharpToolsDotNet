using System.IO;

namespace Adapdev.UnitTest.Core
{
	using System;
	using System.Diagnostics;
	using System.Text;
	using System.Xml;

	/// <summary>
	/// Summary description for XmlFormatter.
	/// </summary>
	public class XmlFormatter : IResultFormatter
	{
		private XmlDocument xml = null;

		public XmlFormatter(TestAssemblyResult[] results){
			this.FormatResults(results);
		}

		protected void FormatTestResult(TestResult tr, XmlNode testFixtureIteration)
		{
			Debug.Assert(tr != null);
			XmlNode testResult = xml.CreateElement("testResult");

			XmlAttribute avgOpsSecond = xml.CreateAttribute("avgOpsSecond");
			avgOpsSecond.Value = tr.GetAvgOpsPerSecond().ToString();
			testResult.Attributes.Append(avgOpsSecond);

			XmlAttribute totalDuration = xml.CreateAttribute("totalDuration");
			totalDuration.Value = tr.GetTotalDuration().ToString();
			testResult.Attributes.Append(totalDuration);

			XmlAttribute category = xml.CreateAttribute("category");
			category.Value = tr.Category;
			testResult.Attributes.Append(category);

			XmlAttribute description = xml.CreateAttribute("description");
			description.Value = tr.Description;
			testResult.Attributes.Append(description);
			
			this.FormatAbstractTestResult(tr, testResult);

			foreach (TestIteration ti in tr.Iterations)
			{
				XmlNode testIteration = xml.CreateElement("testIteration");

				XmlAttribute iteration = xml.CreateAttribute("iteration");
				iteration.Value = ti.Iteration.ToString();
				testIteration.Attributes.Append(iteration);

				XmlNode tcategory = xml.CreateElement("category");
				testIteration.AppendChild(tcategory);
				XmlNode tcategorytext = xml.CreateCDataSection(tr.Category);
				tcategory.AppendChild(tcategorytext);

				XmlNode tmessage = xml.CreateElement("message");
				testIteration.AppendChild(tmessage);
				XmlNode tmessagetext = xml.CreateCDataSection(ti.Result);
				tmessage.AppendChild(tmessagetext);

				XmlNode texception = xml.CreateElement("exception");
				testIteration.AppendChild(texception);
				XmlNode texceptiontext = xml.CreateCDataSection(ti.FullStackTrace);
				texception.AppendChild(texceptiontext);

				XmlNode tduration = xml.CreateElement("duration");
				tduration.InnerText = ti.Duration.ToString();
				testIteration.AppendChild(tduration);

				XmlNode thread = xml.CreateElement("thread");
				thread.InnerText = ti.Thread.ToString();
				testIteration.AppendChild(thread);

				XmlNode state = xml.CreateElement("state");
				state.InnerText = ti.State.ToString();
				testIteration.AppendChild(state);

				XmlNode opsSecond = xml.CreateElement("opsSecond");
				opsSecond.InnerText = ti.GetOpsPerSecond().ToString();
				testIteration.AppendChild(opsSecond);

				XmlNode output = xml.CreateElement("consoleOutput");
				testIteration.AppendChild(output);
				XmlNode outputText = xml.CreateCDataSection(ti.ConsoleOutput);
				output.AppendChild(outputText);

				XmlNode consoleError = xml.CreateElement("consoleError");
				testIteration.AppendChild(consoleError);
				XmlNode consoleErrorText = xml.CreateCDataSection(ti.ConsoleError);
				consoleError.AppendChild(consoleErrorText);

				XmlNode debugOutput = xml.CreateElement("debugOutput");
				testIteration.AppendChild(debugOutput);
				XmlNode debugOutputText = xml.CreateCDataSection(ti.DebugOutput);
				debugOutput.AppendChild(debugOutputText);

				XmlNode traceOutput = xml.CreateElement("traceOutput");
				testIteration.AppendChild(traceOutput);
				XmlNode traceOutputText = xml.CreateCDataSection(ti.TraceOutput);
				traceOutput.AppendChild(traceOutputText);

				XmlNode allOutput = xml.CreateElement("allOutput");
				testIteration.AppendChild(allOutput);
				XmlNode allOutputText = xml.CreateCDataSection(ti.AllOutput);
				allOutput.AppendChild(allOutputText);

				testResult.AppendChild(testIteration);
			}
			testFixtureIteration.AppendChild(testResult);
		}

		protected void FormatTestFixtureResult(TestFixtureResult tfr, XmlNode testAssemblyIteration)
		{
			Debug.Assert(tfr != null);
			XmlNode testFixtureResult = xml.CreateElement("testFixtureResult");

			XmlAttribute totalDuration = xml.CreateAttribute("totalDuration");
			totalDuration.Value = tfr.GetTotalDuration().ToString();
			testFixtureResult.Attributes.Append(totalDuration);						
			
			this.FormatAbstractTestResult(tfr, testFixtureResult);

			int i = 1;
			foreach (TestFixtureIteration tfi in tfr.Iterations)
			{
				XmlNode testFixtureIteration = xml.CreateElement("testFixtureIteration");

				XmlAttribute iteration = xml.CreateAttribute("iteration");
				iteration.Value = i.ToString();
				testFixtureIteration.Attributes.Append(iteration);	
				
				XmlAttribute totalDuration2 = xml.CreateAttribute("totalDuration");
				totalDuration2.Value = tfr.GetTotalDuration().ToString();
				testFixtureIteration.Attributes.Append(totalDuration2);	

				XmlAttribute state = xml.CreateAttribute("state");
				state.Value = tfr.GetTotalDuration().ToString();
				testFixtureIteration.Attributes.Append(state);

				foreach (TestResult tr in tfi.GetTestResults())
				{
					this.FormatTestResult(tr, testFixtureIteration);
				}

				testFixtureResult.AppendChild(testFixtureIteration);
				i++;
			}

			testAssemblyIteration.AppendChild(testFixtureResult);
		}

		protected void FormatTestAssemblyResult(TestAssemblyResult tar, XmlNode resultNode)
		{
			Debug.Assert(tar != null);
			XmlNode testAssemblyResult = xml.CreateNode(XmlNodeType.Element, "testAssemblyResult", "");

			XmlAttribute runTime = xml.CreateAttribute("runTime");
			runTime.Value = tar.RunTime.ToString();
			testAssemblyResult.Attributes.Append(runTime);

			XmlAttribute assemblyName = xml.CreateAttribute("assemblyName");
			assemblyName.Value = tar.AssemblyName;
			testAssemblyResult.Attributes.Append(assemblyName);

			XmlAttribute assemblyFullName = xml.CreateAttribute("assemblyFullName");
			assemblyFullName.Value = tar.AssemblyFullName;
			testAssemblyResult.Attributes.Append(assemblyFullName);

			XmlAttribute location = xml.CreateAttribute("location");
			location.Value = tar.Location;
			testAssemblyResult.Attributes.Append(location);

			this.FormatAbstractTestResult(tar, testAssemblyResult);

			int i = 1;
			foreach (TestAssemblyIteration tai in tar.Iterations)
			{
				XmlNode testAssemblyIteration = xml.CreateElement("testAssemblyIteration");
				
				XmlAttribute iteration = xml.CreateAttribute("iteration");
				iteration.Value = i.ToString();
				testAssemblyIteration.Attributes.Append(iteration);

				XmlAttribute totalDuration = xml.CreateAttribute("totalDuration");
				totalDuration.Value = tai.Duration.ToString();
				testAssemblyIteration.Attributes.Append(totalDuration);

				XmlAttribute state = xml.CreateAttribute("state");
				state.Value = tai.State.ToString();
				testAssemblyIteration.Attributes.Append(state);

				foreach (TestFixtureResult tfr in tai.GetTestResults())
				{
					this.FormatTestFixtureResult(tfr, testAssemblyIteration);
				}

				testAssemblyResult.AppendChild(testAssemblyIteration);
				i++;
			}

			resultNode.AppendChild(testAssemblyResult);
		}

		public void FormatResults(TestAssemblyResult[] tars)
		{
			Debug.Assert(tars != null);
			xml = new XmlDocument();

//			xml.AppendChild(xml.CreateProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\""));
			XmlNode results = xml.CreateNode(XmlNodeType.Element, "results",String.Empty);
			xml.AppendChild(results);
			if (tars != null)
			{
				foreach (TestAssemblyResult tar in tars)
				{
					this.FormatTestAssemblyResult(tar, results);
				}
			}
		}

		protected void FormatAbstractTestResult(AbstractTestResult atr, XmlNode testResult)
		{
			Debug.Assert(atr != null);
			XmlAttribute name = xml.CreateAttribute("name");
			name.Value = atr.Name;
			testResult.Attributes.Append(name);

			XmlAttribute avgDuration = xml.CreateAttribute("avgDuration");
			avgDuration.Value = atr.GetAverageDuration().ToString();
			testResult.Attributes.Append(avgDuration);

			XmlAttribute totalIterations = xml.CreateAttribute("totalIterations");
			totalIterations.Value = atr.GetTotalIterations().ToString();
			testResult.Attributes.Append(totalIterations);

			XmlAttribute state = xml.CreateAttribute("state");
			state.Value = atr.State.ToString();
			testResult.Attributes.Append(state);

			XmlAttribute id = xml.CreateAttribute("id");
			id.Value = atr.TestId.ToString();
			testResult.Attributes.Append(id);

			XmlAttribute passed = xml.CreateAttribute("passed");
			passed.Value = atr.Passed.ToString();
			testResult.Attributes.Append(passed);

			XmlAttribute failed = xml.CreateAttribute("failed");
			failed.Value = atr.Failed.ToString();
			testResult.Attributes.Append(failed);

			XmlAttribute ignored = xml.CreateAttribute("ignored");
			ignored.Value = atr.Ignored.ToString();
			testResult.Attributes.Append(ignored);

			XmlAttribute percentPassed = xml.CreateAttribute("percentPassed");
			percentPassed.Value = atr.PercentPassed.ToString("p");
			testResult.Attributes.Append(percentPassed);

			XmlAttribute percentFailed = xml.CreateAttribute("percentFailed");
			percentFailed.Value = atr.PercentFailed.ToString("p");
			testResult.Attributes.Append(percentFailed);
		}

		public string GetText(){
			StringWriter sw = new StringWriter();
			XmlTextWriter xtw = new XmlTextWriter(sw);
			xtw.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'");
			xml.Save(sw);
			return sw.ToString().Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>","");
		}
	}
}