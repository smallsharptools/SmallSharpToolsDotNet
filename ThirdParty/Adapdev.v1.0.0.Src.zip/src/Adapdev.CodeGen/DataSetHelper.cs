using System;
using System.Data;
using Adapdev.Data;
using Adapdev.Data.Schema;

namespace Adapdev.CodeGen
{
	public class DataHelper
	{
		private DatabaseSchema schema = null;

		public DataHelper(DatabaseSchema schema)
		{
			this.schema = schema;
		}

		public DataTable GetDataTable(DataSet dataset, string dataTableName)
		{
			return dataset.Tables[dataTableName];
		}

		public DataColumn GetDataColumn(DataTable table, string dataColumnName)
		{
			return table.Columns[dataColumnName];
		}

		public object GetColumnValue(DataRow row, string columnName)
		{
			return row[columnName];
		}

		public DataSet GetDataSet(string query)
		{
			try
			{
				IDbCommand command = DbProviderFactory.CreateCommand(schema.DatabaseProviderType);
				command.CommandText = query;
				return DbProviderFactory.CreateDataSet(schema.ConnectionString, command, schema.DatabaseProviderType);
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}

			return null;
		}
	}
}
