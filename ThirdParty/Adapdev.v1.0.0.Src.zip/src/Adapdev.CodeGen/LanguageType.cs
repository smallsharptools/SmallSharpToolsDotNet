namespace Adapdev.CodeGen
{
	using System;

	/// <summary>
	/// Summary description for LanguageType.
	/// </summary>
	/// 
	[Flags]
	public enum LanguageType
	{
		CSHARP = 1,
		JSHARP = 2,
		JSCRIPT = 4,
		VBNET = 8,
		CPP = 16,
		SQL = 32,
		OTHER = 64,
		JAVA = 128
	}
}