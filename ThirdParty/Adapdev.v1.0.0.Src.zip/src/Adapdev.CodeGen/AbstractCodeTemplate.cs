namespace Adapdev.CodeGen
{
	using System;

	/// <summary>
	/// Summary description for AbstractTemplate.
	/// </summary>
	public abstract class AbstractCodeTemplate : ICodeTemplate
	{
		protected string fileName = String.Empty;
		protected string className = String.Empty;
		protected string fileExtension = String.Empty;
		protected string outputDir = String.Empty;
		protected string nameSpace = String.Empty;
		protected bool overwrite = true;

		/// <summary>
		/// Creates a new <see cref="AbstractCodeTemplate"/> instance.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="nameSpace">Namespace.</param>
		public AbstractCodeTemplate(string fileName, string fileExtension, string className, string nameSpace)
		{
			this.fileName = fileName;
			this.fileExtension = fileExtension;
			this.className = className;
			this.nameSpace = nameSpace;
		}

		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value></value>
		public string FileName
		{
			get { return this.fileName; }
			set { this.fileName = value; }
		}

		/// <summary>
		/// Gets or sets the file extension.
		/// </summary>
		/// <value></value>
		public string FileExtension
		{
			get { return this.fileExtension; }
			set { this.fileExtension = value; }
		}

		/// <summary>
		/// Gets or sets the name of the class.
		/// </summary>
		/// <value></value>
		public string ClassName
		{
			get { return this.className; }
			set { this.className = value; }
		}

		/// <summary>
		/// Gets or sets the output directory.
		/// </summary>
		/// <value></value>
		public virtual string OutputDirectory
		{
			get { return this.outputDir; }
			set { this.outputDir = value; }
		}

		/// <summary>
		/// Gets or sets the namespace.
		/// </summary>
		/// <value></value>
		public virtual string Namespace
		{
			get { return this.nameSpace; }
			set { this.nameSpace = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether the generated file can be overwritten
		/// </summary>
		/// <value>
		/// 	<c>true</c> if it can be overwritten; otherwise, <c>false</c>.
		/// </value>
		public virtual bool Overwrite
		{
			get { return this.overwrite; }
			set { this.overwrite = value; }
		}

		/// <summary>
		/// Processes the custom code.
		/// </summary>
		public virtual void ProcessCustomCode()
		{
		}

		/// <summary>
		/// Gets the code.
		/// </summary>
		/// <returns></returns>
		public abstract string GetCode();
	}
}