namespace Adapdev.CodeGen
{
	using System;
	using System.Collections;
	using System.IO;

	public delegate void ProcessCustomCodeHandler(string info);

	/// <summary>
	/// Summary description for AbstractConfig.
	/// </summary>
	public abstract class AbstractConfig
	{
		protected Hashtable properties = null;
		protected string nameSpace = String.Empty;
		protected ArrayList languages = new ArrayList();
		protected string appdir = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
		protected string shareddir = String.Empty;
		protected string outputdir = String.Empty;

		/// <summary>
		/// Creates a new <see cref="AbstractConfig"/> instance.
		/// </summary>
		/// <param name="nameSpace">Namespace.</param>
		public AbstractConfig(string nameSpace)
		{
			this.nameSpace = nameSpace;
			shareddir = Path.Combine(this.appdir, "shared");
		}

		/// <summary>
		/// Gets the base output directory for this template library
		/// </summary>
		/// <value></value>
		public virtual string PackageDirectory
		{
			get { return this.PackageName; }
		}

		/// <summary>
		/// Gets or sets the output directory.
		/// </summary>
		/// <value></value>
		public virtual string OutputDirectory
		{
			get { return this.outputdir; }
			set { this.outputdir = value; }
		}

		/// <summary>
		/// Gets the application directory.
		/// </summary>
		/// <value></value>
		public string ApplicationDirectory
		{
			get { return this.appdir; }
		}

		/// <summary>
		/// Gets or sets the shared directory.
		/// </summary>
		/// <value></value>
		public string SharedDirectory
		{
			get { return this.shareddir; }
			set { this.shareddir = value; }
		}

		/// <summary>
		/// Gets or sets the base namespace for this template library
		/// </summary>
		/// <value></value>
		public string NameSpace
		{
			get { return this.nameSpace; }
			set { this.nameSpace = value; }
		}

		/// <summary>
		/// Gets or sets the custom properties.
		/// </summary>
		/// <value></value>
		public virtual Hashtable CustomProperties
		{
			get { return this.properties; }
			set { this.properties = value; }
		}

		/// <summary>
		/// Processes the custom code.
		/// </summary>
		public virtual void ProcessCustomCode()
		{
		}

		public event ProcessCustomCodeHandler Processing;

		public void OnProcessing(string info)
		{
			if(Processing != null)
			{
				Processing(info);
			}
		} 

		/// <summary>
		/// Gets the code DOM templates.
		/// </summary>
		/// <returns>A list of ICodeDomTemplates to process</returns>
		public abstract ArrayList GetCodeDomTemplates();

		/// <summary>
		/// Gets the code templates.
		/// </summary>
		/// <returns>A list of ICodeTemplates to process</returns>
		public abstract ArrayList GetCodeTemplates();

		// The name of the package.
		/// <summary>
		/// Gets the name of the package.
		/// </summary>
		/// <value></value>
		public abstract string PackageName { get; }

		/// <summary>
		/// Gets the package description.
		/// </summary>
		/// <value></value>
		public abstract string PackageDescription { get; }

		/// <summary>
		/// Gets the author.
		/// </summary>
		/// <value></value>
		public abstract string Author { get; }

		/// <summary>
		/// Gets the version.
		/// </summary>
		/// <value></value>
		public abstract string Version { get; }

		/// <summary>
		/// Gets the copyright.
		/// </summary>
		/// <value></value>
		public abstract string Copyright { get; }
	}
}