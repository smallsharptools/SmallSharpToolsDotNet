namespace Adapdev.CodeGen
{
	/// <summary>
	/// Summary description for ICodeTemplate.
	/// </summary>
	public interface ICodeTemplate
	{
		/// <summary>
		/// Gets the code.
		/// </summary>
		/// <returns></returns>
		string GetCode();
		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value></value>
		string FileName { get; set; }
		/// <summary>
		/// Gets or sets the name of the class.
		/// </summary>
		/// <value></value>
		string ClassName { get; set; }
		/// <summary>
		/// Gets or sets the namespace.
		/// </summary>
		/// <value></value>
		string Namespace { get; set; }
		/// <summary>
		/// Gets or sets the file extension.
		/// </summary>
		/// <value></value>
		string FileExtension { get; set; }
		/// <summary>
		/// Gets or sets the output directory.
		/// </summary>
		/// <value></value>
		string OutputDirectory { get; set; }
		/// <summary>
		/// Gets or sets a value indicating whether the generated file can be overwritten
		/// </summary>
		/// <value>
		/// 	<c>true</c> if overwrite; otherwise, <c>false</c>.
		/// </value>
		bool Overwrite { get; set; }
		/// <summary>
		/// Processes the custom code.
		/// </summary>
		void ProcessCustomCode();
	}
}