namespace Adapdev.CodeGen
{
	using System;
	using System.Collections;
	using System.IO;
	using System.Text;
	using Adapdev.Data;
	using Adapdev.Data.Schema;
	using Adapdev.Data.Sql;
	using NVelocity;
	using NVelocity.App;

	/// <summary>
	/// Summary description for NVelocityTableCodeTemplate.
	/// </summary>
	public class NVelocityTableCodeTemplate : TableCodeTemplate, INVelocityTemplate
	{
		protected DatabaseSchema di = null;
		protected string templateFile = String.Empty;
		protected VelocityContext context = null;

		/// <summary>
		/// Creates a new <see cref="NVelocityTableCodeTemplate"/> instance.
		/// </summary>
		/// <param name="di">Database Schema.</param>
		/// <param name="ti">Table Schema.</param>
		/// <param name="outputDirectory">Output directory.</param>
		/// <param name="templateFile">Template file.</param>
		/// <param name="nameSpace">Namespace.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="overWrite">Over write.</param>
		public NVelocityTableCodeTemplate(DatabaseSchema di,
		                                  TableSchema ti,
		                                  string outputDirectory,
		                                  string templateFile,
		                                  string nameSpace,
		                                  string fileName,
		                                  string fileExtension,
		                                  string className,
		                                  bool overWrite) :
		                                  	base(ti,
		                                  	     nameSpace,
		                                  	     fileName,
		                                  	     fileExtension,
		                                  	     className)
		{
			this.di = di;
			this.templateFile = templateFile;
			this.outputDir = outputDirectory;
			this.overwrite = overWrite;

			if (!File.Exists("nvelocity.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "nvelocity.properties"), Path.Combine(".", "nvelocity.properties"), true);
			if (!File.Exists("directive.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "directive.properties"), Path.Combine(".", "directive.properties"), true);

			Velocity.Init("nvelocity.properties");
			context = new VelocityContext();
		}

		/// <summary>
		/// Creates a new <see cref="NVelocityTableCodeTemplate"/> instance.
		/// </summary>
		/// <param name="di">Database Schema.</param>
		/// <param name="ti">Table Schema.</param>
		/// <param name="outputDirectory">Output directory.</param>
		/// <param name="templateFile">Template file.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		public NVelocityTableCodeTemplate(DatabaseSchema di,
		                                  TableSchema ti,
		                                  string outputDirectory,
		                                  string templateFile,
		                                  string fileName,
		                                  string fileExtension) :
		                                  	this(di,
		                                  	     ti,
		                                  	     outputDirectory,
		                                  	     templateFile,
		                                  	     String.Empty,
		                                  	     fileName,
		                                  	     fileExtension,
		                                  	     String.Empty,
		                                  	     true)
		{
		}

		/// <summary>
		/// Gets the code.
		/// </summary>
		/// <returns></returns>
		public override string GetCode()
		{
			context.Put("databaseschema", this.di);
			context.Put("tableschema", this.ti);
			if(!context.ContainsKey("namespace")) context.Put("namespace", this.nameSpace);
			if(!context.ContainsKey("classname")) context.Put("classname", this.className);
			if(!context.ContainsKey("filename")) context.Put("filename", this.fileName);
			context.Put("datetimenow", DateTime.Now);
			context.Put("datahelper", new DataHelper(di));
			context.Put("providerinfo", ProviderInfoManager.GetInstance());
			context.Put("template", this);
			context.Put("queryhelper", new QueryHelper());
			context.Put("mysqlprovidertype", Adapdev.Data.DbProviderType.MYSQL);

			StringWriter writer = new StringWriter();
			Velocity.MergeTemplate(this.templateFile, context, writer);

			return writer.GetStringBuilder().ToString();
		}

		/// <summary>
		/// Gets the Sql to select one record by the primary key
		/// </summary>
		/// <returns></returns>
		public string GetSelectOneSql()
		{
			return this.GetSelectOneSql(this.ti);
		}

		/// <summary>
		/// Gets the Sql to select one record by the primary key
		/// </summary>
		/// <param name="ts">Ts.</param>
		/// <returns></returns>
		public string GetSelectOneSql(TableSchema ts)
		{
			if(ts.HasPrimaryKeys)
			{
				ISelectQuery query = QueryFactory.CreateSelectQuery(di.DatabaseType, di.DatabaseProviderType);
				query.SetTable(ts.Name);
				foreach (ColumnSchema ci in ts.OrdinalColumns.Values)
				{
					if(ci.IsActive)query.Add(ci.Name);
				}

				ArrayList pks = new ArrayList(ts.PrimaryKeys.Values);
				ColumnSchema pk = (ColumnSchema) pks[0];

				ICriteria criteria = query.CreateCriteria();
				criteria.DbProviderType = this.di.DatabaseProviderType;
				criteria.AddEqualTo(pk.Name);

				query.SetCriteria(criteria);

				return query.GetText();
			}
			return "";			
		}

		/// <summary>
		/// Gets the insert SQL.
		/// </summary>
		/// <returns></returns>
		public string GetInsertSql()
		{
			return this.GetInsertSql(this.ti);
		}

		/// <summary>
		/// Gets the insert SQL.
		/// </summary>
		/// <param name="ts">Ts.</param>
		/// <returns></returns>
		public string GetInsertSql(TableSchema ts)
		{
			IInsertQuery query = QueryFactory.CreateInsertQuery(di.DatabaseType, di.DatabaseProviderType);
			query.SetTable(ts.Name);

			foreach (ColumnSchema ci in ts.SortedColumns.Values)
			{
				if (!ci.IsAutoIncrement && ci.IsActive) query.Add(ci.Name);
			}

			return query.GetText();
		}

		/// <summary>
		/// Gets the update SQL.
		/// </summary>
		/// <returns></returns>
		public string GetUpdateSql()
		{
			return this.GetUpdateSql(this.ti);
		}

		/// <summary>
		/// Gets the update SQL.
		/// </summary>
		/// <returns></returns>
		public string GetUpdateSql(TableSchema ts)
		{
			IUpdateQuery query = QueryFactory.CreateUpdateQuery(di.DatabaseType, di.DatabaseProviderType);
			query.SetTable(ts.Name);

			foreach (ColumnSchema ci in ts.SortedColumns.Values)
			{
				if (!ci.IsAutoIncrement && !ci.IsPrimaryKey && ci.IsActive) query.Add(ci.Name);
			}

			ArrayList pks = new ArrayList(ts.PrimaryKeys.Values);

			ICriteria criteria = query.CreateCriteria();
			criteria.DbProviderType = this.di.DatabaseProviderType;
			int i = 1;
			foreach(ColumnSchema pk in pks)
			{
				criteria.AddEqualTo(pk.Name);
				if(i < pks.Count) criteria.AddAnd();
				i++;
			}

			query.SetCriteria(criteria);

			return query.GetText();
		}


		/// <summary>
		/// Gets the delete one SQL.
		/// </summary>
		/// <returns></returns>
		public string GetDeleteOneSql()
		{
			return this.GetDeleteOneSql(this.ti);
		}

		/// <summary>
		/// Gets the sql to delete one record by primary key
		/// </summary>
		/// <returns></returns>
		public string GetDeleteOneSql(TableSchema ts)
		{
			if(ts.HasPrimaryKeys)
			{
				IDeleteQuery query = QueryFactory.CreateDeleteQuery(di.DatabaseType, di.DatabaseProviderType);
				query.SetTable(ts.Name);

				ArrayList pks = new ArrayList(ts.PrimaryKeys.Values);
				ColumnSchema pk = (ColumnSchema) pks[0];

				ICriteria criteria = query.CreateCriteria();
				criteria.DbProviderType = this.di.DatabaseProviderType;
				criteria.AddEqualTo(pk.Name);

				query.SetCriteria(criteria);

				return query.GetText();
			}
			return "";
		}

		/// <summary>
		/// Gets the foreign key SQL.
		/// </summary>
		/// <param name="ci">Ci.</param>
		/// <returns></returns>
		public string GetForeignKeySql(ColumnSchema ci)
		{
			return this.GetForeignKeySql(this.ti, ci);
		}

		/// <summary>
		/// Gets the foreign key SQL.
		/// </summary>
		/// <param name="ts">Ts.</param>
		/// <param name="columnSchema">Column schema.</param>
		/// <returns></returns>
		public string GetForeignKeySql(TableSchema ts, ColumnSchema columnSchema)
		{
			ISelectQuery query = QueryFactory.CreateSelectQuery(di.DatabaseType);
			query.SetTable(ts.Name);

			foreach (ColumnSchema ci2 in ts.OrdinalColumns.Values)
			{
				if(ci2.IsActive)query.Add(ci2.Name);
			}

			ICriteria criteria = query.CreateCriteria();
			criteria.DbProviderType = this.di.DatabaseProviderType;
			criteria.AddEqualTo(columnSchema.Name);

			query.SetCriteria(criteria);

			return query.GetText();
		}

		/// <summary>
		/// Gets the name of the parameter.
		/// </summary>
		/// <param name="name">Name.</param>
		/// <returns></returns>
		public string GetParameterName(string name)
		{
			return QueryHelper.GetParameterName(name, this.di.DatabaseProviderType);
		}

		/// <summary>
		/// Gets the parameter value.
		/// </summary>
		/// <param name="c">C.</param>
		/// <returns></returns>
		public string GetParameterValue(DatabaseSchema d, ColumnSchema c)
		{
			if (c.NetType.Equals("System.DateTime"))
			{
				if(d.DatabaseType == Adapdev.Data.DbType.SQLSERVER)
					return c.Alias + ".Subtract(new TimeSpan(2,0,0,0)).ToOADate()";
				else if(d.DatabaseType == Adapdev.Data.DbType.ORACLE)
					return c.Alias;
				else if (d.DatabaseType == Adapdev.Data.DbType.MYSQL)
					return c.Alias;
				else
					return c.Alias + ".ToOADate()";
			}
			else return c.Alias;
		}

		public string GetParameterLength(ColumnSchema c)
		{
			switch(c.DataType.ToLower())
			{
				case "binary":
				case "char":
				case "nchar":
				case "nvarchar":
				case "varbinary":
				case "varchar":
					return "(" + c.Length + ")";
			}
			return String.Empty;
		}

		public string GetParameterText(ColumnSchema cs)
		{
			return this.GetParameterName(cs.Name) + " " + cs.DataType.ToLower()	+ this.GetParameterLength(cs);
		}

		/// <summary>
		/// Gets or sets the template file.
		/// </summary>
		/// <value></value>
		public string TemplateFile
		{
			get { return this.templateFile; }
			set { this.templateFile = value; }
		}

		public override bool Overwrite
		{
			get { return this.overwrite; }
			set { base.Overwrite = value; }
		}

		/// <summary>
		/// Gets the context.
		/// </summary>
		/// <value></value>
		public VelocityContext Context
		{
			get { return this.context; }
		}

		/// <summary>
		/// Adds the context.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void AddContext(string key, object value)
		{
			this.context.Put(key, value);
		}

		/// <summary>
		/// Gets the output.
		/// </summary>
		/// <returns></returns>
		public string GetOutput()
		{
			return this.GetCode();
		}

		public string GetConversionExpression(string objectType)
		{
			string subt = objectType.Substring(objectType.IndexOf(".") + 1);
			return "Convert.To"+subt;
		}

		public string GetSqlServerSPInsertParams(TableSchema ts)
		{
			StringBuilder sb = new StringBuilder();
			ArrayList al = new ArrayList();

			// Get all columns that aren't autoincrement
			foreach(ColumnSchema cs in ts.SortedColumns.Values)
			{
				if(!cs.IsAutoIncrement && cs.IsActive)al.Add(cs);
			}

			// Build the list of parameters
			int i = 1;
			foreach(ColumnSchema cs in al)
			{
				if(cs.IsActive)
				{
					if(i < al.Count)
					{
						sb.Append(this.GetParameterText(cs) + "," + Environment.NewLine);
					}
					else 
					{
						sb.Append(this.GetParameterText(cs) + Environment.NewLine);
					}
					i++;
				}
			}
			return sb.ToString();
		}

		public string GetSqlServerSPUpdateParams(TableSchema ts)
		{
			int i = 1;
			StringBuilder sb = new StringBuilder();
			foreach (ColumnSchema columnSchema in ts.SortedColumns.Values)
			{
				if(columnSchema.IsActive)
				{
					if(i < ts.SortedColumns.Count)
					{
						sb.Append(this.GetParameterText(columnSchema) + "," + Environment.NewLine);
					}
					else
					{
						sb.Append(this.GetParameterText(columnSchema) + Environment.NewLine);
					}
				}
				i++;
			}
			return sb.ToString();
		}

		public string GetJoinStatement(object id, ForeignKeyAssociation assoc, DbType dbType)
		{
			string text = String.Empty;

			if(assoc.AssociationType == AssociationType.OneToOne ||
				assoc.AssociationType == AssociationType.OneToMany)
			{
				ISelectQuery query = QueryFactory.CreateSelectQuery(dbType);
				query.SetTable(assoc.SecondForeignTableName);
				query.AddAll();
				query.AddJoin(assoc.TableName, assoc.ColumnName, assoc.SecondForeignColumnName, JoinType.INNER);

				ICriteria criteria = query.CreateCriteria();
				criteria.AddEqualTo(assoc.Table.GetPrimaryKey(0).Name, id);
				query.SetCriteria(criteria);

				text = query.GetText();
			}

			return text;
		}

	}
}