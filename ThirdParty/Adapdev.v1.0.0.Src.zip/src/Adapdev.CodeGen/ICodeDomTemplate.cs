namespace Adapdev.CodeGen
{
	using System.CodeDom;

	/// <summary>
	/// Summary description for ICodeDomTemplate.
	/// </summary>
	public interface ICodeDomTemplate
	{
		/// <summary>
		/// Gets the code compile unit.
		/// </summary>
		/// <returns></returns>
		CodeCompileUnit GetCodeCompileUnit();
		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value></value>
		string FileName { get; set; }
		/// <summary>
		/// Gets or sets the name of the class.
		/// </summary>
		/// <value></value>
		string ClassName { get; set; }
		/// <summary>
		/// Gets or sets the namespace.
		/// </summary>
		/// <value></value>
		string Namespace { get; set; }
		/// <summary>
		/// Gets or sets the output directory.
		/// </summary>
		/// <value></value>
		string OutputDirectory { get; set; }
		/// <summary>
		/// Gets or sets a value indicating whether the generated file can be overwritten
		/// </summary>
		/// <value>
		/// 	<c>true</c> if overwrite; otherwise, <c>false</c>.
		/// </value>
		bool Overwrite { get; set; }
		/// <summary>
		/// Processes the custom code.
		/// </summary>
		void ProcessCustomCode();
	}
}