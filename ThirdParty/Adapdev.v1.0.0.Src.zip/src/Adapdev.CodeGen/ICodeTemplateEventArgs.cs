namespace Adapdev.CodeGen
{
	using System;

	/// <summary>
	/// Summary description for ICodeTemplateEventArgs.
	/// </summary>
	public class ICodeTemplateEventArgs : EventArgs
	{
		private ICodeTemplate _template = null;

		/// <summary>
		/// Creates a new <see cref="ICodeTemplateEventArgs"/> instance.
		/// </summary>
		/// <param name="template">Template.</param>
		public ICodeTemplateEventArgs(ICodeTemplate template)
		{
			this._template = template;
		}

		/// <summary>
		/// Gets the I code template.
		/// </summary>
		/// <value></value>
		public ICodeTemplate ICodeTemplate
		{
			get { return this._template; }
		}
	}
}