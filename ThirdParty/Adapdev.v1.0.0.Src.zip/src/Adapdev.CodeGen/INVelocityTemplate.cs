using System;
using NVelocity;

namespace Adapdev.CodeGen
{
	/// <summary>
	/// Summary description for INVelocityTemplate.
	/// </summary>
	public interface INVelocityTemplate
	{
		/// <summary>
		/// Gets the context.
		/// </summary>
		/// <value></value>
		VelocityContext Context{get;}
		/// <summary>
		/// Adds the context.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		void AddContext(string key, object value);
		/// <summary>
		/// Gets the output.
		/// </summary>
		/// <returns></returns>
		string GetOutput();
	}
}
