namespace Adapdev.CodeGen
{
	using Adapdev.Data.Schema;

	public abstract class TableCodeDomTemplate : AbstractCodeDomTemplate
	{
		protected TableSchema ti;

		/// <summary>
		/// Creates a new <see cref="TableCodeDomTemplate"/> instance.
		/// </summary>
		/// <param name="ti">TableSchema.</param>
		/// <param name="nameSpace">Namespace.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="className">Name of the class.</param>
		public TableCodeDomTemplate(TableSchema ti, string nameSpace, string fileName, string className) : base(fileName, className, nameSpace)
		{
			this.ti = ti;
		}
	}
}