namespace Adapdev.CodeGen
{
	using System;
	using Adapdev.Data.Schema;

	/// <summary>
	/// Summary description for AbstractConfig.
	/// </summary>
	public abstract class AbstractSchemaConfig : AbstractConfig
	{
		protected string connectionString = String.Empty;
		protected DatabaseSchema databaseSchema = new DatabaseSchema();

		/// <summary>
		/// Creates a new <see cref="AbstractSchemaConfig"/> instance.
		/// </summary>
		/// <param name="connectionString">Connection string.</param>
		/// <param name="nameSpace">Namespace.</param>
		/// <param name="databaseSchema">Database schema.</param>
		public AbstractSchemaConfig(string connectionString, string nameSpace, DatabaseSchema databaseSchema) : base(nameSpace)
		{
			this.connectionString = connectionString;
			this.databaseSchema = databaseSchema;
		}

		/// <summary>
		/// Gets or sets the connection string.
		/// </summary>
		/// <value></value>
		public string ConnectionString
		{
			get { return this.connectionString; }
			set { this.connectionString = value; }
		}

		/// <summary>
		/// Gets or sets the <see cref="DatabaseSchema"/>
		/// </summary>
		/// <value></value>
		public DatabaseSchema DatabaseSchema
		{
			get { return this.databaseSchema; }
			set { this.databaseSchema = value; }
		}
	}
}