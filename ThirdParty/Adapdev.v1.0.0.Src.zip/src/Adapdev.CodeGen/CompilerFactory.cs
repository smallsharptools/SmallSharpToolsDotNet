namespace Adapdev.CodeGen
{
	using System.CodeDom.Compiler;
	using Microsoft.CSharp;
	using Microsoft.JScript;
	using Microsoft.MCpp;
	using Microsoft.VisualBasic;
	using Microsoft.VJSharp;

	/// <summary>
	/// Summary description for CompilerFactory.
	/// </summary>
	public class CodeProviderFactory
	{
		/// <summary>
		/// Gets the code provider.
		/// </summary>
		/// <param name="codeType">Code type.</param>
		/// <returns></returns>
		public static CodeDomProvider GetCodeProvider(LanguageType codeType)
		{
			switch (codeType)
			{
				case LanguageType.CPP:
					return new MCppCodeProvider();
				case LanguageType.CSHARP:
					return new CSharpCodeProvider();
				case LanguageType.JSCRIPT:
					return new JScriptCodeProvider();
				case LanguageType.JSHARP:
					return new VJSharpCodeProvider();
				case LanguageType.VBNET:
					return new VBCodeProvider();
				default:
					return new CSharpCodeProvider();
			}
		}
	}
}