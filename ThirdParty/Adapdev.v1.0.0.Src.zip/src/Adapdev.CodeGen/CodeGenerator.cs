namespace Adapdev.CodeGen
{
	using System;
	using System.CodeDom;
	using System.CodeDom.Compiler;
	using System.Collections;
	using System.IO;

	public delegate void ICodeTemplateProcessedEventHandler(object sender, ICodeTemplateEventArgs e);

	public delegate void ICodeDomTemplateProcessedEventHandler(object sender, ICodeDomTemplateEventArgs e);

	/// <summary>
	/// Summary description for CodeGenerator.
	/// </summary>
	public class CodeGenerator
	{
		public event ICodeTemplateProcessedEventHandler ICodeTemplateProcessed;
		public event ICodeDomTemplateProcessedEventHandler ICodeDomTemplateProcessed;

		protected string outputDir = String.Empty;

		/// <summary>
		/// Creates a new <see cref="CodeGenerator"/> instance.
		/// </summary>
		/// <param name="outputDir">Output dir.</param>
		public CodeGenerator(string outputDir)
		{
			this.outputDir = outputDir;
		}

		/// <summary>
		/// Gets or sets the output dir.
		/// </summary>
		/// <value></value>
		public string OutputDir
		{
			get { return this.outputDir; }
			set { this.outputDir = value; }
		}

		/// <summary>
		/// Processes the <see cref="ICodeDomTemplate"/> to file.
		/// </summary>
		/// <param name="template">Template.</param>
		/// <param name="codeType">Code type.</param>
		/// <param name="refAssemblies">Reference assemblies.</param>
		public void ProcessICodeDomTemplateToFile(ICodeDomTemplate template, LanguageType codeType, params string[] refAssemblies)
		{
			string location = Path.Combine(this.outputDir, template.OutputDirectory);
			location = Path.Combine(location, codeType.ToString());
			CodeCompileUnit ccu = template.GetCodeCompileUnit();
			
			foreach(string s in refAssemblies)
			{
				ccu.ReferencedAssemblies.Add(s);
			}

			if (ccu != null)
			{
				// Obtains an ICodeGenerator from a CodeDomProvider class.
				CodeDomProvider provider = CodeProviderFactory.GetCodeProvider(codeType);
				ICodeGenerator gen = provider.CreateGenerator();

				// If the directory doesn't exist, create it
				if (!Directory.Exists(location))
				{
					Directory.CreateDirectory(location);
				}

				// Build path and filename
				string filePath = Path.Combine(location, template.FileName + "." + provider.FileExtension);

				if (File.Exists(filePath) && template.Overwrite) // If the filepath exists and it can be overwritten
				{
					// Creates a StreamWriter to an output file.
					StreamWriter sw = new StreamWriter(filePath, false);

					// Generates source code using the code generator.
					gen.GenerateCodeFromCompileUnit(ccu, sw, new CodeGeneratorOptions());

					// Closes the output files.
					sw.Close();
				}
				else if (!File.Exists(filePath)) // If the file path doesn't exist
				{
					// Creates a StreamWriter to an output file.
					StreamWriter sw = new StreamWriter(filePath, false);

					// Generates source code using the code generator.
					gen.GenerateCodeFromCompileUnit(ccu, sw, new CodeGeneratorOptions());

					// Closes the output files.
					sw.Close();
				}

				// Process any custom code
				template.ProcessCustomCode();
			}
			this.OnICodeDomTemplateProcessed(new ICodeDomTemplateEventArgs(template));
		}

		/// <summary>
		/// Processes the I code DOM template.
		/// </summary>
		/// <param name="template">The template.</param>
		/// <param name="codeType">Type of the code.</param>
		/// <param name="refAssemblies">The ref assemblies.</param>
		/// <returns></returns>
		public string ProcessICodeDomTemplate(ICodeDomTemplate template, LanguageType codeType, params string[] refAssemblies)
		{
			CodeCompileUnit ccu = template.GetCodeCompileUnit();
			string output = String.Empty;
			
			foreach(string s in refAssemblies)
			{
				ccu.ReferencedAssemblies.Add(s);
			}

			if (ccu != null)
			{
				// Obtains an ICodeGenerator from a CodeDomProvider class.
				CodeDomProvider provider = CodeProviderFactory.GetCodeProvider(codeType);
				ICodeGenerator gen = provider.CreateGenerator();

				// Creates a StreamWriter to an output file.
				using(StringWriter sw = new StringWriter())
				{
					// Generates source code using the code generator.
					gen.GenerateCodeFromCompileUnit(ccu, sw, new CodeGeneratorOptions());
					output = sw.GetStringBuilder().ToString();
				}

				// Process any custom code
				template.ProcessCustomCode();
			}
			this.OnICodeDomTemplateProcessed(new ICodeDomTemplateEventArgs(template));

			return output;
		}


		/// <summary>
		/// Processes the <see cref="ICodeTemplate"/> to a file.
		/// </summary>
		/// <param name="template">Template.</param>
		public void ProcessICodeTemplateToFile(ICodeTemplate template)
		{
			// Get the code
			string code = template.GetCode();

			// Make sure it's not null or empty
			if (template != null && !code.Equals(String.Empty))
			{
				// Build the output path, and create it if it doesn't exist
				string output = Path.Combine(this.outputDir, template.OutputDirectory);
				if (!Directory.Exists(output))
				{
					Directory.CreateDirectory(output);
				}

				// Build the file path
				string filePath = Path.Combine(output, template.FileName + "." + template.FileExtension);

				if (File.Exists(filePath) && template.Overwrite) // If it exists and can be overwritten
				{
					// Creates a StreamWriter to an output file.
					StreamWriter sw = new StreamWriter(filePath, false);

					// Generates source code using the code generator.
					sw.Write(code);

					// Closes the output files.
					sw.Close();
				}
				else if (!File.Exists(filePath)) // The file doesn't exist
				{
					// Creates a StreamWriter to an output file.
					StreamWriter sw = new StreamWriter(filePath, false);

					// Generates source code using the code generator.
					sw.Write(code);

					// Closes the output files.
					sw.Close();
				}

				template.ProcessCustomCode();
			}
			this.OnICodeTemplateProcessed(new ICodeTemplateEventArgs(template));
		}

		/// <summary>
		/// Processes the <see cref="ICodeDomTemplate"/>s to files.
		/// </summary>
		/// <param name="templates">Templates.</param>
		/// <param name="codeType">Code type.</param>
		public void ProcessICodeDomTemplatesToFiles(ICollection templates, LanguageType codeType)
		{
			foreach (ICodeDomTemplate template in templates)
			{
				try
				{
					this.ProcessICodeDomTemplateToFile(template, codeType);
				}
				catch(Exception ex)
				{
					throw ex;					
				}
			}
		}

		/// <summary>
		/// Processes the <see cref="ICodeTemplate"/>s to files.
		/// </summary>
		/// <param name="templates">Templates.</param>
		public void ProcessICodeDomTemplatesToFiles(ICollection templates)
		{
			foreach (ICodeDomTemplate template in templates)
			{
				this.ProcessICodeDomTemplateToFile(template, LanguageType.CPP);
				this.ProcessICodeDomTemplateToFile(template, LanguageType.CSHARP);
				this.ProcessICodeDomTemplateToFile(template, LanguageType.JSCRIPT);
				this.ProcessICodeDomTemplateToFile(template, LanguageType.JSHARP);
				this.ProcessICodeDomTemplateToFile(template, LanguageType.VBNET);
			}
		}

		public void ProcessICodeTemplatesToFiles(ICollection templates)
		{
			foreach (ICodeTemplate template in templates)
			{
				this.ProcessICodeTemplateToFile(template);
			}
		}

		/// <summary>
		/// Processes the templates to an assembly.
		/// </summary>
		/// <param name="templates">Templates.</param>
		/// <param name="codeType">Code type.</param>
		/// <param name="assembly">Assembly.</param>
		/// <param name="cparams">Cparams.</param>
		public void ProcessTemplatesToAssembly(ICollection templates, LanguageType codeType, string assembly, CompilerParameters cparams)
		{
			// Create compiler for the specified CodeDom
			CodeDomProvider provider = CodeProviderFactory.GetCodeProvider(codeType);
			ICodeCompiler gen = provider.CreateCompiler();

			ArrayList files = new ArrayList();

			// Generate the code
			foreach (ICodeDomTemplate template in templates)
			{
				this.ProcessICodeDomTemplateToFile(template, codeType);
				files.Add(template.FileName + "." + provider.FileExtension);
			}

			// Compile the code
			gen.CompileAssemblyFromFileBatch(cparams, (string[]) files.ToArray(typeof (string)));
		}

		/// <summary>
		/// Fires when the <see cref="ICodeTemplate"/> is processed
		/// </summary>
		/// <param name="e">E.</param>
		public void OnICodeTemplateProcessed(ICodeTemplateEventArgs e)
		{
			if (ICodeTemplateProcessed != null)
			{
				//Invokes the delegates.
				ICodeTemplateProcessed(this, e);
			}
		}

		/// <summary>
		/// Fires when the <see cref="ICodeDomTemplate"/> is processed
		/// </summary>
		/// <param name="e">E.</param>
		public void OnICodeDomTemplateProcessed(ICodeDomTemplateEventArgs e)
		{
			if (ICodeDomTemplateProcessed != null)
			{
				//Invokes the delegates.
				ICodeDomTemplateProcessed(this, e);
			}
		}

//		public void ProcessTemplateAssemblyToFiles(Assembly a, LanguageType codeType){}
//		public void ProcessTemplateAssemblyToAssembly(string assemblyToRead, string assemblyToWrite, LanguageType codeType, CompilerParameters cparams){}
//
//		public void ProcessCodeCompileUnitToFile(CodeCompileUnit ccu, string fileName, LanguageType codeType){}
//		public void ProcessCodeCompileUnitsToFiles(ICollection ccus, string[] fileNames, LanguageType codeType){}
//		public void ProcessCodeCompileUnitsToAssembly(ICollection ccus, LanguageType codeType, string assembly, CompilerParameters cparams){}
//		public void ProcessCodeCompileUnitAssemblyToFiles(Assembly a, LanguageType codeType){}
//		public void ProcessCodeCompileUnitAssemblyToAssembly(string assemblyToRead, string assemblyToWrite, LanguageType codeType, CompilerParameters cparams){}

	}


}