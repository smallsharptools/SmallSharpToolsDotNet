using System;

namespace Adapdev.Data.CodeGen
{
	/// <summary>
	/// Summary description for CodeType.
	/// </summary>
	/// 
	[FlagsAttribute]
	public enum CodeType
	{
		CSHARP,
		JSHARP,
		JSCRIPT,
		VBNET,
		CPP
	}
}
