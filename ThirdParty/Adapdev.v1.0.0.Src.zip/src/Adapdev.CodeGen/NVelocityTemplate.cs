using System;
using System.IO;
using Adapdev.IO;
using NVelocity;
using NVelocity.App;

namespace Adapdev.CodeGen
{
	/// <summary>
	/// Summary description for NVelocityTemplate.
	/// </summary>
	public class NVelocityTemplate : INVelocityTemplate
	{
		protected VelocityContext context = null;
		protected string content = String.Empty;

		public NVelocityTemplate()
		{
			if (!File.Exists("nvelocity.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "nvelocity.properties"), Path.Combine(".", "nvelocity.properties"), true);
			if (!File.Exists("directive.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "directive.properties"), Path.Combine(".", "directive.properties"), true);

			Velocity.Init("nvelocity.properties");
			context = new VelocityContext();
		}

		public void SetFileTemplate(string filePath)
		{
			if(!File.Exists(filePath)) throw new FileNotFoundException("Couldn't find file.", filePath);
			else this.content = FileUtil.ReadFile(filePath);
		}

		public void SetTemplate(string content)
		{
			this.content = content;
		}

		#region INVelocityTemplate Members

		public NVelocity.VelocityContext Context
		{
			get
			{
				return this.context;
			}
		}

		public void AddContext(string key, object value)
		{
			this.context.Put(key, value);
		}

		public string GetOutput()
		{
			if(this.content.Length > 0)
			{
				context.Put("template", this);

				StringWriter writer = new StringWriter();
				Velocity.Evaluate(context, writer, "output", this.content);

				return writer.GetStringBuilder().ToString();
			}
			else
			{
				return String.Empty;
			}
		}

		#endregion
	}
}
