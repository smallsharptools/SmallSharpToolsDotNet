namespace Adapdev.CodeGen
{
	using System;
	using Adapdev.Data.Schema;

	public abstract class TableCodeTemplate : AbstractCodeTemplate
	{
		protected TableSchema ti;

		/// <summary>
		/// Creates a new <see cref="TableCodeTemplate"/> instance.
		/// </summary>
		/// <param name="ti">TableSchema.</param>
		/// <param name="nameSpace">Namespace.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		/// <param name="className">Name of the class.</param>
		public TableCodeTemplate(TableSchema ti,
		                         string nameSpace,
		                         string fileName,
		                         string fileExtension,
		                         string className) :
		                         	base(fileName, fileExtension, className, nameSpace)
		{
			this.ti = ti;
		}

		/// <summary>
		/// Creates a new <see cref="TableCodeTemplate"/> instance.
		/// </summary>
		/// <param name="ti">TableSchema.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		public TableCodeTemplate(TableSchema ti,
		                         string fileName,
		                         string fileExtension) :
		                         	base(fileName, fileExtension, String.Empty, String.Empty)
		{
			this.ti = ti;
		}

	}
}