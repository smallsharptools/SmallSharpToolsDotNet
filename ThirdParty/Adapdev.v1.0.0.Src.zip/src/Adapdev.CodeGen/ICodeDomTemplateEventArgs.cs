namespace Adapdev.CodeGen
{
	using System;

	/// <summary>
	/// Summary description for ICodeDomTemplateEventArgs.
	/// </summary>
	public class ICodeDomTemplateEventArgs : EventArgs
	{
		private ICodeDomTemplate _template = null;

		/// <summary>
		/// Creates a new <see cref="ICodeDomTemplateEventArgs"/> instance.
		/// </summary>
		/// <param name="template">Template.</param>
		public ICodeDomTemplateEventArgs(ICodeDomTemplate template)
		{
			this._template = template;
		}

		/// <summary>
		/// Gets the <see cref="ICodeDomTemplate"/>
		/// </summary>
		/// <value></value>
		public ICodeDomTemplate ICodeDomTemplate
		{
			get { return this._template; }
		}
	}

}