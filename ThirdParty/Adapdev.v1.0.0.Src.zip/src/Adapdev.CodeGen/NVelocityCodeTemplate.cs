namespace Adapdev.CodeGen
{
	using System;
	using System.IO;
	using NVelocity;
	using NVelocity.App;

	/// <summary>
	/// Summary description for NVelocityCodeTemplate.
	/// </summary>
	public class NVelocityCodeTemplate : AbstractCodeTemplate, INVelocityTemplate
	{
		protected string templateFile = String.Empty;
		protected VelocityContext context = null;

		/// <summary>
		/// Creates a new <see cref="NVelocityCodeTemplate"/> instance.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		/// <param name="overWrite">Over write.</param>
		/// <param name="templateFile">Template file.</param>
		/// <param name="outputDirectory">Output directory.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="nameSpace">Namespace.</param>
		public NVelocityCodeTemplate(string fileName,
		                             string fileExtension,
		                             bool overWrite,
		                             string templateFile,
		                             string outputDirectory,
		                             string className,
		                             string nameSpace) : base(fileName,
		                                                      fileExtension,
		                                                      className,
		                                                      nameSpace)
		{
			this.templateFile = templateFile;
			this.outputDir = outputDirectory;
			this.overwrite = overWrite;

			if (!File.Exists("nvelocity.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "nvelocity.properties"), Path.Combine(".", "nvelocity.properties"), true);
			if (!File.Exists("directive.properties")) File.Copy(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "directive.properties"), Path.Combine(".", "directive.properties"), true);

			Velocity.Init("nvelocity.properties");
			context = new VelocityContext();
		}

		/// <summary>
		/// Creates a new <see cref="NVelocityCodeTemplate"/> instance.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="fileExtension">File extension.</param>
		/// <param name="templateFile">Template file.</param>
		/// <param name="outputDirectory">Output directory.</param>
		public NVelocityCodeTemplate(string fileName, string fileExtension, string templateFile, string outputDirectory) :
			this(fileName,
			     fileExtension,
			     true,
			     templateFile,
			     outputDirectory,
			     String.Empty,
			     String.Empty)
		{
		}

		/// <summary>
		/// Gets the code.
		/// </summary>
		/// <returns></returns>
		public override string GetCode()
		{
			if(!context.ContainsKey("namespace")) context.Put("namespace", this.nameSpace);
			if(!context.ContainsKey("classname")) context.Put("classname", this.className);
			if(!context.ContainsKey("filename")) context.Put("filename", this.fileName);
			context.Put("datetimenow", DateTime.Now);
			context.Put("template", this);

			StringWriter writer = new StringWriter();
			Velocity.MergeTemplate(this.templateFile, context, writer);

			return writer.GetStringBuilder().ToString();
		}

		/// <summary>
		/// Gets or sets the template file.
		/// </summary>
		/// <value></value>
		public string TemplateFile
		{
			get { return this.templateFile; }
			set { this.templateFile = value; }
		}

		public override bool Overwrite
		{
			get { return this.overwrite; }
			set { base.Overwrite = value; }
		}

		/// <summary>
		/// Gets the context.
		/// </summary>
		/// <value></value>
		public VelocityContext Context
		{
			get { return this.context; }
		}

		/// <summary>
		/// Adds the context.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void AddContext(string key, object value)
		{
			this.context.Put(key, value);
		}

		/// <summary>
		/// Gets the output.
		/// </summary>
		/// <returns></returns>
		public string GetOutput()
		{
			return this.GetCode();
		}

		public string GetConversionExpression(string objectType)
		{
			string subt = objectType.Substring(objectType.IndexOf(".") + 1);
			return "Convert.To"+subt;
		}
	}
}