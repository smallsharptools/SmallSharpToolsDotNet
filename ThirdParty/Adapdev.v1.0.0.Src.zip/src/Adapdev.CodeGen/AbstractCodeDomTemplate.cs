namespace Adapdev.CodeGen
{
	using System;
	using System.CodeDom;

	/// <summary>
	/// Summary description for AbstractTemplate.
	/// </summary>
	public abstract class AbstractCodeDomTemplate : ICodeDomTemplate
	{
		protected string fileName = String.Empty;
		protected string className = String.Empty;
		protected string outputDir = String.Empty;
		protected string nameSpace = String.Empty;
		protected bool overwrite = true;

		/// <summary>
		/// Creates a new <see cref="AbstractCodeDomTemplate"/> instance.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="nameSpace">Namespace.</param>
		public AbstractCodeDomTemplate(string fileName, string className, string nameSpace)
		{
			this.fileName = fileName;
			this.className = className;
			this.nameSpace = nameSpace;
		}

		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value></value>
		public string FileName
		{
			get { return this.fileName; }
			set { this.fileName = value; }
		}

		/// <summary>
		/// Gets or sets the name of the class.
		/// </summary>
		/// <value></value>
		public string ClassName
		{
			get { return this.className; }
			set { this.className = value; }
		}

		/// <summary>
		/// Gets or sets the output directory.
		/// </summary>
		/// <value></value>
		public virtual string OutputDirectory
		{
			get { return this.outputDir; }
			set { this.outputDir = value; }
		}

		/// <summary>
		/// Gets or sets the namespace.
		/// </summary>
		/// <value></value>
		public virtual string Namespace
		{
			get { return this.nameSpace; }
			set { this.nameSpace = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether generated file can be overwritten
		/// </summary>
		/// <value>
		/// 	<c>true</c> if it can be overwritten; otherwise, <c>false</c>.
		/// </value>
		public virtual bool Overwrite
		{
			get { return this.overwrite; }
			set { this.overwrite = value; }
		}

		/// <summary>
		/// Processes the custom code.
		/// </summary>
		public virtual void ProcessCustomCode()
		{
		}

		/// <summary>
		/// Gets the code compile unit.
		/// </summary>
		/// <returns></returns>
		public abstract CodeCompileUnit GetCodeCompileUnit();
	}
}