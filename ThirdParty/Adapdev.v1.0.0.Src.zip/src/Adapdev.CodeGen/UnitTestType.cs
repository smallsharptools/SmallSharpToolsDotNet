using System;

namespace Adapdev.Data.CodeGen
{
	/// <summary>
	/// Summary description for UnitTestType.
	/// </summary>
	public enum UnitTestType
	{
		CSUNIT,
		NUNIT,
		ZANEBUG,
		MBUNIT
	}
}
