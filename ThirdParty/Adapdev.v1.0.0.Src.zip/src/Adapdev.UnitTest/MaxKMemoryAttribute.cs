#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies the maximum amount of memory that a Test can use.
	/// 
	/// If the memory used by the tests exceeds this value, then the Test
	/// will fail.
	/// </summary>
	/// <remarks>
	/// The Zanebug memory measurement feature is currently buggy, and
	/// should not be relied upon for accurate measurements
	/// </remarks>
	/// <example>
	/// [Test]
	/// [MaxKMemory(200)]
	/// public void MaxKMemory()
	/// {
	///		// this test will fail if the memory usage
	///		// exceeds 200kb
	///	}
	///	</example>
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public sealed class MaxKMemoryAttribute : Attribute
	{
		private int maxK;

		/// <summary>
		/// The maximum amount of memory that should be used (in kb)
		/// </summary>
		public int MaxK
		{
			get { return maxK; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="n">The maximum amount of memory that should be used (in kb)</param>
		public MaxKMemoryAttribute(int n)
		{
			maxK = n;
		}
	}
}