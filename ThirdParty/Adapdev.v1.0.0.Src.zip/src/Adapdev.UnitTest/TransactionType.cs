using System;

namespace Adapdev.UnitTest
{
	/// <summary>
	/// Summary description for TransactionType.
	/// </summary>
	public enum TransactionType
	{
		None,
		AutoCommit,
		AutoRollback
	}
}
