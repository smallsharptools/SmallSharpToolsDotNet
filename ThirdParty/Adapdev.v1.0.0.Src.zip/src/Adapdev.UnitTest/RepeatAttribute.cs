#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies how many times a Test or TestFixture should be repeated
	/// </summary>
	/// <example>
	/// [Test]
	/// [Repeat(5)]
	/// public void Repeat(){
	///		// this test will be run 5 times in a row
	/// }
	/// 
	/// [Test]
	/// [Repeat(5,3000)]
	/// public void Repeat(){
	///		// this test will be run 5 times in a row
	///		// with a 3 second delay between each run
	/// }
	/// </example>
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple=false, Inherited=true)]
	public sealed class RepeatAttribute : Attribute
	{
		private int repCount = 1;
		private int delayBetweenReps = 0; //ms

		/// <summary>
		/// The number of times the Test or TestFixture should be repeated
		/// </summary>
		public int RepeatCount
		{
			get { return repCount; }
		}

		/// <summary>
		/// The number of milliseconds that the engine should wait 
		/// before repeating the Test
		/// </summary>
		public int RepeatDelay
		{
			get { return delayBetweenReps; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="count">The number of times the Test or TestFixture should be repeated</param>
		public RepeatAttribute(int count)
		{
			repCount = count;
			delayBetweenReps = 0;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="count">The number of times the Test or TestFixture should be repeated</param>
		/// <param name="delay">The number of milliseconds that the engine should wait 
		/// before repeating the Test</param>
		public RepeatAttribute(int count, int delay)
		{
			repCount = count;
			delayBetweenReps = delay;
		}


	}
}