#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies a place for code that should be run prior to a Test
	/// 
	/// Unless a Test name is specified, this will run prior to each Test.
	/// </summary>
	/// <example>
	/// [TestSetUp]
	/// public void SetUp(){
	///		// this will run for each test
	/// }
	/// 
	/// [TestSetUp(Test="SomeTest")]
	/// public void SetUpForSomeTest(){
	///		// this will run only for SomeTest
	/// }
	/// 
	/// [Test]
	/// public void SomeTest(){
	///		// code
	/// }
	/// </example>
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public class TestSetUpAttribute : Attribute
	{
		private string _test = "";

		/// <summary>
		/// Constructor
		/// </summary>
		public TestSetUpAttribute() : base()
		{
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="test">The name of the Test that this should run for.</param>
		public TestSetUpAttribute(string test)
		{
			this._test = test;
		}

		public string Test
		{
			get { return this._test; }
			set { this._test = value; }
		}
	}
}