#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies a TestFixture, which is a designation for a class that contains
	/// one or more Tests.
	/// 
	/// If a class contains Tests, but is not marked with the TestFixture attribute then
	/// the class will be ignored by the test engine.
	/// </summary>
	/// <example>
	/// using System;
	/// using Adapdev.UnitTest;
	/// 
	/// namespace Tests
	/// {
	///		[TestFixture]	
	///		public class SomeTest
	///		{
	///			[Test]
	///			public void Test1(){...}
	///			
	///			[Test]
	///			public void Test2(){...}
	///		}
	///	}
	/// </example>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple=false, Inherited=true)]
	public sealed class TestFixtureAttribute : Attribute
	{
		private bool _multiThreaded = false;

		public bool IsMultiThreaded
		{
			get { return _multiThreaded; }
			set { _multiThreaded = value; }
		}

	}
}