using System;

namespace Adapdev.UnitTest
{
	/// <summary>
	/// Summary description for TestType.
	/// </summary>
	/// 
	[Serializable]
	[Flags]
	public enum TestType : int
	{
		/// <summary>
		/// 
		/// </summary>
		Unit = 1,
		/// <summary>
		/// 
		/// </summary>
		Integration = 2,
		/// <summary>
		/// 
		/// </summary>
		System = 4,
		/// <summary>
		/// 
		/// </summary>
		Database = 8,
		/// <summary>
		/// Function testing of the target-of-test should focus on any requirements for test that can be traced directly to use cases or business functions and business rules. The goals of these tests are to verify proper data acceptance, processing, and retrieval, and the appropriate implementation of the business rules. This type of testing is based upon black box techniques; that is verifying the application and its internal processes by interacting with the application via the Graphical User Interface (GUI) and analyzing the output or results.
		/// </summary>
		Functional = 16,
		/// <summary>
		/// Business Cycle Testing should emulate the activities performed over time. A period should be identified, such as one year, and transactions and activities that would occur during a year's period should be executed. This includes all daily, weekly, and monthly cycles and, events that are date-sensitive, such as ticklers.
		/// </summary>
		BusinessCycle = 32,
		/// <summary>
		/// User Interface (UI) testing verifies a user's interaction with the software. The goal of UI testing is to ensure that the User Interface provides the user with the appropriate access and navigation through the functions of the target-of-test. In addition, UI testing ensures that the objects within the UI function as expected and conform to corporate or industry standards.
		/// </summary>
		DesktopUserInterface = 64,
		/// <summary>
		/// User Interface (UI) testing verifies a user's interaction with the software. The goal of UI testing is to ensure that the User Interface provides the user with the appropriate access and navigation through the functions of the target-of-test. In addition, UI testing ensures that the objects within the UI function as expected and conform to corporate or industry standards.
		/// </summary>
		WebUserInterface = 128,
		/// <summary>
		/// Performance profiling is a performance test in which response times, transaction rates, and other time-sensitive requirements are measured and evaluated. The goal of Performance Profiling is to verify performance requirements have been achieved. Performance profiling is implemented and executed to profile and tune a target-of-test's performance behaviors as a function of conditions such as workload or hardware configurations
		/// </summary>
		Performance = 256,
		/// <summary>
		/// 
		/// </summary>
		Web = 512,
		/// <summary>
		/// Load testing is a performance test which subjects the target-of-test to varying workloads to measure and evaluate the performance behaviors and ability of the target-of-test to continue to function properly under these different workloads.  The goal of load testing is to determine and ensure that the system functions properly beyond the expected maximum workload. Additionally, load testing evaluates the performance characteristics, such as response times, transaction rates, and other time sensitive issues).
		/// </summary>
		Load = 1024,
		/// <summary>
		/// Stress testing is a type of performance test implemented and executed to find errors due to low resources or competition for resources. Low memory or disk space may reveal defects in the target-of-test that aren't apparent under normal conditions. Other defects might result from competition for shared resources like database locks or network bandwidth. Stress testing can also be used to identify the peak workload the target-of-test can handle.
		/// </summary>
		Stress = 2048,
		/// <summary>
		/// Volume Testing subjects the target-of-test to large amounts of data to determine if limits are reached that cause the software to fail. Volume Testing also identifies the continuous maximum load or volume the target-of-test can handle for a given period. For example, if the target-of-test is processing a set of database records to generate a report, a Volume Test would use a large test database and check that the software behaved normally and produced the correct report.
		/// </summary>
		Volume = 4096,
		/// <summary>
		/// Configuration testing verifies the operation of the target-of-test on different software and hardware configurations. In most production environments, the particular hardware specifications for the client workstations, network connections and database servers vary. Client workstations may have different software loaded�for example, applications, drivers, and so on�and at any one time, many different combinations may be active using different resources.
		/// </summary>
		Configuration = 8192,
		/// <summary>
		/// Security and Access Control Testing
		/// </summary>
		Security = 16284,
		/// <summary>
		/// Failover and Recovery Testing ensures that the target-of-test can successfully failover and recover from a variety of hardware, software or network malfunctions with undue loss of data or data integrity.
		/// </summary>
		FailoverAndRecovery = 32568
	}
}
