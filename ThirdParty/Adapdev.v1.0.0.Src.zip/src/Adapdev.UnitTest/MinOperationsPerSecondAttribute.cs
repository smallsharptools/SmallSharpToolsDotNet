#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies the minimum number of times a Test should be able
	/// to run within 1 second.
	/// </summary>
	/// <remarks>
	/// The MinOps/s value is derived by dividing 1 by the Test duration:
	/// 
	/// 1/(test duration) = MinOps/s
	/// </remarks>
	/// <example>
	/// [Test]
	/// [MinOperationsPerSecond(10)]
	/// public void MinOpsPerSecond(){
	///		// this test will fail if it can't be run
	///		// 10 times in 1 second
	/// }
	/// </example>
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public sealed class MinOperationsPerSecondAttribute : Attribute
	{
		private int minOpsPerSecond;

		/// <summary>
		/// The minimum number of times a Test should run
		/// within a second
		/// </summary>
		public int MinOps
		{
			get { return minOpsPerSecond; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="n">
		/// The minimum number of times a Test should run
		/// within a second
		/// </param>
		public MinOperationsPerSecondAttribute(int n)
		{
			minOpsPerSecond = n;
		}
	}
}