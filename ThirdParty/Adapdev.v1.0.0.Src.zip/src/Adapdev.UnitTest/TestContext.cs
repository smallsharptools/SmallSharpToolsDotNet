using System;

namespace Adapdev.UnitTest
{
	/// <summary>
	/// Summary description for TestContext.
	/// </summary>
	public class TestContext
	{
		public TestContext()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
