using System;

namespace Adapdev.UnitTest
{
	/// <summary>
	/// Summary description for RollbackTransaction.
	/// </summary>
	/// 
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public class RollbackTransaction : Attribute
	{
	}
}
