using System;

namespace Adapdev.UnitTest
{
	/// <summary>
	/// Summary description for Transaction.
	/// </summary>
	/// 
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public class TransactionAttribute : Attribute
	{
	}
}
