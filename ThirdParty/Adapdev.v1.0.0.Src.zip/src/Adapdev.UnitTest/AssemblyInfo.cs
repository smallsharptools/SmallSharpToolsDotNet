using System;
using System.Reflection;

[assembly: AssemblyTitle("Adapdev.UnitTest")]
