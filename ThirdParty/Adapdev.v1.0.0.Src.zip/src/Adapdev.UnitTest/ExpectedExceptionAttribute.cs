#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.UnitTest
{
	using System;

	/// <summary>
	/// Specifies an Exception type that is expected to be thrown.
	/// 
	/// If that Exception type, or one of its children, is thrown then
	/// the Test will pass.
	/// 
	/// If the Exception type, or one of its children, is not thrown then
	/// the Test will fail.
	/// </summary>
	/// <example>
	/// [Test]
	///	[ExpectedException(typeof(DivideByZeroException))]
	///	public void ExpectedDivideByZeroException()
	///	{
	///		Console.WriteLine("ExpectedException");
	///		throw new DivideByZeroException("This Exception is expected.");
	///	}
	/// </example>
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=false, Inherited=true)]
	public sealed class ExpectedExceptionAttribute : Attribute
	{
		private string expectedException = String.Empty;
		private string message = String.Empty;

		/// <summary>
		/// The ExceptionType that is expected to be thrown.
		/// </summary>
		public string ExceptionType
		{
			get { return expectedException; }
		}

		public string Message
		{
			get { return this.message;}
			set { this.message = value;}
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="exception">The ExceptionType that is expected to be thrown.</param>
		public ExpectedExceptionAttribute(Type exception)
		{
			expectedException = exception.FullName;
		}

		public ExpectedExceptionAttribute(Type exception, string message)
		{
			this.expectedException = exception.FullName;
			this.message = message;
		}
	}
}