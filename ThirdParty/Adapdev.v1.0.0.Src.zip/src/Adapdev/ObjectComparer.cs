using System;
using System.Reflection;
using System.Runtime.Serialization;
using Adapdev.Reflection;
using Adapdev.Serialization;

namespace Adapdev
{
	/// <summary>
	/// Summary description for ObjectComparer.
	/// </summary>
	public class ObjectComparer
	{
		private ObjectComparer()
		{
		}

		/// <summary>
		/// Does a binary comparison of the objects.
		/// </summary>
		/// <remarks>Both class must support serialization.</remarks>
		/// <param name="x">Object x.</param>
		/// <param name="y">Object y.</param>
		/// <returns></returns>
		public static bool AreBytesEqual(object x, object y)
		{
			return AreBytesEqual(Serializer.SerializeToBinary(x), Serializer.SerializeToBinary(y));
		}

		/// <summary>
		/// Are the properties equal.
		/// </summary>
		/// <param name="x">Object x.</param>
		/// <param name="y">Object y.</param>
		/// <returns></returns>
		public static bool ArePropertiesEqual(object x, object y)
		{
			Type t = x.GetType();
			IClassAccessor accessor = ClassAccessorCache.Get(t);
			try
			{
				object p1 = null;
				object p2 = null;
				IPropertyAccessor property = null;
				foreach(string key in accessor.GetIPropertyAccessors().Keys)
				{
					property = accessor.GetIPropertyAccessor(key);
					p1 = accessor.GetPropertyValue(x, key);
					p2 = accessor.GetPropertyValue(y, key);

					if(!p1.Equals(Convert.ChangeType(p2, property.PropertyType)))
						return false;
				}

				return true;
			}
			catch(ArgumentException)
			{
				return false;
			}
		}

		/// <summary>
		/// Are the objects equal.  Compares both fields and properties
		/// </summary>
		/// <param name="x">Object x.</param>
		/// <param name="y">Object y.</param>
		/// <returns></returns>
		public static bool AreEqual(object x, object y)
		{
			bool equal = false;
			equal = ObjectComparer.AreFieldsEqual(x, y);
			if(!equal) return false;
			equal = ObjectComparer.ArePropertiesEqual(x, y);
			return equal;
		}

		/// <summary>
		/// Are the fields equal.
		/// </summary>
		/// <param name="x">Object x.</param>
		/// <param name="y">Object y.</param>
		/// <returns></returns>
		public static bool AreFieldsEqual(object x, object y)
		{
			Type t = x.GetType();
			IClassAccessor accessor = ClassAccessorCache.Get(t);
			try
			{
				object p1 = null;
				object p2 = null;
				IFieldAccessor property = null;
				foreach(string key in accessor.GetIFieldAccessors().Keys)
				{
					property = accessor.GetIFieldAccessor(key);
					p1 = accessor.GetFieldValue(x, key);
					p2 = accessor.GetFieldValue(y, key);

					if(!p1.Equals(Convert.ChangeType(p2, property.FieldType)))
						return false;
				}

				return true;
			}
			catch(ArgumentException)
			{
				return false;
			}		
		}

		/// <summary>
		/// Are the bytes equal.
		/// </summary>
		/// <param name="a">Object A</param>
		/// <param name="b">Object B</param>
		/// <returns></returns>
		public static bool AreBytesEqual(byte[] a, byte[] b)
		{
			int i=0;
			bool same=true;
			do
			{
				if(a[i]!=b[i])
				{
					same=false;
					break;
				}
				i++;
			}while(i<a.Length);	
		
			return same;
		}
	}
}
