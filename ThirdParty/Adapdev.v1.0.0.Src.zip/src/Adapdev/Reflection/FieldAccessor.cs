using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;
using System.Collections;

namespace Adapdev.Reflection
{
	/// <summary>
	/// The FieldAccessor class provides fast dynamic access
	/// to a field of a specified target class.
	/// </summary>
	public class FieldAccessor : IFieldAccessor
	{
		private Type mTargetType;
		private string mField;
		private Type mFieldType;
		private FieldInfo fi;

		/// <summary>
		/// Creates a new field accessor.
		/// </summary>
		/// <param name="targetType">Target object type.</param>
		/// <param name="field">Field name.</param>
		public FieldAccessor(Type targetType, string field)
		{
			this.mTargetType = targetType;
			this.fi = targetType.GetField(field, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);

			//
			// Make sure the field exists
			//
			if(this.fi == null)
			{
				throw new FieldAccessorException(
					string.Format("Field \"{0}\" does not exist for type "
					+ "{1}.", field, targetType));
			}
			else
			{
				this.mFieldType = this.fi.FieldType;
			}
		}

		/// <summary>
		/// Gets the property value from the specified target.
		/// </summary>
		/// <param name="target">Target object.</param>
		/// <returns>Property value.</returns>
		public object Get(object target)
		{
			{
				return this.fi.GetValue(target);
			}
		}

		/// <summary>
		/// Sets the property for the specified target.
		/// </summary>
		/// <param name="target">Target object.</param>
		/// <param name="value">Value to set.</param>
		public void Set(object target, object value)
		{
			this.fi.SetValue(target, value);
		}

		/// <summary>
		/// Whether or not the Property supports read access.
		/// </summary>
		public bool CanRead
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// Whether or not the Property supports write access.
		/// </summary>
		public bool CanWrite
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// The Type of object this property accessor was
		/// created for.
		/// </summary>
		public Type TargetType
		{
			get
			{
				return this.mTargetType;
			}
		}

		/// <summary>
		/// The Type of the Property being accessed.
		/// </summary>
		public Type FieldType
		{
			get
			{
				return this.mFieldType;
			}
		}

	}
}