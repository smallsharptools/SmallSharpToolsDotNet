using System;
using System.Collections;
using System.Reflection;
using System.Text;

namespace Adapdev.Reflection
{
	/// <summary>
	/// Summary description for ClassAccessor.
	/// </summary>
	public class ClassAccessor : IClassAccessor
	{
		private Type _type = null;
		private Hashtable _properties = new Hashtable();
		private Hashtable _fields = new Hashtable();
		private DateTime _created;

		/// <summary>
		/// Initializes a new instance of the <see cref="ClassAccessor"/> class.
		/// </summary>
		/// <param name="t">The t.</param>
		public ClassAccessor(Type t)
		{
			this._type = t;
			this._created = DateTime.Now;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ClassAccessor"/> class.
		/// </summary>
		/// <param name="o">The o.</param>
		public ClassAccessor(object o) : this(o.GetType()){}

		/// <summary>
		/// Adds the property.
		/// </summary>
		/// <param name="name">The name.</param>
		public void AddProperty(string name)
		{
			PropertyAccessor accessor = new PropertyAccessor(this._type, name);
			this._properties[name] = accessor;
		}

		/// <summary>
		/// Adds the field.
		/// </summary>
		/// <param name="name">The name.</param>
		public void AddField(string name)
		{
			FieldAccessor accessor = new FieldAccessor(this._type, name);
			this._fields[name] = accessor;
		}

		/// <summary>
		/// Gets the field value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		public object GetFieldValue(object o, string fieldName)
		{
			this.CheckForIFieldAccessor(fieldName);
			FieldAccessor accessor = this._fields[fieldName] as FieldAccessor;
			return accessor.Get(o);
		}

		/// <summary>
		/// Gets the accessor.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns></returns>
		public IValueAccessor GetIValueAccessor(string name)
		{
			if(this.IsFieldDefined(name)) return this._fields[name] as IValueAccessor;
			if(this.IsPropertyDefined(name)) return this._properties[name] as IValueAccessor;
			return null;
		}

		/// <summary>
		/// Gets the field accessor.
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		public IFieldAccessor GetIFieldAccessor(string fieldName)
		{
			return this._fields[fieldName] as FieldAccessor;
		}

		/// <summary>
		/// Gets the field accessors.
		/// </summary>
		/// <returns></returns>
		public Hashtable GetIFieldAccessors()
		{
			return this._fields;
		}

		/// <summary>
		/// Fields the type.
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		public Type FieldType(string fieldName)
		{
			this.CheckForIFieldAccessor(fieldName);
			FieldAccessor accessor = this._properties[fieldName] as FieldAccessor;
			return accessor.FieldType;
		}

		public object GetValue(object o, string name)
		{
			if(this.IsFieldDefined(name)) return this.GetFieldValue(o, name);
			if(this.IsPropertyDefined(name)) return this.GetPropertyValue(o, name);
			return null;
		}

		/// <summary>
		/// Gets the property value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		public object GetPropertyValue(object o, string propertyName)
		{
			this.CheckForIPropertyAccessor(propertyName);
			PropertyAccessor accessor = this._properties[propertyName] as PropertyAccessor;
			return accessor.Get(o);
		}

		/// <summary>
		/// Gets the property accessor.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		public IPropertyAccessor GetIPropertyAccessor(string propertyName)
		{
			return this._properties[propertyName] as PropertyAccessor;
		}

		/// <summary>
		/// Gets the property accessors.
		/// </summary>
		/// <returns></returns>
		public Hashtable GetIPropertyAccessors()
		{
			return this._properties;
		}

		/// <summary>
		/// Properties the type.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		public Type PropertyType(string propertyName)
		{
			this.CheckForIPropertyAccessor(propertyName);
			PropertyAccessor accessor = this._properties[propertyName] as PropertyAccessor;
			return accessor.PropertyType;
		}

		/// <summary>
		/// Gets the type.
		/// </summary>
		/// <value>The type.</value>
		public Type Type
		{
			get
			{
				return this._type;
			}
		}

		/// <summary>
		/// Sets the value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="name">The name.</param>
		/// <param name="val">The val.</param>
		public void SetValue(object o, string name, object val)
		{
			if(this.IsFieldDefined(name)) this.SetFieldValue(o, name, val);
			if(this.IsPropertyDefined(name)) this.SetPropertyValue(o, name, val);
		}

		/// <summary>
		/// Sets the property value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="propertyName">Name of the property.</param>
		/// <param name="val">The val.</param>
		public void SetPropertyValue(object o, string propertyName, object val)
		{
			this.CheckForIPropertyAccessor(propertyName);
			PropertyAccessor accessor = this._properties[propertyName] as PropertyAccessor;
			accessor.Set(o, val);
		}

		/// <summary>
		/// Sets the field value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="fieldName">Name of the field.</param>
		/// <param name="val">The val.</param>
		public void SetFieldValue(object o, string fieldName, object val)
		{
			this.CheckForIFieldAccessor(fieldName);
			FieldAccessor accessor = this._fields[fieldName] as FieldAccessor;
			accessor.Set(o, val);
		}

		/// <summary>
		/// Checks for property accessor.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		private void CheckForIPropertyAccessor(string propertyName)
		{
			if(!this.IsPropertyDefined(propertyName))
				this.AddProperty(propertyName);
		}

		/// <summary>
		/// Checks for field accessor.
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		private void CheckForIFieldAccessor(string fieldName)
		{
			if(!this.IsFieldDefined(fieldName))
				this.AddField(fieldName);
		}

		/// <summary>
		/// Determines whether [is property defined] [the specified property name].
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns>
		/// 	<c>true</c> if [is property defined] [the specified property name]; otherwise, <c>false</c>.
		/// </returns>
		private bool IsPropertyDefined(string propertyName)
		{
			return this._properties.ContainsKey(propertyName);
		}

		/// <summary>
		/// Determines whether [is field defined] [the specified field name].
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns>
		/// 	<c>true</c> if [is field defined] [the specified field name]; otherwise, <c>false</c>.
		/// </returns>
		private bool IsFieldDefined(string fieldName)
		{
			return this._fields.ContainsKey(fieldName);
		}

		/// <summary>
		/// Loads all properties.
		/// </summary>
		public void LoadAllProperties()
		{
			PropertyInfo[] infoArray = this._type.GetProperties();
			foreach(PropertyInfo p in infoArray)
			{
				this.AddProperty(p.Name);
			}
		}

		/// <summary>
		/// Loads all fields.
		/// </summary>
		public void LoadAllFields()
		{
			FieldInfo[] infoArray = this._type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			foreach(FieldInfo f in infoArray)
			{
				this.AddField(f.Name);
			}
		}


		/// <summary>
		/// Loads all properties and fields.
		/// </summary>
		public void LoadAllPropertiesAndFields()
		{
			this.LoadAllFields();
			this.LoadAllProperties();
		}

		/// <summary>
		/// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </returns>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("[" + this._type.FullName + "] Properties loaded: " + Environment.NewLine);
			foreach(string key in this._properties.Keys)
			{
				sb.Append(key + Environment.NewLine);
			}
			sb.Append("[" + this._type.FullName + "] Fields loaded: " + Environment.NewLine);
			foreach(string key in this._fields.Keys)
			{
				sb.Append(key + Environment.NewLine);
			}
			return sb.ToString();
		}

		/// <summary>
		/// Gets the property count.
		/// </summary>
		/// <value>The property count.</value>
		public int PropertyCount
		{
			get{return this._properties.Count;}
		}

		/// <summary>
		/// Gets the field count.
		/// </summary>
		/// <value>The field count.</value>
		public int FieldCount
		{
			get{return this._fields.Count;}
		}

		/// <summary>
		/// Gets the total count.
		/// </summary>
		/// <value>The total count.</value>
		public int TotalCount
		{
			get{return this._fields.Count + this._properties.Count;}
		}

		/// <summary>
		/// Gets the created date.
		/// </summary>
		/// <value>The created date.</value>
		public DateTime Created
		{
			get { return _created; }
		}

	}
}
