using System;

namespace Adapdev.Reflection
{
	public interface IFieldAccessor : IValueAccessor
	{
		/// <summary>
		/// Gets the property value from the specified target.
		/// </summary>
		/// <param name="target">Target object.</param>
		/// <returns>Property value.</returns>
		object Get(object target);

		/// <summary>
		/// Sets the property for the specified target.
		/// </summary>
		/// <param name="target">Target object.</param>
		/// <param name="value">Value to set.</param>
		void Set(object target, object value);

		/// <summary>
		/// Whether or not the Property supports read access.
		/// </summary>
		bool CanRead { get; }

		/// <summary>
		/// Whether or not the Property supports write access.
		/// </summary>
		bool CanWrite { get; }

		/// <summary>
		/// The Type of object this property accessor was
		/// created for.
		/// </summary>
		Type TargetType { get; }

		/// <summary>
		/// The Type of the Property being accessed.
		/// </summary>
		Type FieldType { get; }
	}
}