using System;
using System.Collections;

namespace Adapdev.Reflection
{
	public interface IClassAccessor
	{
		/// <summary>
		/// Adds the property.
		/// </summary>
		/// <param name="name">The name.</param>
		void AddProperty(string name);

		/// <summary>
		/// Adds the field.
		/// </summary>
		/// <param name="name">The name.</param>
		void AddField(string name);

		/// <summary>
		/// Gets the field value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		object GetFieldValue(object o, string fieldName);

		/// <summary>
		/// Gets the accessor.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns></returns>
		IValueAccessor GetIValueAccessor(string name);

		/// <summary>
		/// Gets the field accessor.
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		IFieldAccessor GetIFieldAccessor(string fieldName);

		/// <summary>
		/// Gets the field accessors.
		/// </summary>
		/// <returns></returns>
		Hashtable GetIFieldAccessors();

		/// <summary>
		/// Fields the type.
		/// </summary>
		/// <param name="fieldName">Name of the field.</param>
		/// <returns></returns>
		Type FieldType(string fieldName);

		object GetValue(object o, string name);

		/// <summary>
		/// Gets the property value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		object GetPropertyValue(object o, string propertyName);

		/// <summary>
		/// Gets the property accessor.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		IPropertyAccessor GetIPropertyAccessor(string propertyName);

		/// <summary>
		/// Gets the property accessors.
		/// </summary>
		/// <returns></returns>
		Hashtable GetIPropertyAccessors();

		/// <summary>
		/// Properties the type.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		/// <returns></returns>
		Type PropertyType(string propertyName);

		/// <summary>
		/// Gets the type.
		/// </summary>
		/// <value>The type.</value>
		Type Type { get; }

		/// <summary>
		/// Sets the value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="name">The name.</param>
		/// <param name="val">The val.</param>
		void SetValue(object o, string name, object val);

		/// <summary>
		/// Sets the property value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="propertyName">Name of the property.</param>
		/// <param name="val">The val.</param>
		void SetPropertyValue(object o, string propertyName, object val);

		/// <summary>
		/// Sets the field value.
		/// </summary>
		/// <param name="o">The o.</param>
		/// <param name="fieldName">Name of the field.</param>
		/// <param name="val">The val.</param>
		void SetFieldValue(object o, string fieldName, object val);

		/// <summary>
		/// Loads all properties.
		/// </summary>
		void LoadAllProperties();

		/// <summary>
		/// Loads all fields.
		/// </summary>
		void LoadAllFields();

		/// <summary>
		/// Loads all properties and fields.
		/// </summary>
		void LoadAllPropertiesAndFields();

		/// <summary>
		/// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
		/// </returns>
		string ToString();

		/// <summary>
		/// Gets the property count.
		/// </summary>
		/// <value>The property count.</value>
		int PropertyCount { get; }

		/// <summary>
		/// Gets the field count.
		/// </summary>
		/// <value>The field count.</value>
		int FieldCount { get; }

		/// <summary>
		/// Gets the total count.
		/// </summary>
		/// <value>The total count.</value>
		int TotalCount { get; }

		/// <summary>
		/// Gets the created date.
		/// </summary>
		/// <value>The created date.</value>
		DateTime Created { get; }
	}
}