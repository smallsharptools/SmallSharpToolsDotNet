#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion
using System;
using System.Reflection;

namespace Adapdev.Reflection
{
	using System.Collections;

	/// <summary>
	/// Summary description for AssemblyCache.
	/// </summary>
	public class AssemblyCache
	{
		private static Hashtable ht = new Hashtable();

		/// <summary>
		/// Initializes a new instance of the <see cref="AssemblyCache"/> class.
		/// </summary>
		private AssemblyCache(){}

		/// <summary>
		/// Adds the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="path">The path.</param>
		/// <returns></returns>
		public static Assembly Add(object key, string path)
		{
//			if(!AssemblyCache.ContainsByKey(key) && !AssemblyCache.ContainsByPath(path))
				return AssemblyCache.LoadAssembly(key, path);
//			return AssemblyCache.Get(key);
		}

		/// <summary>
		/// Adds the specified path.
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns></returns>
		public static Assembly Add(string path)
		{
			return AssemblyCache.Add(path, path);
		}

		/// <summary>
		/// Gets the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns></returns>
		public static Assembly Get(object key)
		{
			object o = null;
			lock (ht.SyncRoot)
			{
				o = ht[key];
				if(o == null)
				{
					o = LoadAssembly(key, key.ToString());
				}
			}
			return o as Assembly;
		}

		/// <summary>
		/// Sets the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="a">A.</param>
		protected static void Set(object key, Assembly a)
		{
			lock (ht.SyncRoot)
			{
				ht[key] = a;
			}
		}

		/// <summary>
		/// Determines whether [contains by key] [the specified key].
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>
		/// 	<c>true</c> if [contains by key] [the specified key]; otherwise, <c>false</c>.
		/// </returns>
		public static bool ContainsByKey(object key)
		{
			if(ht[key] != null) return true;
			else return false;
		}

		/// <summary>
		/// Determines whether [contains by path] [the specified path].
		/// </summary>
		/// <param name="path">The path.</param>
		/// <returns>
		/// 	<c>true</c> if [contains by path] [the specified path]; otherwise, <c>false</c>.
		/// </returns>
		public static bool ContainsByPath(string path)
		{
			foreach(Assembly a in ht.Values)
			{
				if(path.ToLower() == a.Location.ToLower()) return true;
			}
			return false;
		}

		/// <summary>
		/// Clears this instance.
		/// </summary>
		public static void Clear()
		{
			ht = new Hashtable();
		}

		/// <summary>
		/// Counts this instance.
		/// </summary>
		/// <returns></returns>
		public static int Count()
		{
			return ht.Count;
		}

		/// <summary>
		/// Loads the assembly.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="path">The path.</param>
		/// <returns></returns>
		private static Assembly LoadAssembly(object key, string path)
		{
			Assembly a = Assembly.LoadFrom(path);
			AssemblyCache.Set(key, a);
			return a;
		}

	}
}