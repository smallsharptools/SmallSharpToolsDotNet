using System;

namespace Adapdev
{
	/// <summary>
	/// Summary description for IEntity.
	/// </summary>
	public interface IEntity
	{
	}
}
