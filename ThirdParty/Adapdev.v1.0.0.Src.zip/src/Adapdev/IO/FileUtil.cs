#region Copyright / License Information
/*

   Copyright 2004 - 2005 Adapdev Technologies, LLC

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

============================
Author Log
============================
III	Full Name
SMM	Sean McCormack (Adapdev)


============================
Change Log
============================
III	MMDDYY	Change

*/
#endregion

namespace Adapdev.IO
{
	using System;
	using System.IO;

	public class FileUtil
	{
		private FileUtil()
		{
		}

		public static void CreateFile(string filePath, string content)
		{
			FileStream fs = null;
			StreamWriter sw = null;
			try
			{
				string directoryName = Path.GetDirectoryName(filePath);
				if (directoryName.Length > 0 && !Directory.Exists(directoryName))
				{
					Directory.CreateDirectory(directoryName);
				}
				fs = new FileStream(filePath, FileMode.Create);
				sw = new StreamWriter(fs);
				sw.Write(content);
			}
			catch (Exception e)
			{
				Console.WriteLine("FileUtil::CreateFile " + e.Message);
				throw e;
			}
			finally
			{
				if (fs != null)
				{
					sw.Close();
					fs.Close();
				}
			}
		}

		public static void CreateFile(string filePath, byte[] content)
		{
			FileStream fs = null;
			BinaryWriter sw = null;
			try
			{
				string directoryName = Path.GetDirectoryName(filePath);
				if (directoryName.Length > 0 && !Directory.Exists(directoryName))
				{
					Directory.CreateDirectory(directoryName);
				}
				Console.WriteLine("creating file: " + filePath);
				fs = new FileStream(filePath, FileMode.Create);
				sw = new BinaryWriter(fs);
				sw.Write(content);
			}
			catch (Exception e)
			{
				Console.WriteLine("FileUtil::CreateFile " + e.Message);
				throw e;
			}
			finally
			{
				if (fs != null)
				{
					sw.Close();
					fs.Close();
				}
			}
		}


		public static string ReadFile(string filePath)
		{
			StreamReader sr = null;
			string content = "";
			try
			{
				sr = new StreamReader(filePath);
				content = sr.ReadToEnd();
			}
			catch (Exception)
			{
			}
			finally
			{
				if (sr != null)
				{
					sr.Close();
				}
			}
			return content;
		}

		public static byte[] ReadBinaryFile(string filePath)
		{
			FileStream fs = null;
			BinaryReader br = null;
			byte[] data = null;
			try
			{
				FileInfo fInfo = new FileInfo(filePath);

				long numBytes = fInfo.Length;

				fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
			
				br = new BinaryReader(fs);

				data = br.ReadBytes((int)numBytes);
			}
			catch (Exception)
			{
			}
			finally
			{
				if(br != null) br.Close();
				if (fs != null) fs.Close();
			}
			return data;
		}

	}
}