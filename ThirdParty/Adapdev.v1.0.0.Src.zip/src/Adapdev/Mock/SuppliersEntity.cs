using System;
using Adapdev.Text;

namespace Adapdev.Mock 
{    

	/// <summary>
	/// An object representation of the Northwind Suppliers table
	/// </summary>
	/// 
	[Serializable]
	public class SuppliersEntity
	{
	
		private System.String _Address = "";
		private System.String _City = "";
		private System.String _CompanyName = "";
		private System.String _ContactName = "";
		private System.String _ContactTitle = "";
		private System.String _Country = "";
		private System.String _Fax = "";
		private System.String _HomePage = "";
		private System.String _Phone = "";
		private System.String _PostalCode = "";
		private System.String _Region = "";
		private System.Int32 _SupplierID = 0;
		private System.DateTime _Created = DateTime.Now;
		public System.DateTime InternalCreated = DateTime.Now;


		public System.String Address 
		{
			get 
			{
				return this._Address;
			}
			set 
			{
				this._Address = value;
			}
		}			
		

		public System.String City 
		{
			get 
			{
				return this._City;
			}
			set 
			{
				this._City = value;
			}
		}			
		

		public System.String CompanyName 
		{
			get 
			{
				return this._CompanyName;
			}
			set 
			{
				this._CompanyName = value;
			}
		}			
		

		public System.String ContactName 
		{
			get 
			{
				return this._ContactName;
			}
			set 
			{
				this._ContactName = value;
			}
		}			
		

		public System.String ContactTitle 
		{
			get 
			{
				return this._ContactTitle;
			}
			set 
			{
				this._ContactTitle = value;
			}
		}			
		

		public System.String Country 
		{
			get 
			{
				return this._Country;
			}
			set 
			{
				this._Country = value;
			}
		}			
		

		public System.String Fax 
		{
			get 
			{
				return this._Fax;
			}
			set 
			{
				this._Fax = value;
			}
		}			
		

		public System.String HomePage 
		{
			get 
			{
				return this._HomePage;
			}
			set 
			{
				this._HomePage = value;
			}
		}			
		

		public System.String Phone 
		{
			get 
			{
				return this._Phone;
			}
			set 
			{
				this._Phone = value;
			}
		}			
		

		public System.String PostalCode 
		{
			get 
			{
				return this._PostalCode;
			}
			set 
			{
				this._PostalCode = value;
			}
		}			
		

		public System.String Region 
		{
			get 
			{
				return this._Region;
			}
			set 
			{
				this._Region = value;
			}
		}			
		

		public System.Int32 SupplierID 
		{
			get 
			{
				return this._SupplierID;
			}
			set 
			{
				this._SupplierID = value;
			}
		}			

		public DateTime Created
		{
			get{return this._Created;}
			set{this._Created = value;}
		}
        
		/// <summary>
		/// Returns a string representation of the object, displaying all property and field names and values.
		/// </summary>
		public override string ToString() 
		{
			return StringUtil.ToString(this);
		}
	}
}