// Ami Bar
// amibar@gmail.com

using System;
using System.Threading;
using System.Globalization;
using System.Security.Principal;
using System.Reflection;
using System.Runtime.Remoting.Contexts;

namespace Adapdev.Threading
{
	#region CallerThreadContext class

	/// <summary>
	/// This class stores the caller thread context in order to restore
	/// it when the work item is executed in the context of the thread 
	/// from the pool.
	/// Note that we can't store the thread's CompressedStack, because 
	/// it throws a security exception
	/// </summary>
	internal class CallerThreadContext
	{
		private CultureInfo _culture = null;
		private CultureInfo _cultureUI = null;
		private IPrincipal _principal;
		private System.Runtime.Remoting.Contexts.Context _context;

		private static FieldInfo _fieldInfo = GetFieldInfo();

		private static FieldInfo GetFieldInfo()
		{
			Type threadType = typeof(Thread);
			return threadType.GetField(
				"m_Context",
				BindingFlags.Instance | BindingFlags.NonPublic);
		}

		/// <summary>
		/// Constructor
		/// </summary>
		private CallerThreadContext()
		{
		}

		/// <summary>
		/// Captures the current thread context
		/// </summary>
		/// <returns></returns>
		public static CallerThreadContext Capture()
		{
			CallerThreadContext callerThreadContext = new CallerThreadContext();

			Thread thread = Thread.CurrentThread;
			callerThreadContext._culture = thread.CurrentCulture;
			callerThreadContext._cultureUI = thread.CurrentUICulture;
			callerThreadContext._principal = Thread.CurrentPrincipal;
			callerThreadContext._context = Thread.CurrentContext;
			return callerThreadContext;
		}

		/// <summary>
		/// Applies the thread context stored earlier
		/// </summary>
		/// <param name="callerThreadContext"></param>
		public static void Apply(CallerThreadContext callerThreadContext)
		{
			Thread thread = Thread.CurrentThread;
			thread.CurrentCulture = callerThreadContext._culture;
			thread.CurrentUICulture = callerThreadContext._cultureUI;
			Thread.CurrentPrincipal = callerThreadContext._principal;

			// Uncomment the following block to enable the Thread.CurrentThread
/*
			if (null != _fieldInfo)
			{
				_fieldInfo.SetValue(
					Thread.CurrentThread, 
					callerThreadContext._context);
			}
*/			
		}
	}

	#endregion
}
