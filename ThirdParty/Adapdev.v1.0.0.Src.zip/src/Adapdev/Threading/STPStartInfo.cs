// Ami Bar
// amibar@gmail.com

using System;

namespace Adapdev.Threading
{
	/// <summary>
	/// Summary description for STPStartInfo.
	/// </summary>
	public class STPStartInfo
	{
        /// <summary>
        /// Idle timeout in milliseconds.
        /// If a thread is idle for _idleTimeout milliseconds then 
        /// it may quit.
        /// </summary>
        private int _idleTimeout;

        /// <summary>
        /// The lower limit of threads in the pool.
        /// </summary>
        private int _minWorkerThreads;

        /// <summary>
        /// The upper limit of threads in the pool.
        /// </summary>
        private int _maxWorkerThreads;

        /// <summary>
        /// Use the caller's security context
        /// </summary>
        private bool _useCallerContext;

        /// <summary>
        /// Dispose of the state object of a work item
        /// </summary>
        private bool _disposeOfStateObjects;

        /// <summary>
        /// The option to run the post execute
        /// </summary>
        private CallToPostExecute _callToPostExecute;

		/// <summary>
		/// A post execute callback to call when none is provided in 
		/// the QueueWorkItem method.
		/// </summary>
		private PostExecuteWorkItemCallback _postExecuteWorkItemCallback;
        
		public STPStartInfo()
		{
            _idleTimeout = SmartThreadPool.DefaultIdleTimeout;
            _minWorkerThreads = SmartThreadPool.DefaultMinWorkerThreads;
            _maxWorkerThreads = SmartThreadPool.DefaultMaxWorkerThreads;
            _useCallerContext = SmartThreadPool.DefaultUseCallerContext;
            _disposeOfStateObjects = SmartThreadPool.DefaultDisposeOfStateObjects;
            _callToPostExecute = SmartThreadPool.DefaultCallToPostExecute;
			_postExecuteWorkItemCallback = SmartThreadPool.DefaultPostExecuteWorkItemCallback;
		}

        public STPStartInfo(STPStartInfo stpStartInfo)
        {
            _idleTimeout = stpStartInfo._idleTimeout;
            _minWorkerThreads = stpStartInfo._minWorkerThreads;
            _maxWorkerThreads = stpStartInfo._maxWorkerThreads;
            _useCallerContext = stpStartInfo._useCallerContext;
            _disposeOfStateObjects = stpStartInfo._disposeOfStateObjects;
            _callToPostExecute = stpStartInfo._callToPostExecute;
			_postExecuteWorkItemCallback = stpStartInfo._postExecuteWorkItemCallback;
        }

        public int IdleTimeout
        {
            get { return _idleTimeout; }
            set { _idleTimeout = value; }
        }

        public int MinWorkerThreads
        {
            get { return _minWorkerThreads; }
            set { _minWorkerThreads = value; }
        }

        public int MaxWorkerThreads
        {
            get { return _maxWorkerThreads; }
            set { _maxWorkerThreads = value; }
        }

        public bool UseCallerContext
        {
            get { return _useCallerContext; }
            set { _useCallerContext = value; }
        }

        public bool DisposeOfStateObjects
        {
            get { return _disposeOfStateObjects; }
            set { _disposeOfStateObjects = value; }
        }

        public CallToPostExecute CallToPostExecute
        {
            get { return _callToPostExecute; }
            set { _callToPostExecute = value; }
        }

		public PostExecuteWorkItemCallback PostExecuteWorkItemCallback
		{
			get { return _postExecuteWorkItemCallback; }
			set { _postExecuteWorkItemCallback = value; }
		}
	}
}
