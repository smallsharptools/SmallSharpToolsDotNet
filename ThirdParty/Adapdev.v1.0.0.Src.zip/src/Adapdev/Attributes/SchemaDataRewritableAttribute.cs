using System;

namespace Adapdev.Attributes
{
	/// <summary>
	/// Summary description for CompareAttribute.
	/// 
	/// Add this attribute to Schema properties that should or shouldn't be updated when performing
	/// a CompareDatabaseSchema between the saved schema and DB schema's
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class SchemaDataRewritableAttribute : Attribute
	{
		private bool _rewrite;
		
		/// <summary>
		/// SchemaDataRewritableAttribute
		/// </summary>
		/// <param name="rewrite">bool - is this property going to be rewritten from the DatabaseSchema</param>
		public SchemaDataRewritableAttribute(bool rewrite)
		{
			this._rewrite = rewrite;
		}

		/// <summary>
		/// Is this Schema property it be re-written from the Database schama
		/// </summary>
		public bool Rewrite
		{
			get{return this._rewrite;}
			set{this._rewrite = value;}		
		}
	}
}
