<script type="text/javascript">
testFoo = "foo"; $('#foo').html('foo');ok( true, "test2.php executed" );
</script>
