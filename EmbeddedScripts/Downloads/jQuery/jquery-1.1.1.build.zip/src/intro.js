/* prevent execution of jQuery if included more than once */
if(typeof window.jQuery == "undefined") {
